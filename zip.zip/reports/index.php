<?php

require_once __DIR__ . '/../includes/auth.php';

requireLogin();

$user = currentUser();

$pageTitle = 'Reports & Analytics';
$activePage = 'reports';

$userRole =
    $user['role'] ?? '';


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

$allowedRoles = [
    'admin',
    'faculty',
    'rps',
    'extension_coordinator'
];


if (
    !in_array(
        $userRole,
        $allowedRoles,
        true
    )
) {

    redirect(
        BASE_URL . '/dashboard.php'
    );
}


/*
|--------------------------------------------------------------------------
| DISPLAY ROLE
|--------------------------------------------------------------------------
*/

$displayRole =
    $userRole === 'rps'
        ? 'Research Processing Staff (RPS)'
        : roleLabel($userRole);


/*
|--------------------------------------------------------------------------
| REPORT CONFIGURATION
|--------------------------------------------------------------------------
*/

$validStatuses = [
    'Draft',
    'Submitted',
    'Under Review',
    'For Revision',
    'Approved',
    'Ongoing',
    'Completed',
    'Rejected',
    'Archived'
];


$reportCatalog = [

    'annual_summary' => [

        'label' =>
            'Annual Research and Extension Summary',

        'roles' => [
            'admin'
        ]
    ],


    'research_projects' => [

        'label' =>
            'Research Projects Report',

        'roles' => [
            'admin',
            'faculty',
            'rps'
        ]
    ],


    'research_status' => [

        'label' =>
            'Research Status Report',

        'roles' => [
            'admin',
            'faculty',
            'rps'
        ]
    ],


    'completed_research' => [

        'label' =>
            'Completed Research Report',

        'roles' => [
            'admin',
            'faculty',
            'rps'
        ]
    ],


    'extension_programs' => [

        'label' =>
            'Extension Programs Report',

        'roles' => [
            'admin',
            'extension_coordinator'
        ]
    ],


    'extension_participants' => [

        'label' =>
            'Extension Participant Report',

        'roles' => [
            'admin',
            'extension_coordinator'
        ]
    ],


    'extension_accomplishments' => [

        'label' =>
            'Extension Accomplishment Report',

        'roles' => [
            'admin',
            'extension_coordinator'
        ]
    ]
];


/*
|--------------------------------------------------------------------------
| ALLOWED REPORT TYPES
|--------------------------------------------------------------------------
*/

$allowedReportTypes = [];


foreach (
    $reportCatalog
    as
    $reportKey =>
    $reportDefinition
) {

    if (
        in_array(
            $userRole,
            $reportDefinition['roles'],
            true
        )
    ) {

        $allowedReportTypes[
            $reportKey
        ] =
            $reportDefinition;
    }
}


/*
|--------------------------------------------------------------------------
| FILTER VALUES
|--------------------------------------------------------------------------
*/

$reportType =
    trim(
        $_GET['report_type']
        ?? ''
    );


$year =
    trim(
        $_GET['year']
        ?? ''
    );


$status =
    trim(
        $_GET['status']
        ?? ''
    );


$unit =
    trim(
        $_GET['unit']
        ?? ''
    );


if (
    $reportType !== ''
    &&
    !isset(
        $allowedReportTypes[
            $reportType
        ]
    )
) {

    $reportType = '';
}


if (
    $year !== ''
    &&
    !preg_match(
        '/^\d{4}$/',
        $year
    )
) {

    $year = '';
}


if (
    $status !== ''
    &&
    !in_array(
        $status,
        $validStatuses,
        true
    )
) {

    $status = '';
}


$unitType = '';

$unitId = 0;


if (
    preg_match(
        '/^(college|department):(\d+)$/',
        $unit,
        $unitMatch
    )
) {

    $unitType =
        $unitMatch[1];

    $unitId =
        (int)$unitMatch[2];

} else {

    $unit = '';
}


/*
|--------------------------------------------------------------------------
| RESEARCH ACCESS
|--------------------------------------------------------------------------
*/

function reportResearchAccess(
    array $user
): array {

    /*
     * Administrator:
     * all non-draft institutional research.
     */

    if (
        $user['role']
        === 'admin'
    ) {

        return [
            "rp.status <> 'Draft'",
            []
        ];
    }


    /*
     * RPS:
     * all non-draft institutional research.
     */

    if (
        $user['role']
        === 'rps'
    ) {

        return [
            "rp.status <> 'Draft'",
            []
        ];
    }


    /*
     * Faculty:
     * own research only.
     */

    if (
        $user['role']
        === 'faculty'
    ) {

        return [
            'rp.researcher_id = ?',
            [
                (int)$user['user_id']
            ]
        ];
    }


    /*
     * All other roles:
     * no research access.
     */

    return [
        '1 = 0',
        []
    ];
}


/*
|--------------------------------------------------------------------------
| EXTENSION ACCESS
|--------------------------------------------------------------------------
*/

function reportExtensionAccess(
    array $user
): array {

    if (
        $user['role']
        === 'admin'
    ) {

        return [
            "ep.status <> 'Draft'",
            []
        ];
    }


    if (
        $user['role']
        === 'extension_coordinator'
    ) {

        return [
            'ep.coordinator_id = ?',
            [
                (int)$user['user_id']
            ]
        ];
    }


    return [
        '1 = 0',
        []
    ];
}


/*
|--------------------------------------------------------------------------
| FILTER HELPER
|--------------------------------------------------------------------------
*/

function reportModuleFilters(
    string $alias,
    string $dateExpression,
    string $year,
    string $status,
    string $unitType,
    int $unitId,
    bool $includeStatus = true
): array {

    $sql = '';

    $params = [];


    if ($year !== '') {

        $sql .= "
            AND YEAR(
                {$dateExpression}
            ) = ?
        ";

        $params[] =
            (int)$year;
    }


    if (
        $includeStatus
        &&
        $status !== ''
    ) {

        $sql .= "
            AND {$alias}.status = ?
        ";

        $params[] =
            $status;
    }


    if (
        $unitType === 'college'
        &&
        $unitId > 0
    ) {

        $sql .= "
            AND {$alias}.college_id = ?
        ";

        $params[] =
            $unitId;
    }


    if (
        $unitType === 'department'
        &&
        $unitId > 0
    ) {

        $sql .= "
            AND {$alias}.department_id = ?
        ";

        $params[] =
            $unitId;
    }


    return [
        $sql,
        $params
    ];
}


/*
|--------------------------------------------------------------------------
| COUNT HELPER
|--------------------------------------------------------------------------
*/

function reportCount(
    PDO $pdo,
    string $table,
    string $alias,
    string $whereSql,
    array $params,
    string $extraSql = ''
): int {

    $sql = "
        SELECT COUNT(*)

        FROM {$table} {$alias}

        WHERE {$whereSql}

        {$extraSql}
    ";


    $stmt =
        $pdo->prepare($sql);


    $stmt->execute(
        $params
    );


    return
        (int)$stmt
            ->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| SUM HELPER
|--------------------------------------------------------------------------
*/

function reportSum(
    PDO $pdo,
    string $table,
    string $alias,
    string $column,
    string $whereSql,
    array $params,
    string $extraSql = ''
): int {

    $sql = "
        SELECT

            COALESCE(
                SUM({$column}),
                0
            )

        FROM {$table} {$alias}

        WHERE {$whereSql}

        {$extraSql}
    ";


    $stmt =
        $pdo->prepare($sql);


    $stmt->execute(
        $params
    );


    return
        (int)$stmt
            ->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| PERSON NAME
|--------------------------------------------------------------------------
*/

function reportPersonName(
    array $row,
    string $prefix = ''
): string {

    $first =
        trim(
            (string)(
                $row[
                    $prefix
                    . 'first_name'
                ]
                ?? ''
            )
        );


    $middle =
        trim(
            (string)(
                $row[
                    $prefix
                    . 'middle_name'
                ]
                ?? ''
            )
        );


    $last =
        trim(
            (string)(
                $row[
                    $prefix
                    . 'last_name'
                ]
                ?? ''
            )
        );


    return trim(
        $first
        .
        ' '
        .
        (
            $middle !== ''
                ? $middle . ' '
                : ''
        )
        .
        $last
    );
}


/*
|--------------------------------------------------------------------------
| STATUS BADGE
|--------------------------------------------------------------------------
*/

function reportStatusBadgeClass(
    string $status
): string {

    return match ($status) {

        'Submitted' =>
            'bg-primary-subtle text-primary-emphasis',

        'Under Review' =>
            'bg-warning-subtle text-warning-emphasis',

        'For Revision' =>
            'bg-warning-subtle text-warning-emphasis',

        'Approved' =>
            'bg-success-subtle text-success-emphasis',

        'Ongoing' =>
            'bg-success-subtle text-success-emphasis',

        'Completed' =>
            'bg-success text-white',

        'Rejected' =>
            'bg-danger-subtle text-danger-emphasis',

        'Archived' =>
            'bg-secondary-subtle text-secondary-emphasis',

        default =>
            'bg-light text-secondary'
    };
}


/*
|--------------------------------------------------------------------------
| BASE ACCESS
|--------------------------------------------------------------------------
*/

[
    $researchAccessSql,
    $researchAccessParams
] =
    reportResearchAccess(
        $user
    );


[
    $extensionAccessSql,
    $extensionAccessParams
] =
    reportExtensionAccess(
        $user
    );


$researchDateExpression =
    'COALESCE(
        rp.start_date,
        DATE(rp.submitted_at),
        DATE(rp.created_at)
    )';


$extensionDateExpression =
    'COALESCE(
        ep.start_date,
        DATE(ep.submitted_at),
        DATE(ep.created_at)
    )';


/*
|--------------------------------------------------------------------------
| COLLEGES
|--------------------------------------------------------------------------
*/

$colleges =
    $pdo
        ->query("
            SELECT
                college_id,
                college_name

            FROM colleges

            ORDER BY
                college_name ASC
        ")
        ->fetchAll(
            PDO::FETCH_ASSOC
        );


/*
|--------------------------------------------------------------------------
| DEPARTMENTS
|--------------------------------------------------------------------------
*/

$departments =
    $pdo
        ->query("
            SELECT
                d.department_id,
                d.department_name,
                c.college_name

            FROM departments d

            LEFT JOIN colleges c
                ON c.college_id =
                    d.college_id

            ORDER BY
                c.college_name ASC,
                d.department_name ASC
        ")
        ->fetchAll(
            PDO::FETCH_ASSOC
        );


/*
|--------------------------------------------------------------------------
| UNIT LABEL
|--------------------------------------------------------------------------
*/

$unitLabel =
    'All Colleges / Departments';


if (
    $unitType === 'college'
    &&
    $unitId > 0
) {

    foreach (
        $colleges
        as
        $college
    ) {

        if (
            (int)$college[
                'college_id'
            ]
            ===
            $unitId
        ) {

            $unitLabel =
                $college[
                    'college_name'
                ];

            break;
        }
    }
}


if (
    $unitType === 'department'
    &&
    $unitId > 0
) {

    foreach (
        $departments
        as
        $department
    ) {

        if (
            (int)$department[
                'department_id'
            ]
            ===
            $unitId
        ) {

            $unitLabel =
                $department[
                    'department_name'
                ];

            break;
        }
    }
}


/*
|--------------------------------------------------------------------------
| AVAILABLE YEARS
|--------------------------------------------------------------------------
*/

$yearValues = [];


if (
    $researchAccessSql
    !== '1 = 0'
) {

    $stmt =
        $pdo->prepare("
            SELECT DISTINCT

                YEAR(
                    {$researchDateExpression}
                ) AS report_year

            FROM research_proposals rp

            WHERE {$researchAccessSql}

              AND {$researchDateExpression}
                  IS NOT NULL
        ");


    $stmt->execute(
        $researchAccessParams
    );


    foreach (
        $stmt->fetchAll(
            PDO::FETCH_COLUMN
        )
        as
        $availableYear
    ) {

        if ($availableYear) {

            $yearValues[] =
                (int)$availableYear;
        }
    }
}


if (
    $extensionAccessSql
    !== '1 = 0'
) {

    $stmt =
        $pdo->prepare("
            SELECT DISTINCT

                YEAR(
                    {$extensionDateExpression}
                ) AS report_year

            FROM extension_programs ep

            WHERE {$extensionAccessSql}

              AND {$extensionDateExpression}
                  IS NOT NULL
        ");


    $stmt->execute(
        $extensionAccessParams
    );


    foreach (
        $stmt->fetchAll(
            PDO::FETCH_COLUMN
        )
        as
        $availableYear
    ) {

        if ($availableYear) {

            $yearValues[] =
                (int)$availableYear;
        }
    }
}


$yearValues =
    array_values(
        array_unique(
            $yearValues
        )
    );


rsort(
    $yearValues,
    SORT_NUMERIC
);


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

[
    $researchFilterSql,
    $researchFilterParams
] =
    reportModuleFilters(
        'rp',
        $researchDateExpression,
        $year,
        $status,
        $unitType,
        $unitId
    );


[
    $extensionFilterSql,
    $extensionFilterParams
] =
    reportModuleFilters(
        'ep',
        $extensionDateExpression,
        $year,
        $status,
        $unitType,
        $unitId
    );


$researchWhereSql =
    $researchAccessSql
    .
    $researchFilterSql;


$researchWhereParams =
    array_merge(
        $researchAccessParams,
        $researchFilterParams
    );


$extensionWhereSql =
    $extensionAccessSql
    .
    $extensionFilterSql;


$extensionWhereParams =
    array_merge(
        $extensionAccessParams,
        $extensionFilterParams
    );


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$totalResearchProjects =
    reportCount(
        $pdo,
        'research_proposals',
        'rp',
        $researchWhereSql,
        $researchWhereParams
    );


$totalExtensionPrograms =
    reportCount(
        $pdo,
        'extension_programs',
        'ep',
        $extensionWhereSql,
        $extensionWhereParams
    );


$totalParticipants =
    reportSum(
        $pdo,
        'extension_programs',
        'ep',
        'ep.target_participants',
        $extensionWhereSql,
        $extensionWhereParams
    );


$totalCompletedResearch =
    reportCount(
        $pdo,
        'research_proposals',
        'rp',
        $researchWhereSql,
        $researchWhereParams,
        "AND rp.status = 'Completed'"
    );


$totalCompletedExtension =
    reportCount(
        $pdo,
        'extension_programs',
        'ep',
        $extensionWhereSql,
        $extensionWhereParams,
        "AND ep.status = 'Completed'"
    );


$totalCompletedProjects =
    $totalCompletedResearch
    +
    $totalCompletedExtension;


/*
|--------------------------------------------------------------------------
| REPORT CARD COUNTS
|--------------------------------------------------------------------------
*/

$researchReportCount =
    $totalResearchProjects;


$extensionReportCount =
    $totalExtensionPrograms;


$participantReportCount =
    $totalParticipants;


/*
|--------------------------------------------------------------------------
| ACCOMPLISHMENT COUNT
|--------------------------------------------------------------------------
*/

$accomplishmentSql = "
    SELECT

        COUNT(
            DISTINCT
            ep.extension_id
        )

    FROM extension_programs ep

    INNER JOIN extension_documents ed

        ON ed.extension_id =
            ep.extension_id

       AND ed.document_type =
            'Accomplishment Report'

    WHERE {$extensionWhereSql}
";


$accomplishmentStmt =
    $pdo->prepare(
        $accomplishmentSql
    );


$accomplishmentStmt->execute(
    $extensionWhereParams
);


$accomplishmentReportCount =
    (int)$accomplishmentStmt
        ->fetchColumn();


/*
|--------------------------------------------------------------------------
| MONTHLY CHART
|--------------------------------------------------------------------------
*/

$chartYear =
    $year !== ''
        ? (int)$year
        : (
            $yearValues[0]
            ??
            (int)date('Y')
        );


$monthlyResearch =
    array_fill(
        0,
        12,
        0
    );


$monthlyExtension =
    array_fill(
        0,
        12,
        0
    );


[
    $chartResearchFilterSql,
    $chartResearchFilterParams
] =
    reportModuleFilters(
        'rp',
        $researchDateExpression,
        (string)$chartYear,
        $status,
        $unitType,
        $unitId
    );


$chartResearchSql = "
    SELECT

        MONTH(
            {$researchDateExpression}
        ) AS activity_month,

        COUNT(*) AS activity_total

    FROM research_proposals rp

    WHERE {$researchAccessSql}

    {$chartResearchFilterSql}

    GROUP BY

        MONTH(
            {$researchDateExpression}
        )
";


$chartResearchStmt =
    $pdo->prepare(
        $chartResearchSql
    );


$chartResearchStmt->execute(
    array_merge(
        $researchAccessParams,
        $chartResearchFilterParams
    )
);


foreach (
    $chartResearchStmt
        ->fetchAll(
            PDO::FETCH_ASSOC
        )
    as
    $chartRow
) {

    $monthNumber =
        (int)$chartRow[
            'activity_month'
        ];


    if (
        $monthNumber >= 1
        &&
        $monthNumber <= 12
    ) {

        $monthlyResearch[
            $monthNumber - 1
        ] =
            (int)$chartRow[
                'activity_total'
            ];
    }
}


/*
|--------------------------------------------------------------------------
| EXTENSION CHART
|--------------------------------------------------------------------------
*/

[
    $chartExtensionFilterSql,
    $chartExtensionFilterParams
] =
    reportModuleFilters(
        'ep',
        $extensionDateExpression,
        (string)$chartYear,
        $status,
        $unitType,
        $unitId
    );


$chartExtensionSql = "
    SELECT

        MONTH(
            {$extensionDateExpression}
        ) AS activity_month,

        COUNT(*) AS activity_total

    FROM extension_programs ep

    WHERE {$extensionAccessSql}

    {$chartExtensionFilterSql}

    GROUP BY

        MONTH(
            {$extensionDateExpression}
        )
";


$chartExtensionStmt =
    $pdo->prepare(
        $chartExtensionSql
    );


$chartExtensionStmt->execute(
    array_merge(
        $extensionAccessParams,
        $chartExtensionFilterParams
    )
);


foreach (
    $chartExtensionStmt
        ->fetchAll(
            PDO::FETCH_ASSOC
        )
    as
    $chartRow
) {

    $monthNumber =
        (int)$chartRow[
            'activity_month'
        ];


    if (
        $monthNumber >= 1
        &&
        $monthNumber <= 12
    ) {

        $monthlyExtension[
            $monthNumber - 1
        ] =
            (int)$chartRow[
                'activity_total'
            ];
    }
}


/*
|--------------------------------------------------------------------------
| GENERATED REPORT
|--------------------------------------------------------------------------
*/

$reportGenerated =
    $reportType !== '';


$generatedReportTitle = '';

$reportColumns = [];

$reportRows = [];

$reportNote = '';


if ($reportGenerated) {

    $generatedReportTitle =
        $allowedReportTypes[
            $reportType
        ]['label'];


    /*
    |--------------------------------------------------------------------------
    | RESEARCH PROJECTS / COMPLETED RESEARCH
    |--------------------------------------------------------------------------
    */

    if (
        in_array(
            $reportType,
            [
                'research_projects',
                'completed_research'
            ],
            true
        )
    ) {

        [
            $previewFilterSql,
            $previewFilterParams
        ] =
            reportModuleFilters(
                'rp',
                $researchDateExpression,
                $year,
                $status,
                $unitType,
                $unitId,
                $reportType
                !==
                'completed_research'
            );


        $extraStatusSql =
            $reportType
            ===
            'completed_research'

                ? "
                    AND rp.status =
                        'Completed'
                "

                : '';


        $sql = "
            SELECT

                rp.research_id,

                rp.research_title,

                rp.status,

                rp.progress_percentage,

                {$researchDateExpression}
                    AS report_date,

                u.first_name,

                u.middle_name,

                u.last_name,

                c.college_name,

                d.department_name

            FROM research_proposals rp

            INNER JOIN users u

                ON u.user_id =
                    rp.researcher_id

            LEFT JOIN colleges c

                ON c.college_id =
                    rp.college_id

            LEFT JOIN departments d

                ON d.department_id =
                    rp.department_id

            WHERE {$researchAccessSql}

            {$previewFilterSql}

            {$extraStatusSql}

            ORDER BY

                {$researchDateExpression}
                    DESC,

                rp.research_id DESC
        ";


        $stmt =
            $pdo->prepare($sql);


        $stmt->execute(
            array_merge(
                $researchAccessParams,
                $previewFilterParams
            )
        );


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            as
            $row
        ) {

            $reportRows[] = [

                'title' =>
                    $row[
                        'research_title'
                    ],

                'person' =>
                    reportPersonName(
                        $row
                    ),

                'unit' =>
                    trim(
                        (
                            $row[
                                'college_name'
                            ]
                            ?: 'Not assigned'
                        )
                        .
                        (
                            !empty(
                                $row[
                                    'department_name'
                                ]
                            )

                                ? ' / '
                                    .
                                    $row[
                                        'department_name'
                                    ]

                                : ''
                        )
                    ),

                'status' =>
                    $row['status'],

                'year' =>
                    !empty(
                        $row[
                            'report_date'
                        ]
                    )

                        ? date(
                            'Y',
                            strtotime(
                                $row[
                                    'report_date'
                                ]
                            )
                        )

                        : '—',

                'progress' =>
                    (int)$row[
                        'progress_percentage'
                    ]
                    .
                    '%'
            ];
        }


        $reportColumns = [

            'title' =>
                'Research Title',

            'person' =>
                'Researcher',

            'unit' =>
                'College / Department',

            'status' =>
                'Status',

            'year' =>
                'Year',

            'progress' =>
                'Progress'
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | RESEARCH STATUS
    |--------------------------------------------------------------------------
    */

    if (
        $reportType
        ===
        'research_status'
    ) {

        $sql = "
            SELECT

                rp.status,

                COUNT(*)
                    AS total_records

            FROM research_proposals rp

            WHERE {$researchWhereSql}

            GROUP BY
                rp.status

            ORDER BY
                total_records DESC,
                rp.status ASC
        ";


        $stmt =
            $pdo->prepare($sql);


        $stmt->execute(
            $researchWhereParams
        );


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            as
            $row
        ) {

            $reportRows[] = [

                'status' =>
                    $row['status'],

                'records' =>
                    (int)$row[
                        'total_records'
                    ]
            ];
        }


        $reportColumns = [

            'status' =>
                'Research Status',

            'records' =>
                'Number of Records'
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | EXTENSION PROGRAMS
    |--------------------------------------------------------------------------
    */

    if (
        $reportType
        ===
        'extension_programs'
    ) {

        $sql = "
            SELECT

                ep.extension_id,

                ep.program_title,

                ep.target_community,

                ep.target_participants,

                ep.status,

                ep.progress_percentage,

                {$extensionDateExpression}
                    AS report_date,

                u.first_name,

                u.middle_name,

                u.last_name,

                c.college_name,

                d.department_name

            FROM extension_programs ep

            INNER JOIN users u

                ON u.user_id =
                    ep.coordinator_id

            LEFT JOIN colleges c

                ON c.college_id =
                    ep.college_id

            LEFT JOIN departments d

                ON d.department_id =
                    ep.department_id

            WHERE {$extensionWhereSql}

            ORDER BY

                {$extensionDateExpression}
                    DESC,

                ep.extension_id DESC
        ";


        $stmt =
            $pdo->prepare($sql);


        $stmt->execute(
            $extensionWhereParams
        );


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            as
            $row
        ) {

            $reportRows[] = [

                'title' =>
                    $row[
                        'program_title'
                    ],

                'person' =>
                    reportPersonName(
                        $row
                    ),

                'community' =>
                    $row[
                        'target_community'
                    ]
                    ?: '—',

                'participants' =>
                    (int)(
                        $row[
                            'target_participants'
                        ]
                        ?? 0
                    ),

                'status' =>
                    $row['status'],

                'year' =>
                    !empty(
                        $row[
                            'report_date'
                        ]
                    )

                        ? date(
                            'Y',
                            strtotime(
                                $row[
                                    'report_date'
                                ]
                            )
                        )

                        : '—'
            ];
        }


        $reportColumns = [

            'title' =>
                'Extension Program',

            'person' =>
                'Coordinator',

            'community' =>
                'Target Community',

            'participants' =>
                'Target Participants',

            'status' =>
                'Status',

            'year' =>
                'Year'
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | EXTENSION PARTICIPANTS
    |--------------------------------------------------------------------------
    */

    if (
        $reportType
        ===
        'extension_participants'
    ) {

        $sql = "
            SELECT

                ep.program_title,

                ep.target_community,

                ep.municipality,

                ep.target_participants,

                ep.status,

                {$extensionDateExpression}
                    AS report_date,

                c.college_name,

                d.department_name

            FROM extension_programs ep

            LEFT JOIN colleges c

                ON c.college_id =
                    ep.college_id

            LEFT JOIN departments d

                ON d.department_id =
                    ep.department_id

            WHERE {$extensionWhereSql}

            ORDER BY

                {$extensionDateExpression}
                    DESC,

                ep.extension_id DESC
        ";


        $stmt =
            $pdo->prepare($sql);


        $stmt->execute(
            $extensionWhereParams
        );


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            as
            $row
        ) {

            $reportRows[] = [

                'title' =>
                    $row[
                        'program_title'
                    ],

                'community' =>
                    trim(
                        (
                            $row[
                                'target_community'
                            ]
                            ?: '—'
                        )
                        .
                        (
                            !empty(
                                $row[
                                    'municipality'
                                ]
                            )

                                ? ', '
                                    .
                                    $row[
                                        'municipality'
                                    ]

                                : ''
                        )
                    ),

                'participants' =>
                    (int)(
                        $row[
                            'target_participants'
                        ]
                        ?? 0
                    ),

                'status' =>
                    $row['status'],

                'year' =>
                    !empty(
                        $row[
                            'report_date'
                        ]
                    )

                        ? date(
                            'Y',
                            strtotime(
                                $row[
                                    'report_date'
                                ]
                            )
                        )

                        : '—'
            ];
        }


        $reportColumns = [

            'title' =>
                'Extension Program',

            'community' =>
                'Community / Municipality',

            'participants' =>
                'Target Participants',

            'status' =>
                'Status',

            'year' =>
                'Year'
        ];


        $reportNote =
            'Participant attendance records are not yet stored in a dedicated participant table. This report uses actual target participant values already saved in extension records.';
    }


    /*
    |--------------------------------------------------------------------------
    | EXTENSION ACCOMPLISHMENTS
    |--------------------------------------------------------------------------
    */

    if (
        $reportType
        ===
        'extension_accomplishments'
    ) {

        [
            $previewFilterSql,
            $previewFilterParams
        ] =
            reportModuleFilters(
                'ep',
                $extensionDateExpression,
                $year,
                $status,
                $unitType,
                $unitId,
                false
            );


        $sql = "
            SELECT

                ep.extension_id,

                ep.program_title,

                ep.target_community,

                ep.status,

                ep.completed_at,

                {$extensionDateExpression}
                    AS report_date,

                COUNT(
                    CASE

                        WHEN
                            ed.document_type
                            =
                            'Accomplishment Report'

                        THEN
                            ed.document_id

                    END
                )
                AS accomplishment_documents

            FROM extension_programs ep

            LEFT JOIN extension_documents ed

                ON ed.extension_id =
                    ep.extension_id

            WHERE {$extensionAccessSql}

            {$previewFilterSql}

              AND ep.status =
                    'Completed'

            GROUP BY

                ep.extension_id,

                ep.program_title,

                ep.target_community,

                ep.status,

                ep.completed_at,

                {$extensionDateExpression}

            ORDER BY

                ep.completed_at DESC,

                ep.extension_id DESC
        ";


        $stmt =
            $pdo->prepare($sql);


        $stmt->execute(
            array_merge(
                $extensionAccessParams,
                $previewFilterParams
            )
        );


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            )
            as
            $row
        ) {

            $reportRows[] = [

                'title' =>
                    $row[
                        'program_title'
                    ],

                'community' =>
                    $row[
                        'target_community'
                    ]
                    ?: '—',

                'status' =>
                    $row['status'],

                'completed' =>
                    !empty(
                        $row[
                            'completed_at'
                        ]
                    )

                        ? date(
                            'M d, Y',
                            strtotime(
                                $row[
                                    'completed_at'
                                ]
                            )
                        )

                        : '—',

                'documents' =>
                    (int)$row[
                        'accomplishment_documents'
                    ]
            ];
        }


        $reportColumns = [

            'title' =>
                'Extension Program',

            'community' =>
                'Target Community',

            'status' =>
                'Status',

            'completed' =>
                'Completed Date',

            'documents' =>
                'Accomplishment Files'
        ];


        $reportNote =
            'This report uses completed extension programs and actual uploaded accomplishment report files.';
    }


    /*
    |--------------------------------------------------------------------------
    | ANNUAL SUMMARY
    |--------------------------------------------------------------------------
    */

    if (
        $reportType
        ===
        'annual_summary'
    ) {

        $researchApproved =
            reportCount(
                $pdo,
                'research_proposals',
                'rp',
                $researchWhereSql,
                $researchWhereParams,
                "AND rp.status = 'Approved'"
            );


        $researchOngoing =
            reportCount(
                $pdo,
                'research_proposals',
                'rp',
                $researchWhereSql,
                $researchWhereParams,
                "AND rp.status = 'Ongoing'"
            );


        $extensionApproved =
            reportCount(
                $pdo,
                'extension_programs',
                'ep',
                $extensionWhereSql,
                $extensionWhereParams,
                "AND ep.status = 'Approved'"
            );


        $extensionOngoing =
            reportCount(
                $pdo,
                'extension_programs',
                'ep',
                $extensionWhereSql,
                $extensionWhereParams,
                "AND ep.status = 'Ongoing'"
            );


        $reportRows = [

            [

                'module' =>
                    'Research',

                'total' =>
                    $totalResearchProjects,

                'approved' =>
                    $researchApproved,

                'ongoing' =>
                    $researchOngoing,

                'completed' =>
                    $totalCompletedResearch,

                'participants' =>
                    '—'
            ],

            [

                'module' =>
                    'Extension',

                'total' =>
                    $totalExtensionPrograms,

                'approved' =>
                    $extensionApproved,

                'ongoing' =>
                    $extensionOngoing,

                'completed' =>
                    $totalCompletedExtension,

                'participants' =>
                    $totalParticipants
            ]
        ];


        $reportColumns = [

            'module' =>
                'Module',

            'total' =>
                'Total Records',

            'approved' =>
                'Approved',

            'ongoing' =>
                'Ongoing',

            'completed' =>
                'Completed',

            'participants' =>
                'Target Participants'
        ];
    }
}


/*
|--------------------------------------------------------------------------
| CSV EXPORT
|--------------------------------------------------------------------------
*/

if (
    $reportGenerated
    &&
    (
        $_GET['export']
        ?? ''
    )
    ===
    'csv'
) {

    $safeFileName =
        preg_replace(
            '/[^a-z0-9]+/i',
            '_',
            strtolower(
                $generatedReportTitle
            )
        );


    $safeFileName =
        trim(
            $safeFileName,
            '_'
        );


    header(
        'Content-Type: text/csv; charset=UTF-8'
    );


    header(
        'Content-Disposition: attachment; filename="'
        .
        $safeFileName
        .
        '_'
        .
        date('Ymd_His')
        .
        '.csv"'
    );


    $output =
        fopen(
            'php://output',
            'w'
        );


    fwrite(
        $output,
        "\xEF\xBB\xBF"
    );


    fputcsv(
        $output,
        array_values(
            $reportColumns
        )
    );


    foreach (
        $reportRows
        as
        $row
    ) {

        $csvRow = [];


        foreach (
            array_keys(
                $reportColumns
            )
            as
            $columnKey
        ) {

            $csvRow[] =
                $row[$columnKey]
                ?? '';
        }


        fputcsv(
            $output,
            $csvRow
        );
    }


    fclose(
        $output
    );


    exit;
}


/*
|--------------------------------------------------------------------------
| INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';


if (
    !empty(
        $user[
            'first_name'
        ]
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user[
                    'first_name'
                ],
                0,
                1
            )
        );
}


if (
    !empty(
        $user[
            'last_name'
        ]
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user[
                    'last_name'
                ],
                0,
                1
            )
        );
}


/*
|--------------------------------------------------------------------------
| SCOPE DESCRIPTION
|--------------------------------------------------------------------------
*/

$scopeText =
    match ($userRole) {

        'admin' =>
            'Institutional reports exclude private Draft records.',

        'rps' =>
            'Research reports include authorized institutional research records processed by the Research Office.',

        'faculty' =>
            'Reports are limited to your own research records.',

        'extension_coordinator' =>
            'Reports are limited to extension programs assigned to your account.',

        default =>
            'Reports are limited to authorized records.'
    };


/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

require __DIR__ . '/../includes/header.php';

require __DIR__ . '/../includes/sidebar.php';

?>


<style>

.reports-scope-note {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 8px;
    color: #6f7a71;
    font-size: 10px;
}


.report-filter-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}


.report-chart-wrap {
    padding: 14px 18px 18px;
}


.report-chart-canvas {
    position: relative;

    height: 260px;
    max-height: 260px;
}


.report-chart-canvas canvas {
    width: 100% !important;
    height: 100% !important;
}


@media (
    max-width: 768px
) {

    .report-chart-canvas {

        height: 220px;
        max-height: 220px;
    }
}


.report-chart-meta {

    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 12px;

    margin-bottom: 12px;

    color: #778079;

    font-size: 10px;
}


.report-card-link {

    color: inherit;

    text-decoration: none;
}


.report-card-link:hover {

    color: inherit;
}


.report-card-clickable {

    transition:
        transform .16s ease,
        box-shadow .16s ease,
        border-color .16s ease;
}


.report-card-clickable:hover {

    transform:
        translateY(-1px);

    border-color:
        #cddbcf;

    box-shadow:
        0 7px 20px
        rgba(
            31,
            74,
            39,
            .07
        );
}


.report-card {

    display: flex;
    align-items: center;

    gap: 14px;
}


.report-card h6 {

    margin: 0 0 3px;

    font-size: 12px;
    font-weight: 700;
}


.report-card p {

    margin: 0;

    color: #7b847d;

    font-size: 9px;

    line-height: 1.5;
}


.report-preview-head {

    display: flex;

    align-items:
        flex-start;

    justify-content:
        space-between;

    gap: 18px;

    padding: 20px;

    border-bottom:
        1px solid
        #edf1ed;
}


.report-preview-head h3 {

    margin: 0 0 5px;

    color: #283029;

    font-size: 15px;

    font-weight: 700;
}


.report-preview-meta {

    display: flex;

    flex-wrap: wrap;

    gap:
        6px
        16px;

    color: #7b847d;

    font-size: 9px;
}


.report-preview-actions {

    display: flex;

    flex-wrap: wrap;

    gap: 8px;
}


.report-note {

    margin:
        16px
        20px
        0;

    padding:
        11px
        13px;

    border-left:
        3px solid
        #d5aa13;

    border-radius: 6px;

    background:
        #fff9df;

    color:
        #6c6135;

    font-size: 9px;

    line-height: 1.6;
}


.report-table-wrap {

    overflow-x: auto;

    padding:
        18px
        20px
        20px;
}


.report-table {

    min-width: 760px;

    margin: 0;

    font-size: 10px;
}


.report-table
thead th {

    border-bottom-width:
        1px;

    color:
        #667067;

    font-size:
        9px;

    font-weight:
        700;

    text-transform:
        uppercase;

    letter-spacing:
        .035em;

    white-space:
        nowrap;
}


.report-table td {

    vertical-align:
        middle;

    color:
        #3e4740;
}


.report-table .badge {

    font-size: 8px;

    font-weight: 700;
}


.report-zero-state {

    padding:
        44px
        20px;

    text-align:
        center;

    color:
        #7f8981;
}


.report-zero-state i {

    display: block;

    margin-bottom:
        12px;

    color:
        #a3ada5;

    font-size:
        28px;
}


.report-zero-state h3 {

    margin-bottom:
        6px;

    color:
        #3d473f;

    font-size:
        14px;
}


@media print {

    .asu-sidebar,
    .asu-topbar,
    .page-heading,
    .filter-card,
    .stats-row,
    .reports-upper-row,
    .design-notice,
    .content-footer,
    .report-preview-actions,
    #sidebarToggle {

        display:
            none !important;
    }


    .main-page,
    .page-content {

        margin:
            0 !important;

        padding:
            0 !important;

        width:
            100% !important;

        max-width:
            none !important;
    }


    .asu-panel {

        border:
            0 !important;

        box-shadow:
            none !important;
    }


    .report-table-wrap {

        overflow:
            visible !important;
    }


    .report-table {

        min-width:
            0 !important;

        width:
            100% !important;
    }
}

</style>


<div class="main-page">


    <!-- TOPBAR -->

    <header class="asu-topbar">


        <div class="topbar-left">


            <button
                id="sidebarToggle"
                class="sidebar-toggle"
                type="button"
                aria-label="Open navigation"
            >

                <i class="bi bi-list"></i>

            </button>


            <span class="system-name">

                Research & Extension Management System

            </span>


        </div>



        <div class="topbar-user">


            <div class="topbar-user-text">


                <strong>

                    <?= e(
                        fullName($user)
                    ); ?>

                </strong>


                <span>

                    <?= e(
                        $displayRole
                    ); ?>

                </span>


            </div>



            <div class="dropdown">


                <button
                    type="button"
                    class="user-dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >

                    <div class="user-avatar">

                        <?= e(
                            $initials
                        ); ?>

                    </div>

                </button>


                <ul
                    class="
                        dropdown-menu
                        dropdown-menu-end
                    "
                >


                    <li>

                        <div
                            class="
                                dropdown-item-text
                            "
                        >

                            <strong class="d-block">

                                <?= e(
                                    fullName($user)
                                ); ?>

                            </strong>


                            <small class="text-muted">

                                <?= e(
                                    $user['email']
                                ); ?>

                            </small>

                        </div>

                    </li>


                    <li>

                        <hr class="dropdown-divider">

                    </li>


                    <li>

                        <a
                            href="<?= BASE_URL; ?>/logout.php"
                            class="dropdown-item"
                        >

                            <i
                                class="
                                    bi
                                    bi-box-arrow-right
                                    me-2
                                "
                            ></i>

                            Logout

                        </a>

                    </li>


                </ul>


            </div>


        </div>


    </header>



    <!-- CONTENT -->

    <main class="page-content">


        <?php if (
            !$reportGenerated
        ): ?>


            <!-- PAGE HEADING -->

            <div class="page-heading">


                <div>


                    <h1>

                        Reports & Analytics

                    </h1>


                    <p>

                        Generate descriptive research
                        and extension reports from
                        actual ASU-REMS records.

                    </p>


                    <span class="reports-scope-note">

                        <i class="bi bi-shield-check"></i>

                        <?= e(
                            $scopeText
                        ); ?>

                    </span>


                </div>


            </div>



            <!-- FILTERS -->

            <section class="filter-card">


                <form
                    method="get"
                    action=""
                    id="reportFilterForm"
                >


                    <div class="row g-3">


                        <!-- REPORT TYPE -->

                        <div class="col-lg-3">


                            <label
                                for="reportType"
                                class="form-label small"
                            >

                                Report Type

                            </label>


                            <select
                                id="reportType"
                                name="report_type"
                                class="form-select"
                                required
                            >


                                <option value="">

                                    Select Report Type

                                </option>


                                <?php foreach (
                                    $allowedReportTypes
                                    as
                                    $key =>
                                    $definition
                                ): ?>


                                    <option
                                        value="<?= e($key); ?>"
                                        <?= $reportType === $key
                                            ? 'selected'
                                            : ''; ?>
                                    >

                                        <?= e(
                                            $definition[
                                                'label'
                                            ]
                                        ); ?>

                                    </option>


                                <?php endforeach; ?>


                            </select>


                        </div>



                        <!-- YEAR -->

                        <div class="col-lg-3">


                            <label
                                for="reportYear"
                                class="form-label small"
                            >

                                Year

                            </label>


                            <select
                                id="reportYear"
                                name="year"
                                class="form-select"
                            >


                                <option value="">

                                    All Years

                                </option>


                                <?php foreach (
                                    $yearValues
                                    as
                                    $availableYear
                                ): ?>


                                    <option
                                        value="<?= (int)$availableYear; ?>"
                                        <?= $year ===
                                            (string)$availableYear
                                            ? 'selected'
                                            : ''; ?>
                                    >

                                        <?= (int)$availableYear; ?>

                                    </option>


                                <?php endforeach; ?>


                            </select>


                        </div>



                        <!-- STATUS -->

                        <div class="col-lg-3">


                            <label
                                for="reportStatus"
                                class="form-label small"
                            >

                                Status

                            </label>


                            <select
                                id="reportStatus"
                                name="status"
                                class="form-select"
                            >


                                <option value="">

                                    All Status

                                </option>


                                <?php foreach (
                                    $validStatuses
                                    as
                                    $availableStatus
                                ): ?>


                                    <?php

                                    if (
                                        in_array(
                                            $userRole,
                                            [
                                                'admin',
                                                'rps'
                                            ],
                                            true
                                        )
                                        &&
                                        $availableStatus
                                        ===
                                        'Draft'
                                    ) {

                                        continue;
                                    }

                                    ?>


                                    <option
                                        value="<?= e(
                                            $availableStatus
                                        ); ?>"
                                        <?= $status ===
                                            $availableStatus
                                            ? 'selected'
                                            : ''; ?>
                                    >

                                        <?= e(
                                            $availableStatus
                                        ); ?>

                                    </option>


                                <?php endforeach; ?>


                            </select>


                        </div>



                        <!-- UNIT -->

                        <div class="col-lg-3">


                            <label
                                for="reportUnit"
                                class="form-label small"
                            >

                                College / Department

                            </label>


                            <select
                                id="reportUnit"
                                name="unit"
                                class="form-select"
                            >


                                <option value="">

                                    All Colleges / Departments

                                </option>


                                <?php if ($colleges): ?>


                                    <optgroup label="Colleges">


                                        <?php foreach (
                                            $colleges
                                            as
                                            $college
                                        ): ?>


                                            <?php

                                            $value =
                                                'college:'
                                                .
                                                (int)$college[
                                                    'college_id'
                                                ];

                                            ?>


                                            <option
                                                value="<?= e($value); ?>"
                                                <?= $unit === $value
                                                    ? 'selected'
                                                    : ''; ?>
                                            >

                                                <?= e(
                                                    $college[
                                                        'college_name'
                                                    ]
                                                ); ?>

                                            </option>


                                        <?php endforeach; ?>


                                    </optgroup>


                                <?php endif; ?>



                                <?php if ($departments): ?>


                                    <optgroup label="Departments">


                                        <?php foreach (
                                            $departments
                                            as
                                            $department
                                        ): ?>


                                            <?php

                                            $value =
                                                'department:'
                                                .
                                                (int)$department[
                                                    'department_id'
                                                ];

                                            ?>


                                            <option
                                                value="<?= e($value); ?>"
                                                <?= $unit === $value
                                                    ? 'selected'
                                                    : ''; ?>
                                            >

                                                <?= e(
                                                    $department[
                                                        'department_name'
                                                    ]
                                                    .
                                                    (
                                                        !empty(
                                                            $department[
                                                                'college_name'
                                                            ]
                                                        )

                                                            ? ' — '
                                                                .
                                                                $department[
                                                                    'college_name'
                                                                ]

                                                            : ''
                                                    )
                                                ); ?>

                                            </option>


                                        <?php endforeach; ?>


                                    </optgroup>


                                <?php endif; ?>


                            </select>


                        </div>



                        <!-- BUTTONS -->

                        <div class="col-12">


                            <div class="report-filter-actions">


                                <button
                                    id="generateReportButton"
                                    type="submit"
                                    class="btn btn-asu"
                                    <?= $reportType === ''
                                        ? 'disabled'
                                        : ''; ?>
                                >

                                    <i
                                        class="
                                            bi
                                            bi-bar-chart
                                            me-1
                                        "
                                    ></i>

                                    Generate Report

                                </button>


                                <a
                                    href="<?= BASE_URL; ?>/reports/index.php"
                                    class="
                                        btn
                                        btn-outline-asu
                                    "
                                >

                                    <i
                                        class="
                                            bi
                                            bi-arrow-counterclockwise
                                            me-1
                                        "
                                    ></i>

                                    Reset Filters

                                </a>


                            </div>


                        </div>


                    </div>


                </form>


            </section>



            <!-- STATISTICS -->

            <section class="stats-row">


                <div class="stat-card">


                    <div class="stat-icon green">

                        <i class="bi bi-journal-text"></i>

                    </div>


                    <div class="stat-content">

                        <strong>

                            <?= number_format(
                                $totalResearchProjects
                            ); ?>

                        </strong>

                        <span>

                            Research Projects

                        </span>

                    </div>


                </div>



                <div class="stat-card">


                    <div class="stat-icon yellow">

                        <i class="bi bi-megaphone"></i>

                    </div>


                    <div class="stat-content">

                        <strong>

                            <?= number_format(
                                $totalExtensionPrograms
                            ); ?>

                        </strong>

                        <span>

                            Extension Programs

                        </span>

                    </div>


                </div>



                <div class="stat-card">


                    <div class="stat-icon green">

                        <i class="bi bi-people"></i>

                    </div>


                    <div class="stat-content">

                        <strong>

                            <?= number_format(
                                $totalParticipants
                            ); ?>

                        </strong>

                        <span>

                            Target Participants

                        </span>

                    </div>


                </div>



                <div class="stat-card">


                    <div class="stat-icon yellow">

                        <i class="bi bi-check-circle"></i>

                    </div>


                    <div class="stat-content">

                        <strong>

                            <?= number_format(
                                $totalCompletedProjects
                            ); ?>

                        </strong>

                        <span>

                            Completed Projects

                        </span>

                    </div>


                </div>


            </section>



            <!-- CHART -->

            <div
                class="
                    row
                    g-4
                    reports-upper-row
                "
            >


                <div class="col-12">


                    <section class="asu-panel">


                        <div class="panel-header">


                            <h2 class="panel-title">

                                <span class="panel-title-icon">

                                    <i class="bi bi-graph-up"></i>

                                </span>

                                Monthly Research & Extension Activities

                            </h2>


                        </div>


                        <div class="report-chart-wrap">


                            <div class="report-chart-meta">

                                <span>

                                    Activity year:

                                    <strong>

                                        <?= (int)$chartYear; ?>

                                    </strong>

                                </span>


                                <span>

                                    <?= e(
                                        $unitLabel
                                    ); ?>

                                </span>

                            </div>


                            <div class="report-chart-canvas">

                                <canvas
                                    id="monthlyActivityChart"
                                ></canvas>

                            </div>


                        </div>


                    </section>


                </div>



                <!-- AVAILABLE REPORTS -->

                <div class="col-12">


                    <section class="asu-panel">


                        <div class="panel-header">


                            <h2 class="panel-title">

                                <span class="panel-title-icon">

                                    <i
                                        class="
                                            bi
                                            bi-file-earmark-bar-graph
                                        "
                                    ></i>

                                </span>

                                Available Reports

                            </h2>


                        </div>



                        <div class="panel-body">


                            <?php if (
                                isset(
                                    $allowedReportTypes[
                                        'research_projects'
                                    ]
                                )
                            ): ?>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'research_projects',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-journal-text"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Research Projects Report
                                            </h6>

                                            <p>
                                                Summary of authorized research records.
                                            </p>

                                        </div>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:#eef3ef;
                                                color:#607267;
                                            "
                                        >

                                            <?= number_format(
                                                $researchReportCount
                                            ); ?>

                                            records

                                        </span>


                                    </div>


                                </a>


                            <?php endif; ?>



                            <?php if (
                                isset(
                                    $allowedReportTypes[
                                        'research_status'
                                    ]
                                )
                            ): ?>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'research_status',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-list-check"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Research Status Report
                                            </h6>

                                            <p>
                                                Summary of research records grouped by status.
                                            </p>

                                        </div>


                                    </div>


                                </a>


                            <?php endif; ?>



                            <?php if (
                                isset(
                                    $allowedReportTypes[
                                        'completed_research'
                                    ]
                                )
                            ): ?>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'completed_research',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                '',
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i
                                                class="
                                                    bi
                                                    bi-check-circle
                                                "
                                            ></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Completed Research Report
                                            </h6>

                                            <p>
                                                Completed research records available to your role.
                                            </p>

                                        </div>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:#eef3ef;
                                                color:#607267;
                                            "
                                        >

                                            <?= number_format(
                                                $totalCompletedResearch
                                            ); ?>

                                            records

                                        </span>


                                    </div>


                                </a>


                            <?php endif; ?>



                            <?php if (
                                isset(
                                    $allowedReportTypes[
                                        'extension_programs'
                                    ]
                                )
                            ): ?>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'extension_programs',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-megaphone"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Extension Programs Report
                                            </h6>

                                            <p>
                                                Summary of extension implementation records.
                                            </p>

                                        </div>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:#eef3ef;
                                                color:#607267;
                                            "
                                        >

                                            <?= number_format(
                                                $extensionReportCount
                                            ); ?>

                                            records

                                        </span>


                                    </div>


                                </a>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'extension_participants',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-people"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Extension Participant Report
                                            </h6>

                                            <p>
                                                Aggregate target participant values.
                                            </p>

                                        </div>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:#eef3ef;
                                                color:#607267;
                                            "
                                        >

                                            <?= number_format(
                                                $participantReportCount
                                            ); ?>

                                            target

                                        </span>


                                    </div>


                                </a>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'extension_accomplishments',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                            mb-3
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-check2-square"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Extension Accomplishment Report
                                            </h6>

                                            <p>
                                                Completed programs with uploaded accomplishment files.
                                            </p>

                                        </div>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:#eef3ef;
                                                color:#607267;
                                            "
                                        >

                                            <?= number_format(
                                                $accomplishmentReportCount
                                            ); ?>

                                            with files

                                        </span>


                                    </div>


                                </a>


                            <?php endif; ?>



                            <?php if (
                                isset(
                                    $allowedReportTypes[
                                        'annual_summary'
                                    ]
                                )
                            ): ?>


                                <a
                                    class="report-card-link"
                                    href="?<?= e(
                                        http_build_query([
                                            'report_type' =>
                                                'annual_summary',
                                            'year' =>
                                                $year,
                                            'status' =>
                                                $status,
                                            'unit' =>
                                                $unit
                                        ])
                                    ); ?>#reportPreview"
                                >


                                    <div
                                        class="
                                            report-card
                                            report-card-clickable
                                        "
                                    >


                                        <div class="report-card-icon">

                                            <i class="bi bi-calendar3"></i>

                                        </div>


                                        <div class="flex-grow-1">

                                            <h6>
                                                Annual Summary
                                            </h6>

                                            <p>
                                                Combined institutional research and extension summary.
                                            </p>

                                        </div>


                                    </div>


                                </a>


                            <?php endif; ?>


                        </div>


                    </section>


                </div>


            </div>


        <?php endif; ?>



        <!-- REPORT PREVIEW -->

        <?php if (
            $reportGenerated
        ): ?>


            <section
                class="
                    asu-panel
                    mt-4
                "
                id="reportPreview"
            >


                <div class="panel-header">


                    <h2 class="panel-title">

                        <span class="panel-title-icon">

                            <i
                                class="
                                    bi
                                    bi-file-earmark-text
                                "
                            ></i>

                        </span>

                        <?= e(
                            $generatedReportTitle
                        ); ?>

                    </h2>


                    <a
                        href="<?= BASE_URL; ?>/reports/index.php"
                        class="
                            btn
                            btn-outline-asu
                            btn-sm
                        "
                    >

                        <i
                            class="
                                bi
                                bi-arrow-left
                                me-1
                            "
                        ></i>

                        Back to Reports

                    </a>


                </div>



                <div class="report-preview-head">


                    <div>


                        <h3>

                            <?= e(
                                $generatedReportTitle
                            ); ?>

                        </h3>


                        <div class="report-preview-meta">


                            <span>

                                <i
                                    class="
                                        bi
                                        bi-calendar3
                                        me-1
                                    "
                                ></i>

                                Year:

                                <?= $year !== ''
                                    ? e($year)
                                    : 'All Years'; ?>

                            </span>


                            <span>

                                <i
                                    class="
                                        bi
                                        bi-funnel
                                        me-1
                                    "
                                ></i>

                                Status:

                                <?= $status !== ''
                                    ? e($status)
                                    : 'All Status'; ?>

                            </span>


                            <span>

                                <i
                                    class="
                                        bi
                                        bi-building
                                        me-1
                                    "
                                ></i>

                                <?= e(
                                    $unitLabel
                                ); ?>

                            </span>


                            <span>

                                <i
                                    class="
                                        bi
                                        bi-clock
                                        me-1
                                    "
                                ></i>

                                Generated:

                                <?= e(
                                    date(
                                        'M d, Y h:i A'
                                    )
                                ); ?>

                            </span>


                        </div>


                    </div>



                    <div class="report-preview-actions">


                        <button
                            type="button"
                            class="
                                btn
                                btn-outline-asu
                                btn-sm
                            "
                            onclick="window.print()"
                        >

                            <i
                                class="
                                    bi
                                    bi-printer
                                    me-1
                                "
                            ></i>

                            Print / Save PDF

                        </button>


                        <a
                            href="?<?= e(
                                http_build_query([
                                    'report_type' =>
                                        $reportType,
                                    'year' =>
                                        $year,
                                    'status' =>
                                        $status,
                                    'unit' =>
                                        $unit,
                                    'export' =>
                                        'csv'
                                ])
                            ); ?>"
                            class="
                                btn
                                btn-asu
                                btn-sm
                            "
                        >

                            <i
                                class="
                                    bi
                                    bi-file-earmark-spreadsheet
                                    me-1
                                "
                            ></i>

                            Export CSV

                        </a>


                    </div>


                </div>



                <?php if (
                    $reportNote !== ''
                ): ?>


                    <div class="report-note">

                        <i
                            class="
                                bi
                                bi-info-circle
                                me-1
                            "
                        ></i>

                        <?= e(
                            $reportNote
                        ); ?>

                    </div>


                <?php endif; ?>



                <?php if (
                    !$reportRows
                ): ?>


                    <div class="report-zero-state">


                        <i class="bi bi-inbox"></i>


                        <h3>

                            No records found

                        </h3>


                        <p class="mb-0">

                            No authorized records matched the selected report criteria.

                        </p>


                    </div>


                <?php else: ?>


                    <div class="report-table-wrap">


                        <table
                            class="
                                table
                                table-hover
                                report-table
                            "
                        >


                            <thead>


                                <tr>


                                    <?php foreach (
                                        $reportColumns
                                        as
                                        $columnLabel
                                    ): ?>


                                        <th>

                                            <?= e(
                                                $columnLabel
                                            ); ?>

                                        </th>


                                    <?php endforeach; ?>


                                </tr>


                            </thead>



                            <tbody>


                                <?php foreach (
                                    $reportRows
                                    as
                                    $row
                                ): ?>


                                    <tr>


                                        <?php foreach (
                                            $reportColumns
                                            as
                                            $columnKey =>
                                            $columnLabel
                                        ): ?>


                                            <td>


                                                <?php if (
                                                    $columnKey
                                                    ===
                                                    'status'
                                                ): ?>


                                                    <span
                                                        class="
                                                            badge
                                                            <?= e(
                                                                reportStatusBadgeClass(
                                                                    (string)(
                                                                        $row[
                                                                            $columnKey
                                                                        ]
                                                                        ?? ''
                                                                    )
                                                                )
                                                            ); ?>
                                                        "
                                                    >

                                                        <?= e(
                                                            (string)(
                                                                $row[
                                                                    $columnKey
                                                                ]
                                                                ?? '—'
                                                            )
                                                        ); ?>

                                                    </span>


                                                <?php else: ?>


                                                    <?= e(
                                                        (string)(
                                                            $row[
                                                                $columnKey
                                                            ]
                                                            ?? '—'
                                                        )
                                                    ); ?>


                                                <?php endif; ?>


                                            </td>


                                        <?php endforeach; ?>


                                    </tr>


                                <?php endforeach; ?>


                            </tbody>


                        </table>


                    </div>


                <?php endif; ?>


            </section>


        <?php endif; ?>



        <?php if (
            !$reportGenerated
        ): ?>


            <div class="design-notice">


                <strong>

                    Reports Module:

                </strong>

                Statistics, filters and descriptive
                charts use actual MySQL records
                available to the logged-in user.


            </div>


        <?php endif; ?>



        <footer class="content-footer">


            <span>

                © <?= date('Y'); ?>
                Aklan State University

            </span>


            <span class="footer-divider">
                •
            </span>


            <span>

                Research & Extension Management System

            </span>


        </footer>


    </main>


</div>


<script
    src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"
></script>


<script>

document.addEventListener(
    'DOMContentLoaded',
    function () {


        /*
        |--------------------------------------------------------------------------
        | REPORT BUTTON
        |--------------------------------------------------------------------------
        */

        const reportType =
            document.getElementById(
                'reportType'
            );


        const generateButton =
            document.getElementById(
                'generateReportButton'
            );


        if (
            reportType
            &&
            generateButton
        ) {

            const updateGenerateButton =
                function () {

                    generateButton.disabled =
                        reportType.value === '';
                };


            reportType.addEventListener(
                'change',
                updateGenerateButton
            );


            updateGenerateButton();
        }


        /*
        |--------------------------------------------------------------------------
        | CHART
        |--------------------------------------------------------------------------
        */

        const chartCanvas =
            document.getElementById(
                'monthlyActivityChart'
            );


        if (
            chartCanvas
            &&
            typeof Chart
                !== 'undefined'
        ) {

            new Chart(
                chartCanvas,
                {

                    type: 'line',

                    data: {

                        labels: [

                            'Jan',
                            'Feb',
                            'Mar',
                            'Apr',
                            'May',
                            'Jun',
                            'Jul',
                            'Aug',
                            'Sep',
                            'Oct',
                            'Nov',
                            'Dec'
                        ],

                        datasets: [

                            {

                                label:
                                    'Research',

                                data:
                                    <?= json_encode(
                                        $monthlyResearch
                                    ); ?>,

                                borderColor:
                                    'rgba(8, 117, 44, 1)',

                                backgroundColor:
                                    'rgba(8, 117, 44, 0.10)',

                                borderWidth:
                                    3,

                                pointRadius:
                                    4,

                                tension:
                                    0.35,

                                fill:
                                    false
                            },

                            {

                                label:
                                    'Extension',

                                data:
                                    <?= json_encode(
                                        $monthlyExtension
                                    ); ?>,

                                borderColor:
                                    'rgba(220, 169, 0, 1)',

                                backgroundColor:
                                    'rgba(255, 205, 30, 0.10)',

                                borderWidth:
                                    3,

                                pointRadius:
                                    4,

                                tension:
                                    0.35,

                                fill:
                                    false
                            }
                        ]
                    },


                    options: {

                        responsive:
                            true,

                        maintainAspectRatio:
                            false,

                        interaction: {

                            mode:
                                'index',

                            intersect:
                                false
                        },


                        plugins: {

                            legend: {

                                position:
                                    'bottom'
                            }
                        },


                        scales: {

                            y: {

                                beginAtZero:
                                    true,

                                ticks: {

                                    precision:
                                        0,

                                    stepSize:
                                        1
                                }
                            }
                        }
                    }
                }
            );
        }

    }
);

</script>


<?php

require __DIR__ . '/../includes/footer.php';

?>