<?php

require_once __DIR__ . '/../../includes/auth.php';

requireRole('admin');

$user = currentUser();

$pageTitle = 'Add User';
$activePage = 'users';

$errors = [];


/*
|--------------------------------------------------------------------------
| GET ACTIVE COLLEGES
|--------------------------------------------------------------------------
*/

$collegeStmt = $pdo->query("
    SELECT
        college_id,
        college_name
    FROM colleges
    WHERE status = 'Active'
    ORDER BY college_name
");

$colleges = $collegeStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| FORM SUBMISSION
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    |--------------------------------------------------------------------------
    | CSRF VALIDATION
    |--------------------------------------------------------------------------
    */

    if (
        !verifyCsrfToken(
            $_POST['csrf_token'] ?? ''
        )
    ) {

        $errors[] =
            'Invalid request. Please refresh and try again.';
    }


    /*
    |--------------------------------------------------------------------------
    | GET VALUES
    |--------------------------------------------------------------------------
    */

    $firstName =
        trim($_POST['first_name'] ?? '');

    $middleName =
        trim($_POST['middle_name'] ?? '');

    $lastName =
        trim($_POST['last_name'] ?? '');

    $username =
        trim($_POST['username'] ?? '');

    $email =
        trim($_POST['email'] ?? '');

    $role =
        trim($_POST['role'] ?? '');

    $collegeId =
        !empty($_POST['college_id'])
            ? (int)$_POST['college_id']
            : null;

    $password =
        $_POST['password'] ?? '';

    $confirmPassword =
        $_POST['confirm_password'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | VALID ROLES
    |--------------------------------------------------------------------------
    |
    | Admin can create:
    |
    | - Administrator
    | - Faculty / Researcher
    | - Research Processing Staff (RPS)
    | - Extension Coordinator
    |
    */

    $validRoles = [
        'admin',
        'faculty',
        'rps',
        'extension_coordinator'
    ];


    /*
    |--------------------------------------------------------------------------
    | VALIDATION
    |--------------------------------------------------------------------------
    */

    if ($firstName === '') {

        $errors[] =
            'First name is required.';
    }


    if ($lastName === '') {

        $errors[] =
            'Last name is required.';
    }


    if ($username === '') {

        $errors[] =
            'Username is required.';
    }


    /*
    |--------------------------------------------------------------------------
    | USERNAME FORMAT
    |--------------------------------------------------------------------------
    */

    if (
        $username !== ''
        &&
        !preg_match(
            '/^[A-Za-z0-9._-]{4,50}$/',
            $username
        )
    ) {

        $errors[] =
            'Username must be 4 to 50 characters and may contain letters, numbers, dot, underscore, or dash only.';
    }


    /*
    |--------------------------------------------------------------------------
    | EMAIL
    |--------------------------------------------------------------------------
    */

    if (
        !filter_var(
            $email,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $errors[] =
            'Please enter a valid email address.';
    }


    /*
    |--------------------------------------------------------------------------
    | ROLE
    |--------------------------------------------------------------------------
    */

    if (
        !in_array(
            $role,
            $validRoles,
            true
        )
    ) {

        $errors[] =
            'Please select a valid user role.';
    }


    /*
    |--------------------------------------------------------------------------
    | PASSWORD
    |--------------------------------------------------------------------------
    */

    if (
        strlen($password) < 8
    ) {

        $errors[] =
            'Password must be at least 8 characters.';
    }


    if (
        $password !==
        $confirmPassword
    ) {

        $errors[] =
            'Password confirmation does not match.';
    }


    /*
    |--------------------------------------------------------------------------
    | ROLE-SPECIFIC COLLEGE ASSIGNMENT
    |--------------------------------------------------------------------------
    |
    | RPS and Administrator accounts do not require
    | a college assignment.
    |
    */

    if (
        $role === 'admin'
        ||
        $role === 'rps'
    ) {

        $collegeId = null;
    }


    /*
    |--------------------------------------------------------------------------
    | CHECK DUPLICATES
    |--------------------------------------------------------------------------
    */

    if (!$errors) {

        $check = $pdo->prepare("
            SELECT user_id
            FROM users
            WHERE username = ?
               OR email = ?
            LIMIT 1
        ");

        $check->execute([
            $username,
            $email
        ]);


        if ($check->fetch()) {

            $errors[] =
                'Username or email already exists.';

        } else {

            /*
            |--------------------------------------------------------------------------
            | PASSWORD HASH
            |--------------------------------------------------------------------------
            */

            $hash =
                password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


            /*
            |--------------------------------------------------------------------------
            | CREATE USER
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                INSERT INTO users
                (
                    first_name,
                    middle_name,
                    last_name,
                    username,
                    email,
                    password,
                    role,
                    college_id,
                    status
                )
                VALUES
                (
                    ?, ?, ?, ?, ?, ?, ?, ?,
                    'Active'
                )
            ");


            $stmt->execute([
                $firstName,
                $middleName !== ''
                    ? $middleName
                    : null,
                $lastName,
                $username,
                $email,
                $hash,
                $role,
                $collegeId
            ]);


            /*
            |--------------------------------------------------------------------------
            | SUCCESS MESSAGE
            |--------------------------------------------------------------------------
            */

            $roleLabels = [

                'admin' =>
                    'Administrator',

                'faculty' =>
                    'Faculty / Researcher',

                'rps' =>
                    'Research Processing Staff (RPS)',

                'extension_coordinator' =>
                    'Extension Coordinator'
            ];


            $createdRoleLabel =
                $roleLabels[$role]
                ?? 'User';


            setFlash(
                'success',
                $createdRoleLabel .
                ' account created successfully.'
            );


            redirect(
                BASE_URL .
                '/admin/users/index.php'
            );
        }
    }
}


/*
|--------------------------------------------------------------------------
| USER INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';

if (!empty($user['first_name'])) {

    $initials .= strtoupper(
        substr(
            $user['first_name'],
            0,
            1
        )
    );
}

if (!empty($user['last_name'])) {

    $initials .= strtoupper(
        substr(
            $user['last_name'],
            0,
            1
        )
    );
}


/*
|--------------------------------------------------------------------------
| LOAD HEADER + SIDEBAR
|--------------------------------------------------------------------------
*/

require __DIR__ . '/../../includes/header.php';

require __DIR__ . '/../../includes/sidebar.php';

?>


<style>

/* =========================================================
   ADD USER PAGE
========================================================= */

.add-user-wrapper {
    max-width: 1050px;
    margin: 0 auto;
}


/* =========================================================
   PAGE TITLE AREA
========================================================= */

.add-user-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 20px;

    margin-bottom: 22px;
}


.add-user-heading-left {
    display: flex;
    align-items: center;

    gap: 14px;
}


.add-user-heading-icon {
    width: 48px;
    height: 48px;

    min-width: 48px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: #e8f5eb;

    color: var(--asu-green);

    font-size: 21px;
}


.add-user-heading h1 {
    margin: 0 0 4px;

    font-size: 25px;
    font-weight: 700;

    color: #1b211d;
}


.add-user-heading p {
    margin: 0;

    color: #747c76;

    font-size: 12px;
}



/* =========================================================
   FORM CARD
========================================================= */

.add-user-card {
    overflow: hidden;

    background: #ffffff;

    border:
        1px solid
        var(--asu-border);

    border-radius: 16px;

    box-shadow:
        0 5px 18px
        rgba(30, 64, 34, 0.04);
}


.add-user-card-header {
    display: flex;
    align-items: center;

    gap: 13px;

    padding: 20px 24px;

    border-bottom:
        1px solid #edf1ec;

    background:
        #ffffff;
}


.add-user-card-header-icon {
    width: 38px;
    height: 38px;

    min-width: 38px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: #eef7ef;

    color: var(--asu-green);

    font-size: 17px;
}


.add-user-card-header h2 {
    margin: 0 0 2px;

    font-size: 15px;
    font-weight: 700;
}


.add-user-card-header p {
    margin: 0;

    font-size: 11px;

    color: #818982;
}



/* =========================================================
   FORM BODY
========================================================= */

.add-user-card-body {
    padding: 25px;
}


.form-section {
    margin-bottom: 30px;
}


.form-section:last-child {
    margin-bottom: 0;
}


.form-section-title {
    display: flex;
    align-items: center;

    gap: 9px;

    margin-bottom: 16px;

    padding-bottom: 11px;

    border-bottom:
        1px solid #eef2ed;

    color: #273029;

    font-size: 12px;
    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 0.04em;
}


.form-section-title i {
    color: var(--asu-green);

    font-size: 15px;
}



/* =========================================================
   LABELS
========================================================= */

.add-user-card .form-label {
    margin-bottom: 7px;

    color: #414943;

    font-size: 12px;

    font-weight: 600;
}


.required-mark {
    color: #bd3131;

    margin-left: 2px;
}



/* =========================================================
   INPUTS
========================================================= */

.add-user-card .form-control,
.add-user-card .form-select {
    min-height: 45px;

    padding:
        9px
        13px;

    background: #fbfcfb;

    border:
        1px solid #d8e1d7;

    border-radius: 9px;

    color: #232923;

    font-size: 13px;

    transition:
        border-color 0.18s ease,
        box-shadow 0.18s ease,
        background 0.18s ease;
}


.add-user-card .form-control:focus,
.add-user-card .form-select:focus {
    background: #ffffff;

    border-color:
        #76ac82;

    box-shadow:
        0 0 0
        3px
        rgba(8, 117, 44, 0.08);
}


.add-user-card .input-group-text {
    border:
        1px solid #d8e1d7;

    background:
        #f4f8f4;

    color:
        var(--asu-green);

    border-radius:
        9px 0 0 9px;
}


.add-user-card
.input-group
.form-control {
    border-left: 0;

    border-radius:
        0 9px 9px 0;
}


.form-help {
    display: block;

    margin-top: 6px;

    color: #939a94;

    font-size: 10px;
}



/* =========================================================
   ROLE INFORMATION
========================================================= */

.role-information {
    display: flex;
    align-items: flex-start;

    gap: 10px;

    margin-top: 10px;

    padding: 11px 13px;

    border-radius: 9px;

    background: #f5f9f5;

    color: #697169;

    font-size: 10px;

    line-height: 1.5;
}


.role-information i {
    margin-top: 1px;

    color: var(--asu-green);

    font-size: 13px;
}



/* =========================================================
   PASSWORD BOX
========================================================= */

.password-note {
    display: flex;
    align-items: flex-start;

    gap: 10px;

    margin-top: 14px;

    padding: 12px 14px;

    border-left:
        3px solid
        var(--asu-yellow);

    border-radius: 7px;

    background: #fffbea;

    color: #685d25;

    font-size: 10px;

    line-height: 1.55;
}


.password-note i {
    margin-top: 1px;

    font-size: 13px;
}



/* =========================================================
   ACTION BAR
========================================================= */

.add-user-actions {
    display: flex;
    justify-content: flex-end;
    align-items: center;

    gap: 10px;

    margin-top: 27px;

    padding-top: 20px;

    border-top:
        1px solid #edf1ec;
}


.add-user-actions .btn {
    min-width: 120px;

    min-height: 42px;
}



/* =========================================================
   ERROR BOX
========================================================= */

.form-errors {
    margin-bottom: 20px;

    padding: 16px 18px;

    border:
        1px solid #f1c7c7;

    border-radius: 11px;

    background: #fff5f5;

    color: #822e2e;
}


.form-errors-header {
    display: flex;
    align-items: center;

    gap: 8px;

    margin-bottom: 8px;

    font-size: 12px;
    font-weight: 700;
}


.form-errors ul {
    margin:
        0;

    padding-left:
        20px;

    font-size:
        11px;

    line-height:
        1.7;
}



/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 768px) {

    .add-user-heading {
        align-items: flex-start;
    }


    .add-user-card-body {
        padding: 20px;
    }


    .add-user-actions {
        flex-direction: column-reverse;
    }


    .add-user-actions .btn {
        width: 100%;
    }

}

</style>



<div class="main-page">


    <!-- =====================================================
         TOPBAR
    ====================================================== -->

    <header class="asu-topbar">


        <div class="topbar-left">


            <button
                id="sidebarToggle"
                type="button"
                class="sidebar-toggle"
                aria-label="Open navigation"
            >

                <i class="bi bi-list"></i>

            </button>


            <span class="system-name">

                Research & Extension Management System

            </span>


        </div>



        <div class="topbar-user">


            <div class="topbar-user-text">


                <strong>

                    <?= e(
                        fullName($user)
                    ); ?>

                </strong>


                <span>

                    <?= e(
                        roleLabel(
                            $user['role']
                        )
                    ); ?>

                </span>


            </div>



            <div class="user-avatar">

                <?= e($initials); ?>

            </div>


        </div>


    </header>



    <!-- =====================================================
         CONTENT
    ====================================================== -->

    <main class="page-content">


        <div class="add-user-wrapper">


            <!-- =================================================
                 PAGE HEADING
            ================================================== -->

            <div class="add-user-heading">


                <div class="add-user-heading-left">


                    <div class="add-user-heading-icon">

                        <i class="bi bi-person-plus"></i>

                    </div>


                    <div>


                        <h1>

                            Add User

                        </h1>


                        <p>

                            Create a new authorized
                            ASU-REMS user account.

                        </p>


                    </div>


                </div>



                <a
                    href="<?= BASE_URL; ?>/admin/users/index.php"
                    class="btn btn-outline-asu"
                >

                    <i class="bi bi-arrow-left me-1"></i>

                    Back to Users

                </a>


            </div>



            <!-- =================================================
                 ERRORS
            ================================================== -->

            <?php if ($errors): ?>


                <div class="form-errors">


                    <div class="form-errors-header">

                        <i class="bi bi-exclamation-circle"></i>

                        Please check the following:

                    </div>


                    <ul>


                        <?php foreach (
                            $errors
                            as
                            $error
                        ): ?>


                            <li>

                                <?= e($error); ?>

                            </li>


                        <?php endforeach; ?>


                    </ul>


                </div>


            <?php endif; ?>



            <!-- =================================================
                 MAIN CARD
            ================================================== -->

            <section class="add-user-card">


                <!-- HEADER -->

                <div class="add-user-card-header">


                    <div class="add-user-card-header-icon">

                        <i class="bi bi-person-vcard"></i>

                    </div>


                    <div>


                        <h2>

                            Account Information

                        </h2>


                        <p>

                            Complete the required fields
                            to create the user account.

                        </p>


                    </div>


                </div>



                <!-- BODY -->

                <div class="add-user-card-body">


                    <form
                        method="POST"
                        autocomplete="off"
                    >


                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e(
                                generateCsrfToken()
                            ); ?>"
                        >



                        <!-- =====================================
                             PERSONAL INFORMATION
                        ====================================== -->

                        <div class="form-section">


                            <div class="form-section-title">

                                <i class="bi bi-person"></i>

                                Personal Information

                            </div>



                            <div class="row g-3">


                                <!-- FIRST NAME -->

                                <div class="col-lg-4 col-md-6">


                                    <label
                                        for="first_name"
                                        class="form-label"
                                    >

                                        First Name

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <input
                                        type="text"
                                        id="first_name"
                                        name="first_name"
                                        class="form-control"
                                        maxlength="100"
                                        placeholder="Enter first name"
                                        value="<?= e(
                                            $_POST['first_name']
                                            ?? ''
                                        ); ?>"
                                        required
                                    >


                                </div>



                                <!-- MIDDLE NAME -->

                                <div class="col-lg-4 col-md-6">


                                    <label
                                        for="middle_name"
                                        class="form-label"
                                    >

                                        Middle Name

                                    </label>


                                    <input
                                        type="text"
                                        id="middle_name"
                                        name="middle_name"
                                        class="form-control"
                                        maxlength="100"
                                        placeholder="Optional"
                                        value="<?= e(
                                            $_POST['middle_name']
                                            ?? ''
                                        ); ?>"
                                    >


                                </div>



                                <!-- LAST NAME -->

                                <div class="col-lg-4 col-md-6">


                                    <label
                                        for="last_name"
                                        class="form-label"
                                    >

                                        Last Name

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <input
                                        type="text"
                                        id="last_name"
                                        name="last_name"
                                        class="form-control"
                                        maxlength="100"
                                        placeholder="Enter last name"
                                        value="<?= e(
                                            $_POST['last_name']
                                            ?? ''
                                        ); ?>"
                                        required
                                    >


                                </div>


                            </div>


                        </div>



                        <!-- =====================================
                             LOGIN INFORMATION
                        ====================================== -->

                        <div class="form-section">


                            <div class="form-section-title">

                                <i class="bi bi-shield-lock"></i>

                                Login Information

                            </div>



                            <div class="row g-3">


                                <!-- USERNAME -->

                                <div class="col-md-6">


                                    <label
                                        for="username"
                                        class="form-label"
                                    >

                                        Username

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <div class="input-group">


                                        <span class="input-group-text">

                                            <i class="bi bi-person-circle"></i>

                                        </span>


                                        <input
                                            type="text"
                                            id="username"
                                            name="username"
                                            class="form-control"
                                            minlength="4"
                                            maxlength="50"
                                            placeholder="Enter username"
                                            value="<?= e(
                                                $_POST['username']
                                                ?? ''
                                            ); ?>"
                                            required
                                        >


                                    </div>


                                    <span class="form-help">

                                        Username must be unique
                                        within ASU-REMS.

                                    </span>


                                </div>



                                <!-- EMAIL -->

                                <div class="col-md-6">


                                    <label
                                        for="email"
                                        class="form-label"
                                    >

                                        Email Address

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <div class="input-group">


                                        <span class="input-group-text">

                                            <i class="bi bi-envelope"></i>

                                        </span>


                                        <input
                                            type="email"
                                            id="email"
                                            name="email"
                                            class="form-control"
                                            maxlength="150"
                                            placeholder="name@example.com"
                                            value="<?= e(
                                                $_POST['email']
                                                ?? ''
                                            ); ?>"
                                            required
                                        >


                                    </div>


                                </div>


                            </div>


                        </div>



                        <!-- =====================================
                             ROLE & ASSIGNMENT
                        ====================================== -->

                        <div class="form-section">


                            <div class="form-section-title">

                                <i class="bi bi-person-gear"></i>

                                Role & Institutional Assignment

                            </div>



                            <div class="row g-3">


                                <!-- ROLE -->

                                <div class="col-md-6">


                                    <label
                                        for="role"
                                        class="form-label"
                                    >

                                        User Role

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <select
                                        id="role"
                                        name="role"
                                        class="form-select"
                                        required
                                    >


                                        <option value="">

                                            Select Role

                                        </option>


                                        <option
                                            value="admin"
                                            <?= (
                                                $_POST['role']
                                                ?? ''
                                            ) === 'admin'
                                                ? 'selected'
                                                : ''; ?>
                                        >

                                            Administrator

                                        </option>


                                        <option
                                            value="faculty"
                                            <?= (
                                                $_POST['role']
                                                ?? ''
                                            ) === 'faculty'
                                                ? 'selected'
                                                : ''; ?>
                                        >

                                            Faculty / Researcher

                                        </option>


                                        <option
                                            value="rps"
                                            <?= (
                                                $_POST['role']
                                                ?? ''
                                            ) === 'rps'
                                                ? 'selected'
                                                : ''; ?>
                                        >

                                            Research Processing Staff (RPS)

                                        </option>


                                        <option
                                            value="extension_coordinator"
                                            <?= (
                                                $_POST['role']
                                                ?? ''
                                            ) ===
                                            'extension_coordinator'
                                                ? 'selected'
                                                : ''; ?>
                                        >

                                            Extension Coordinator

                                        </option>


                                    </select>



                                    <div class="role-information">

                                        <i class="bi bi-info-circle"></i>

                                        <span id="roleDescription">

                                            The selected role determines
                                            which ASU-REMS modules and
                                            functions the user may access.

                                        </span>

                                    </div>


                                </div>



                                <!-- COLLEGE -->

                                <div class="col-md-6">


                                    <label
                                        for="college_id"
                                        class="form-label"
                                    >

                                        College

                                    </label>


                                    <select
                                        id="college_id"
                                        name="college_id"
                                        class="form-select"
                                    >


                                        <option value="">

                                            Not Assigned

                                        </option>



                                        <?php foreach (
                                            $colleges
                                            as
                                            $college
                                        ): ?>


                                            <option
                                                value="<?= (int)$college['college_id']; ?>"
                                                <?= (
                                                    (int)(
                                                        $_POST['college_id']
                                                        ?? 0
                                                    )
                                                    ===
                                                    (int)$college['college_id']
                                                )
                                                    ? 'selected'
                                                    : ''; ?>
                                            >

                                                <?= e(
                                                    $college['college_name']
                                                ); ?>

                                            </option>


                                        <?php endforeach; ?>


                                    </select>


                                    <span
                                        class="form-help"
                                        id="collegeHelp"
                                    >

                                        College assignment may be
                                        updated later if necessary.

                                    </span>


                                </div>


                            </div>


                        </div>



                        <!-- =====================================
                             PASSWORD
                        ====================================== -->

                        <div class="form-section">


                            <div class="form-section-title">

                                <i class="bi bi-key"></i>

                                Account Password

                            </div>



                            <div class="row g-3">


                                <!-- PASSWORD -->

                                <div class="col-md-6">


                                    <label
                                        for="password"
                                        class="form-label"
                                    >

                                        Temporary Password

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <div class="input-group">


                                        <span class="input-group-text">

                                            <i class="bi bi-lock"></i>

                                        </span>


                                        <input
                                            type="password"
                                            id="password"
                                            name="password"
                                            class="form-control"
                                            minlength="8"
                                            autocomplete="new-password"
                                            placeholder="Minimum 8 characters"
                                            required
                                        >


                                    </div>


                                </div>



                                <!-- CONFIRM -->

                                <div class="col-md-6">


                                    <label
                                        for="confirm_password"
                                        class="form-label"
                                    >

                                        Confirm Password

                                        <span class="required-mark">
                                            *
                                        </span>

                                    </label>


                                    <div class="input-group">


                                        <span class="input-group-text">

                                            <i class="bi bi-shield-check"></i>

                                        </span>


                                        <input
                                            type="password"
                                            id="confirm_password"
                                            name="confirm_password"
                                            class="form-control"
                                            minlength="8"
                                            autocomplete="new-password"
                                            placeholder="Re-enter password"
                                            required
                                        >


                                    </div>


                                </div>


                            </div>



                            <div class="password-note">

                                <i class="bi bi-shield-lock"></i>

                                <span>

                                    Passwords are securely stored
                                    using PHP password hashing.
                                    Use a temporary password with
                                    at least eight characters.

                                </span>

                            </div>


                        </div>



                        <!-- =====================================
                             ACTION BUTTONS
                        ====================================== -->

                        <div class="add-user-actions">


                            <a
                                href="<?= BASE_URL; ?>/admin/users/index.php"
                                class="btn btn-outline-asu"
                            >

                                Cancel

                            </a>


                            <button
                                type="submit"
                                class="btn btn-asu"
                            >

                                <i class="bi bi-person-check me-1"></i>

                                Create User

                            </button>


                        </div>


                    </form>


                </div>


            </section>



            <!-- =================================================
                 PAGE FOOTER
            ================================================== -->

            <footer class="content-footer">


                <span>

                    © <?= date('Y'); ?>
                    Aklan State University

                </span>


                <span class="footer-divider">

                    •

                </span>


                <span>

                    Research & Extension Management System

                </span>


            </footer>


        </div>


    </main>


</div>


<script>

document.addEventListener(
    'DOMContentLoaded',
    function () {

        const role =
            document.getElementById(
                'role'
            );

        const college =
            document.getElementById(
                'college_id'
            );

        const collegeHelp =
            document.getElementById(
                'collegeHelp'
            );

        const roleDescription =
            document.getElementById(
                'roleDescription'
            );


        if (
            !role
            ||
            !college
        ) {
            return;
        }


        function updateRoleFields() {

            const selectedRole =
                role.value;


            /*
             * ROLE DESCRIPTION
             */

            const descriptions = {

                admin:
                    'Administrator manages system users, accounts, settings, reports, and overall ASU-REMS administration.',

                faculty:
                    'Faculty / Researcher creates, submits, revises, and tracks research records.',

                rps:
                    'RPS processes research submissions, encodes UREC/IACUC, URRC and In-House results, and processes Notice to Proceed and permits.',

                extension_coordinator:
                    'Extension Coordinator manages and processes extension-related activities and records.'
            };


            if (roleDescription) {

                roleDescription.textContent =
                    descriptions[
                        selectedRole
                    ]
                    ||
                    'The selected role determines which ASU-REMS modules and functions the user may access.';
            }


            /*
             * ADMIN AND RPS DO NOT REQUIRE
             * COLLEGE ASSIGNMENT
             */

            if (
                selectedRole === 'admin'
                ||
                selectedRole === 'rps'
            ) {

                college.value = '';

                college.disabled = true;


                if (collegeHelp) {

                    collegeHelp.textContent =
                        selectedRole === 'rps'
                            ? 'RPS accounts are assigned to the Research Office and do not require a college.'
                            : 'Administrator accounts do not require a college assignment.';
                }

            } else {

                college.disabled = false;


                if (collegeHelp) {

                    collegeHelp.textContent =
                        'College assignment may be updated later if necessary.';
                }
            }
        }


        role.addEventListener(
            'change',
            updateRoleFields
        );


        updateRoleFields();
    }
);

</script>


<?php

require __DIR__ . '/../../includes/footer.php';

?>