<?php

require_once __DIR__ . '/../../includes/auth.php';

requireRole('admin');

$user = currentUser();

$pageTitle = 'Add User';
$activePage = 'users';

$errors = [];

$initials = '';

if (!empty($user['first_name'])) {
    $initials .= strtoupper(substr($user['first_name'], 0, 1));
}

if (!empty($user['last_name'])) {
    $initials .= strtoupper(substr($user['last_name'], 0, 1));
}

$form = [
    'first_name' => '',
    'middle_name' => '',
    'last_name' => '',
    'username' => '',
    'email' => '',
    'role' => '',
    'college_id' => ''
];

$collegeStmt = $pdo->query("
    SELECT college_id, college_name
    FROM colleges
    WHERE status = 'Active'
    ORDER BY college_name
");

$colleges = $collegeStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid request. Please refresh and try again.';
    }

    $form['first_name'] = trim($_POST['first_name'] ?? '');
    $form['middle_name'] = trim($_POST['middle_name'] ?? '');
    $form['last_name'] = trim($_POST['last_name'] ?? '');
    $form['username'] = trim($_POST['username'] ?? '');
    $form['email'] = trim($_POST['email'] ?? '');
    $form['role'] = trim($_POST['role'] ?? '');
    $form['college_id'] = trim($_POST['college_id'] ?? '');

    $collegeId =
        $form['college_id'] !== ''
            ? (int)$form['college_id']
            : null;

    $password = $_POST['password'] ?? '';

    $validRoles = [
        'admin',
        'faculty',
        'extension_coordinator'
    ];

    if ($form['first_name'] === '') {
        $errors[] = 'First name is required.';
    }

    if ($form['last_name'] === '') {
        $errors[] = 'Last name is required.';
    }

    if ($form['username'] === '') {
        $errors[] = 'Username is required.';
    }

    if (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email is required.';
    }

    if (!in_array($form['role'], $validRoles, true)) {
        $errors[] = 'Invalid user role.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters.';
    }

    if (!$errors) {

        $check = $pdo->prepare("
            SELECT user_id
            FROM users
            WHERE username = ?
               OR email = ?
            LIMIT 1
        ");

        $check->execute([
            $form['username'],
            $form['email']
        ]);

        if ($check->fetch()) {

            $errors[] = 'Username or email already exists.';

        } else {

            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users
                (
                    first_name,
                    middle_name,
                    last_name,
                    username,
                    email,
                    password,
                    role,
                    college_id,
                    status
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, 'Active')
            ");

            $stmt->execute([
                $form['first_name'],
                $form['middle_name'] ?: null,
                $form['last_name'],
                $form['username'],
                $form['email'],
                $hash,
                $form['role'],
                $collegeId
            ]);

            setFlash(
                'success',
                'User account created successfully.'
            );

            redirect(BASE_URL . '/admin/users/index.php');
        }
    }
}

require __DIR__ . '/../../includes/header.php';
require __DIR__ . '/../../includes/sidebar.php';

?>

<style>
.user-form-page {
    max-width: 1100px;
    margin: 0 auto;
}

.user-form-heading {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 22px;
}

.user-form-heading h1 {
    margin: 0 0 5px;
    color: #1f2a22;
    font-size: 26px;
    font-weight: 800;
}

.user-form-heading p {
    margin: 0;
    color: var(--asu-muted);
    font-size: 12px;
}

.user-form-card {
    overflow: hidden;
    border: 1px solid var(--asu-border);
    border-radius: 18px;
    background: #ffffff;
    box-shadow: 0 12px 28px rgba(31, 74, 39, .06);
}

.user-form-card-header {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 20px 24px;
    border-bottom: 1px solid #edf1ed;
    background: linear-gradient(180deg, #ffffff, #fbfdfb);
}

.user-form-card-icon {
    width: 44px;
    height: 44px;
    flex: 0 0 44px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 13px;
    background: #edf7ef;
    color: var(--asu-green);
    font-size: 19px;
}

.user-form-card-header h2 {
    margin: 0 0 3px;
    color: #263028;
    font-size: 16px;
    font-weight: 800;
}

.user-form-card-header span {
    color: #7b857e;
    font-size: 10px;
}

.user-form-card-body {
    padding: 24px;
}

.user-form-section {
    margin-bottom: 24px;
}

.user-form-section:last-child {
    margin-bottom: 0;
}

.user-form-section-title {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 14px;
    color: #263028;
    font-size: 12px;
    font-weight: 800;
}

.user-form-section-title i {
    color: var(--asu-green);
}

.user-form-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px 18px;
}

.user-form-grid.two {
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

.user-form-card .form-label {
    margin-bottom: 6px;
    color: #37433a;
    font-size: 11px;
    font-weight: 700;
}

.user-form-card .form-control,
.user-form-card .form-select {
    min-height: 48px;
    border-color: #dfe8e1;
    border-radius: 12px;
    color: #2c352e;
    font-size: 12px;
}

.user-form-card .form-control:focus,
.user-form-card .form-select:focus {
    border-color: var(--asu-green);
    box-shadow: 0 0 0 .18rem rgba(8, 117, 44, .12);
}

.user-form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 26px;
    padding-top: 20px;
    border-top: 1px solid #edf1ed;
}

.user-form-actions .btn {
    min-width: 135px;
    min-height: 44px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 800;
}

.user-form-actions .btn-cancel-clean {
    border: 1px solid #cfd8d1;
    background: #ffffff;
    color: #59635c;
}

.user-form-actions .btn-cancel-clean:hover {
    border-color: #08752c;
    background: #f2f8f3;
    color: #08752c;
}

.user-error-box {
    margin-bottom: 18px;
    padding: 14px 17px;
    border: 1px solid #edcccc;
    border-radius: 13px;
    background: #fff6f6;
    color: #873b3b;
    font-size: 11px;
}

.password-note {
    margin-top: 7px;
    color: #7e8981;
    font-size: 9px;
}

@media (max-width: 991px) {
    .user-form-grid,
    .user-form-grid.two {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 700px) {
    .user-form-heading {
        flex-direction: column;
    }

    .user-form-card-body {
        padding: 18px;
    }

    .user-form-actions {
        flex-direction: column-reverse;
    }

    .user-form-actions .btn {
        width: 100%;
    }
}
</style>

<div class="main-page">

    <header class="asu-topbar">

        <div class="topbar-left">

            <button
                id="sidebarToggle"
                type="button"
                class="sidebar-toggle"
                aria-label="Open navigation"
            >
                <i class="bi bi-list"></i>
            </button>

            <span class="system-name">
                Research & Extension Management System
            </span>

        </div>

        <div class="topbar-user">

            <div class="topbar-user-text">
                <strong>
                    <?= e(fullName($user)); ?>
                </strong>
                <span>
                    <?= e(roleLabel($user['role'])); ?>
                </span>
            </div>

            <div class="user-avatar">
                <?= e($initials); ?>
            </div>

        </div>

    </header>

    <main class="page-content">

        <div class="user-form-page">

            <div class="user-form-heading">

                <div>
                    <h1>
                        Add User
                    </h1>
                    <p>
                        Create a new ASU-REMS account and assign the correct user role.
                    </p>
                </div>

                <a
                    href="<?= BASE_URL; ?>/admin/users/index.php"
                    class="btn btn-outline-asu"
                >
                    <i class="bi bi-arrow-left me-1"></i>
                    Back to Users
                </a>

            </div>

            <?php if ($errors): ?>

                <div class="user-error-box">

                    <strong>
                        Unable to create account.
                    </strong>

                    <ul class="mt-2 mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li>
                                <?= e($error); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                </div>

            <?php endif; ?>

            <section class="user-form-card">

                <div class="user-form-card-header">

                    <div class="user-form-card-icon">
                        <i class="bi bi-person-plus"></i>
                    </div>

                    <div>
                        <h2>
                            User Account Information
                        </h2>
                        <span>
                            Fill out the required fields to add a new authorized user.
                        </span>
                    </div>

                </div>

                <div class="user-form-card-body">

                    <form method="POST" autocomplete="off">

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e(generateCsrfToken()); ?>"
                        >

                        <div class="user-form-section">

                            <div class="user-form-section-title">
                                <i class="bi bi-person"></i>
                                Personal Details
                            </div>

                            <div class="user-form-grid">

                                <div>
                                    <label class="form-label">
                                        First Name
                                    </label>
                                    <input
                                        type="text"
                                        name="first_name"
                                        class="form-control"
                                        value="<?= e($form['first_name']); ?>"
                                        required
                                    >
                                </div>

                                <div>
                                    <label class="form-label">
                                        Middle Name
                                    </label>
                                    <input
                                        type="text"
                                        name="middle_name"
                                        class="form-control"
                                        value="<?= e($form['middle_name']); ?>"
                                    >
                                </div>

                                <div>
                                    <label class="form-label">
                                        Last Name
                                    </label>
                                    <input
                                        type="text"
                                        name="last_name"
                                        class="form-control"
                                        value="<?= e($form['last_name']); ?>"
                                        required
                                    >
                                </div>

                            </div>

                        </div>

                        <div class="user-form-section">

                            <div class="user-form-section-title">
                                <i class="bi bi-key"></i>
                                Login Credentials
                            </div>

                            <div class="user-form-grid">

                                <div>
                                    <label class="form-label">
                                        Username
                                    </label>
                                    <input
                                        type="text"
                                        name="username"
                                        class="form-control"
                                        value="<?= e($form['username']); ?>"
                                        required
                                    >
                                </div>

                                <div>
                                    <label class="form-label">
                                        Email
                                    </label>
                                    <input
                                        type="email"
                                        name="email"
                                        class="form-control"
                                        value="<?= e($form['email']); ?>"
                                        required
                                    >
                                </div>

                                <div>
                                    <label class="form-label">
                                        Temporary Password
                                    </label>
                                    <input
                                        type="password"
                                        name="password"
                                        class="form-control"
                                        minlength="8"
                                        required
                                    >
                                    <div class="password-note">
                                        Minimum of 8 characters.
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="user-form-section">

                            <div class="user-form-section-title">
                                <i class="bi bi-shield-check"></i>
                                Role Assignment
                            </div>

                            <div class="user-form-grid two">

                                <div>
                                    <label class="form-label">
                                        Role
                                    </label>
                                    <select
                                        name="role"
                                        class="form-select"
                                        required
                                    >
                                        <option value="">
                                            Select Role
                                        </option>
                                        <option
                                            value="admin"
                                            <?= $form['role'] === 'admin' ? 'selected' : ''; ?>
                                        >
                                            Administrator
                                        </option>
                                        <option
                                            value="faculty"
                                            <?= $form['role'] === 'faculty' ? 'selected' : ''; ?>
                                        >
                                            Faculty / Researcher
                                        </option>
                                        <option
                                            value="extension_coordinator"
                                            <?= $form['role'] === 'extension_coordinator' ? 'selected' : ''; ?>
                                        >
                                            Extension Coordinator
                                        </option>
                                    </select>
                                </div>

                                <div>
                                    <label class="form-label">
                                        College
                                    </label>
                                    <select
                                        name="college_id"
                                        class="form-select"
                                    >
                                        <option value="">
                                            Not Assigned
                                        </option>

                                        <?php foreach ($colleges as $college): ?>

                                            <option
                                                value="<?= (int)$college['college_id']; ?>"
                                                <?= (string)$form['college_id'] === (string)$college['college_id']
                                                    ? 'selected'
                                                    : ''; ?>
                                            >
                                                <?= e($college['college_name']); ?>
                                            </option>

                                        <?php endforeach; ?>

                                    </select>
                                </div>

                            </div>

                        </div>

                        <div class="user-form-actions">

                            <a
                                href="<?= BASE_URL; ?>/admin/users/index.php"
                                class="btn btn-cancel-clean"
                            >
                                <i class="bi bi-x-circle me-1"></i>
                                Cancel
                            </a>

                            <button
                                type="submit"
                                class="btn btn-asu"
                            >
                                <i class="bi bi-check2-circle me-1"></i>
                                Create User
                            </button>

                        </div>

                    </form>

                </div>

            </section>

        </div>

        <footer class="content-footer">
            <span>
                © <?= date('Y'); ?> Aklan State University
            </span>
            <span class="footer-divider">•</span>
            <span>
                Research & Extension Management System
            </span>
        </footer>

    </main>

</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
