<?php

require_once __DIR__ . '/../../includes/auth.php';

requireRole('admin');

$user = currentUser();

$pageTitle = 'User Management';
$activePage = 'users';


/*
|--------------------------------------------------------------------------
| SEARCH AND FILTER VALUES
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');
$role   = trim($_GET['role'] ?? '');
$status = trim($_GET['status'] ?? '');


/*
|--------------------------------------------------------------------------
| VALID FILTER VALUES
|--------------------------------------------------------------------------
*/

$validRoles = [
    'admin',
    'faculty',
    'rps',
    'extension_coordinator'
];

$validStatuses = [
    'Active',
    'Inactive'
];


/*
|--------------------------------------------------------------------------
| USERS QUERY
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        u.user_id,
        u.first_name,
        u.middle_name,
        u.last_name,
        u.username,
        u.email,
        u.role,
        u.status,
        u.last_login,
        u.created_at,
        u.updated_at,

        c.college_name,

        d.department_name

    FROM users u

    LEFT JOIN colleges c
        ON c.college_id = u.college_id

    LEFT JOIN departments d
        ON d.department_id = u.department_id

    WHERE 1 = 1
";


$params = [];


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $sql .= "
        AND (
            u.first_name LIKE ?
            OR u.middle_name LIKE ?
            OR u.last_name LIKE ?
            OR u.username LIKE ?
            OR u.email LIKE ?
        )
    ";

    $searchTerm =
        '%' . $search . '%';

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}


/*
|--------------------------------------------------------------------------
| ROLE FILTER
|--------------------------------------------------------------------------
*/

if (
    $role !== ''
    &&
    in_array(
        $role,
        $validRoles,
        true
    )
) {

    $sql .= "
        AND u.role = ?
    ";

    $params[] = $role;
}


/*
|--------------------------------------------------------------------------
| STATUS FILTER
|--------------------------------------------------------------------------
*/

if (
    $status !== ''
    &&
    in_array(
        $status,
        $validStatuses,
        true
    )
) {

    $sql .= "
        AND u.status = ?
    ";

    $params[] = $status;
}


/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/

$sql .= "
    ORDER BY
        u.created_at DESC,
        u.last_name ASC,
        u.first_name ASC
";


$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$users = $stmt->fetchAll();


/*
|--------------------------------------------------------------------------
| USER STATISTICS
|--------------------------------------------------------------------------
*/

$totalUsers =
    (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM users
        ")
        ->fetchColumn();


$activeUsers =
    (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM users
            WHERE status = 'Active'
        ")
        ->fetchColumn();


$facultyUsers =
    (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM users
            WHERE role = 'faculty'
        ")
        ->fetchColumn();


$rpsUsers =
    (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM users
            WHERE role = 'rps'
        ")
        ->fetchColumn();


$extensionUsers =
    (int)$pdo
        ->query("
            SELECT COUNT(*)
            FROM users
            WHERE role = 'extension_coordinator'
        ")
        ->fetchColumn();


/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$flash = getFlash();


/*
|--------------------------------------------------------------------------
| HEADER AND SIDEBAR
|--------------------------------------------------------------------------
*/

require __DIR__ . '/../../includes/header.php';

require __DIR__ . '/../../includes/sidebar.php';

?>


<div class="main-page">


    <!-- =====================================================
         TOP HEADER
    ====================================================== -->

    <header class="asu-topbar">


        <div class="topbar-left">


            <button
                type="button"
                id="sidebarToggle"
                class="sidebar-toggle"
                aria-label="Open navigation"
            >

                <i class="bi bi-list"></i>

            </button>


            <span class="system-name">

                Research & Extension Management System

            </span>


        </div>



        <div class="topbar-user">


            <div class="topbar-user-text">


                <strong>

                    <?= e(
                        fullName($user)
                    ); ?>

                </strong>


                <span>

                    <?= e(
                        roleLabel(
                            $user['role']
                        )
                    ); ?>

                </span>


            </div>



            <?php

            $initials = '';

            if (
                !empty(
                    $user['first_name']
                )
            ) {

                $initials .=
                    strtoupper(
                        substr(
                            $user['first_name'],
                            0,
                            1
                        )
                    );
            }


            if (
                !empty(
                    $user['last_name']
                )
            ) {

                $initials .=
                    strtoupper(
                        substr(
                            $user['last_name'],
                            0,
                            1
                        )
                    );
            }

            ?>



            <div class="dropdown">


                <button
                    type="button"
                    class="user-dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >

                    <div class="user-avatar">

                        <?= e($initials); ?>

                    </div>

                </button>



                <ul
                    class="dropdown-menu dropdown-menu-end"
                >


                    <li>

                        <span
                            class="dropdown-item-text"
                        >

                            <strong
                                class="d-block"
                            >

                                <?= e(
                                    fullName($user)
                                ); ?>

                            </strong>


                            <small
                                class="text-muted"
                            >

                                <?= e(
                                    $user['email']
                                ); ?>

                            </small>

                        </span>

                    </li>



                    <li>

                        <hr
                            class="dropdown-divider"
                        >

                    </li>



                    <li>

                        <a
                            href="<?= BASE_URL; ?>/logout.php"
                            class="dropdown-item"
                        >

                            <i
                                class="bi bi-box-arrow-right me-2"
                            ></i>

                            Logout

                        </a>

                    </li>


                </ul>


            </div>


        </div>


    </header>



    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <main class="page-content">


        <!-- =================================================
             PAGE HEADING
        ================================================== -->

        <div class="page-heading">


            <div>


                <h1>

                    User Management

                </h1>


                <p>

                    Manage ASU-REMS user accounts,
                    roles, institutional assignments,
                    and account access.

                </p>


            </div>



            <a
                href="<?= BASE_URL; ?>/admin/users/create.php"
                class="btn btn-asu"
            >

                <i
                    class="bi bi-person-plus me-1"
                ></i>

                Add User

            </a>


        </div>



        <!-- =================================================
             FLASH MESSAGE
        ================================================== -->

        <?php if ($flash): ?>


            <div
                class="
                    alert
                    alert-<?= e(
                        $flash['type']
                    ); ?>
                    alert-dismissible
                    fade
                    show
                    auto-dismiss
                "
                role="alert"
            >


                <?= e(
                    $flash['message']
                ); ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"
                ></button>


            </div>


        <?php endif; ?>



        <!-- =================================================
             USER STATISTIC CARDS
        ================================================== -->

        <section class="stats-row">



            <!-- TOTAL USERS -->

            <div class="stat-card">


                <div
                    class="stat-icon green"
                >

                    <i class="bi bi-people"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $totalUsers
                        ); ?>

                    </strong>


                    <span>

                        Total Users

                    </span>


                </div>


            </div>



            <!-- ACTIVE USERS -->

            <div class="stat-card">


                <div
                    class="stat-icon yellow"
                >

                    <i class="bi bi-person-check"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $activeUsers
                        ); ?>

                    </strong>


                    <span>

                        Active Accounts

                    </span>


                </div>


            </div>



            <!-- FACULTY -->

            <div class="stat-card">


                <div
                    class="stat-icon green"
                >

                    <i class="bi bi-mortarboard"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $facultyUsers
                        ); ?>

                    </strong>


                    <span>

                        Faculty Researchers

                    </span>


                </div>


            </div>



            <!-- RPS -->

            <div class="stat-card">


                <div
                    class="stat-icon yellow"
                >

                    <i class="bi bi-person-gear"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $rpsUsers
                        ); ?>

                    </strong>


                    <span>

                        RPS Accounts

                    </span>


                </div>


            </div>



            <!-- EXTENSION -->

            <div class="stat-card">


                <div
                    class="stat-icon green"
                >

                    <i class="bi bi-person-workspace"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $extensionUsers
                        ); ?>

                    </strong>


                    <span>

                        Extension Coordinators

                    </span>


                </div>


            </div>


        </section>



        <!-- =================================================
             SEARCH AND FILTER
        ================================================== -->

        <section class="filter-card">


            <form
                method="GET"
                class="row g-2"
            >


                <!-- SEARCH -->

                <div class="col-lg-5">


                    <div class="input-group">


                        <span
                            class="input-group-text bg-white"
                        >

                            <i class="bi bi-search"></i>

                        </span>


                        <input
                            type="search"
                            name="search"
                            class="form-control"
                            placeholder="Search name, username or email"
                            value="<?= e(
                                $search
                            ); ?>"
                        >


                    </div>


                </div>



                <!-- ROLE FILTER -->

                <div class="col-lg-3">


                    <select
                        name="role"
                        class="form-select"
                    >


                        <option value="">

                            All Roles

                        </option>



                        <option
                            value="admin"
                            <?= $role === 'admin'
                                ? 'selected'
                                : ''; ?>
                        >

                            Administrator

                        </option>



                        <option
                            value="faculty"
                            <?= $role === 'faculty'
                                ? 'selected'
                                : ''; ?>
                        >

                            Faculty / Researcher

                        </option>



                        <option
                            value="rps"
                            <?= $role === 'rps'
                                ? 'selected'
                                : ''; ?>
                        >

                            RPS

                        </option>



                        <option
                            value="extension_coordinator"
                            <?= $role ===
                                'extension_coordinator'
                                ? 'selected'
                                : ''; ?>
                        >

                            Extension Coordinator

                        </option>


                    </select>


                </div>



                <!-- STATUS -->

                <div class="col-lg-2">


                    <select
                        name="status"
                        class="form-select"
                    >


                        <option value="">

                            All Status

                        </option>



                        <option
                            value="Active"
                            <?= $status ===
                                'Active'
                                ? 'selected'
                                : ''; ?>
                        >

                            Active

                        </option>



                        <option
                            value="Inactive"
                            <?= $status ===
                                'Inactive'
                                ? 'selected'
                                : ''; ?>
                        >

                            Inactive

                        </option>


                    </select>


                </div>



                <!-- FILTER BUTTON -->

                <div class="col-lg-2">


                    <button
                        type="submit"
                        class="
                            btn
                            btn-asu
                            w-100
                        "
                    >

                        <i
                            class="bi bi-funnel me-1"
                        ></i>

                        Filter

                    </button>


                </div>


            </form>



            <?php if (
                $search !== ''
                ||
                $role !== ''
                ||
                $status !== ''
            ): ?>


                <div class="mt-3">


                    <a
                        href="<?= BASE_URL; ?>/admin/users/index.php"
                        class="small"
                        style="
                            color:
                            var(--asu-green);
                        "
                    >

                        <i
                            class="bi bi-x-circle me-1"
                        ></i>

                        Clear Filters

                    </a>


                </div>


            <?php endif; ?>


        </section>



        <!-- =================================================
             USER TABLE
        ================================================== -->

        <section class="asu-panel">


            <div class="panel-header">


                <h2 class="panel-title">


                    <i
                        class="bi bi-people"
                    ></i>

                    User Accounts


                </h2>



                <span
                    class="text-muted small"
                >

                    <?= count($users); ?>

                    result<?= count($users) !== 1
                        ? 's'
                        : ''; ?>

                </span>


            </div>



            <div class="table-responsive">


                <table
                    class="
                        table
                        asu-table
                        align-middle
                    "
                >


                    <thead>


                        <tr>


                            <th>

                                User

                            </th>


                            <th>

                                Username

                            </th>


                            <th>

                                Role

                            </th>


                            <th>

                                College / Department

                            </th>


                            <th>

                                Status

                            </th>


                            <th>

                                Last Login

                            </th>


                            <th
                                class="text-end"
                            >

                                Actions

                            </th>


                        </tr>


                    </thead>



                    <tbody>



                    <?php if (
                        empty($users)
                    ): ?>


                        <tr>


                            <td
                                colspan="7"
                                class="
                                    text-center
                                    py-5
                                "
                            >


                                <div
                                    class="text-muted"
                                >


                                    <i
                                        class="bi bi-people"
                                        style="
                                            font-size:
                                            32px;
                                        "
                                    ></i>


                                    <div
                                        class="mt-2"
                                    >

                                        No user
                                        accounts found.

                                    </div>


                                </div>


                            </td>


                        </tr>



                    <?php else: ?>



                        <?php foreach (
                            $users
                            as
                            $account
                        ): ?>



                            <?php

                            $accountInitials = '';


                            if (
                                !empty(
                                    $account[
                                        'first_name'
                                    ]
                                )
                            ) {

                                $accountInitials .=
                                    strtoupper(
                                        substr(
                                            $account[
                                                'first_name'
                                            ],
                                            0,
                                            1
                                        )
                                    );
                            }


                            if (
                                !empty(
                                    $account[
                                        'last_name'
                                    ]
                                )
                            ) {

                                $accountInitials .=
                                    strtoupper(
                                        substr(
                                            $account[
                                                'last_name'
                                            ],
                                            0,
                                            1
                                        )
                                    );
                            }


                            $accountName =
                                trim(
                                    $account[
                                        'first_name'
                                    ]
                                    .
                                    ' '
                                    .
                                    (
                                        $account[
                                            'middle_name'
                                        ]
                                        ?
                                        $account[
                                            'middle_name'
                                        ]
                                        .
                                        ' '
                                        :
                                        ''
                                    )
                                    .
                                    $account[
                                        'last_name'
                                    ]
                                );

                            ?>



                            <tr>



                                <!-- USER -->

                                <td>


                                    <div
                                        class="
                                            d-flex
                                            align-items-center
                                            gap-3
                                        "
                                    >


                                        <div
                                            class="user-avatar"
                                            style="
                                                width:
                                                40px;

                                                height:
                                                40px;

                                                min-width:
                                                40px;
                                            "
                                        >

                                            <?= e(
                                                $accountInitials
                                            ); ?>

                                        </div>



                                        <div>


                                            <strong
                                                class="d-block"
                                            >

                                                <?= e(
                                                    $accountName
                                                ); ?>

                                            </strong>


                                            <small
                                                class="text-muted"
                                            >

                                                <?= e(
                                                    $account[
                                                        'email'
                                                    ]
                                                ); ?>

                                            </small>


                                        </div>


                                    </div>


                                </td>



                                <!-- USERNAME -->

                                <td>


                                    <span>

                                        <?= e(
                                            $account[
                                                'username'
                                            ]
                                        ); ?>

                                    </span>


                                </td>



                                <!-- ROLE -->

                                <td>



                                    <?php if (
                                        $account[
                                            'role'
                                        ]
                                        ===
                                        'admin'
                                    ): ?>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:
                                                #e5f5e9;

                                                color:
                                                #08752c;

                                                padding:
                                                7px 10px;
                                            "
                                        >

                                            Administrator

                                        </span>



                                    <?php elseif (
                                        $account[
                                            'role'
                                        ]
                                        ===
                                        'faculty'
                                    ): ?>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:
                                                #fff4c8;

                                                color:
                                                #725f00;

                                                padding:
                                                7px 10px;
                                            "
                                        >

                                            Faculty /
                                            Researcher

                                        </span>



                                    <?php elseif (
                                        $account[
                                            'role'
                                        ]
                                        ===
                                        'rps'
                                    ): ?>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:
                                                #e8f5e9;

                                                color:
                                                #176b35;

                                                padding:
                                                7px 10px;
                                            "
                                        >

                                            RPS

                                        </span>



                                    <?php elseif (
                                        $account[
                                            'role'
                                        ]
                                        ===
                                        'extension_coordinator'
                                    ): ?>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:
                                                #e8efff;

                                                color:
                                                #35588b;

                                                padding:
                                                7px 10px;
                                            "
                                        >

                                            Extension
                                            Coordinator

                                        </span>



                                    <?php else: ?>


                                        <span
                                            class="
                                                badge
                                                rounded-pill
                                            "
                                            style="
                                                background:
                                                #eeeeee;

                                                color:
                                                #555555;

                                                padding:
                                                7px 10px;
                                            "
                                        >

                                            Unknown Role

                                        </span>


                                    <?php endif; ?>


                                </td>



                                <!-- COLLEGE -->

                                <td>


                                    <?php if (
                                        !empty(
                                            $account[
                                                'college_name'
                                            ]
                                        )
                                    ): ?>


                                        <strong
                                            class="d-block"
                                            style="
                                                font-size:
                                                12px;
                                            "
                                        >

                                            <?= e(
                                                $account[
                                                    'college_name'
                                                ]
                                            ); ?>

                                        </strong>


                                        <?php if (
                                            !empty(
                                                $account[
                                                    'department_name'
                                                ]
                                            )
                                        ): ?>


                                            <small
                                                class="text-muted"
                                            >

                                                <?= e(
                                                    $account[
                                                        'department_name'
                                                    ]
                                                ); ?>

                                            </small>


                                        <?php else: ?>


                                            <small
                                                class="text-muted"
                                            >

                                                No department

                                            </small>


                                        <?php endif; ?>



                                    <?php else: ?>


                                        <span
                                            class="text-muted"
                                        >

                                            Not assigned

                                        </span>


                                    <?php endif; ?>


                                </td>



                                <!-- STATUS -->

                                <td>



                                    <?php if (
                                        $account[
                                            'status'
                                        ]
                                        ===
                                        'Active'
                                    ): ?>


                                        <span
                                            class="
                                                status-badge
                                                status-completed
                                            "
                                        >

                                            Active

                                        </span>



                                    <?php else: ?>


                                        <span
                                            class="
                                                status-badge
                                                status-revision
                                            "
                                        >

                                            Inactive

                                        </span>


                                    <?php endif; ?>


                                </td>



                                <!-- LAST LOGIN -->

                                <td>


                                    <?php if (
                                        !empty(
                                            $account[
                                                'last_login'
                                            ]
                                        )
                                    ): ?>


                                        <?= e(
                                            date(
                                                'M d, Y',
                                                strtotime(
                                                    $account[
                                                        'last_login'
                                                    ]
                                                )
                                            )
                                        ); ?>


                                        <div
                                            class="
                                                text-muted
                                                small
                                            "
                                        >

                                            <?= e(
                                                date(
                                                    'h:i A',
                                                    strtotime(
                                                        $account[
                                                            'last_login'
                                                        ]
                                                    )
                                                )
                                            ); ?>

                                        </div>



                                    <?php else: ?>


                                        <span
                                            class="text-muted"
                                        >

                                            Never

                                        </span>


                                    <?php endif; ?>


                                </td>



                                <!-- ACTIONS -->

                                <td
                                    class="text-end"
                                >


                                    <div
                                        class="
                                            d-inline-flex
                                            gap-1
                                        "
                                    >



                                        <!-- EDIT USER -->

                                        <a
                                            href="<?= BASE_URL; ?>/admin/users/edit.php?id=<?= (int)$account['user_id']; ?>"
                                            class="
                                                btn
                                                btn-sm
                                                btn-outline-asu
                                            "
                                            title="Edit User"
                                        >

                                            <i
                                                class="bi bi-pencil"
                                            ></i>


                                            <span
                                                class="
                                                    d-none
                                                    d-xl-inline
                                                    ms-1
                                                "
                                            >

                                                Edit

                                            </span>


                                        </a>



                                        <!-- STATUS BUTTON -->

                                        <?php if (
                                            (int)$account[
                                                'user_id'
                                            ]
                                            !==
                                            (int)$_SESSION[
                                                'user_id'
                                            ]
                                        ): ?>



                                            <form
                                                method="POST"
                                                action="<?= BASE_URL; ?>/admin/users/toggle_status.php"
                                                class="d-inline"
                                            >


                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= e(
                                                        generateCsrfToken()
                                                    ); ?>"
                                                >


                                                <input
                                                    type="hidden"
                                                    name="user_id"
                                                    value="<?= (int)$account['user_id']; ?>"
                                                >



                                                <?php if (
                                                    $account[
                                                        'status'
                                                    ]
                                                    ===
                                                    'Active'
                                                ): ?>


                                                    <button
                                                        type="submit"
                                                        class="
                                                            btn
                                                            btn-sm
                                                            btn-outline-danger
                                                        "
                                                        title="Deactivate Account"
                                                        onclick="
                                                            return confirm(
                                                                'Are you sure you want to deactivate this account?'
                                                            );
                                                        "
                                                    >

                                                        <i
                                                            class="bi bi-person-x"
                                                        ></i>

                                                    </button>



                                                <?php else: ?>


                                                    <button
                                                        type="submit"
                                                        class="
                                                            btn
                                                            btn-sm
                                                            btn-outline-success
                                                        "
                                                        title="Activate Account"
                                                        onclick="
                                                            return confirm(
                                                                'Are you sure you want to activate this account?'
                                                            );
                                                        "
                                                    >

                                                        <i
                                                            class="bi bi-person-check"
                                                        ></i>

                                                    </button>


                                                <?php endif; ?>


                                            </form>



                                        <?php else: ?>


                                            <button
                                                type="button"
                                                class="
                                                    btn
                                                    btn-sm
                                                    btn-light
                                                "
                                                disabled
                                                title="Current logged-in account"
                                            >

                                                <i
                                                    class="bi bi-lock"
                                                ></i>

                                            </button>


                                        <?php endif; ?>


                                    </div>


                                </td>


                            </tr>



                        <?php endforeach; ?>



                    <?php endif; ?>



                    </tbody>


                </table>


            </div>


        </section>



        <!-- =================================================
             SECURITY INFORMATION
        ================================================== -->

        <div class="design-notice">


            <strong>
                Account Security:
            </strong>

            User accounts use role-based access
            control. Institutional accounts are
            activated or deactivated instead of
            permanently deleting account history.


        </div>



        <!-- =================================================
             FOOTER
        ================================================== -->

        <footer class="content-footer">

            ASU Research & Extension Management System
            (ASU-REMS)

        </footer>


    </main>


</div>


<?php

require __DIR__ . '/../../includes/footer.php';

?>