<?php

require_once __DIR__ . '/includes/auth.php';

requireLogin();

$user = currentUser();

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';


$userRole =
    $user['role'] ?? '';

$userId =
    (int)($user['user_id'] ?? 0);


/*
|--------------------------------------------------------------------------
| DASHBOARD VIEW
|--------------------------------------------------------------------------
*/

$dashboardView =
    trim(
        $_GET['view']
        ?? ''
    );


/*
|--------------------------------------------------------------------------
| VALIDATE VIEW
|--------------------------------------------------------------------------
*/

if (
    $dashboardView !== ''
    &&
    $dashboardView !== 'processing'
) {

    $dashboardView = '';
}


/*
|--------------------------------------------------------------------------
| PROCESSING VIEW
|--------------------------------------------------------------------------
*/

$isProcessingView =
    $userRole === 'rps'
    &&
    $dashboardView === 'processing';


/*
|--------------------------------------------------------------------------
| USER INFORMATION
|--------------------------------------------------------------------------
*/

$firstName =
    $user['first_name']
    ?? 'User';


$initials = '';


if (
    !empty(
        $user['first_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['first_name'],
                0,
                1
            )
        );
}


if (
    !empty(
        $user['last_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['last_name'],
                0,
                1
            )
        );
}


/*
|--------------------------------------------------------------------------
| ROLE LABEL
|--------------------------------------------------------------------------
*/

if (
    $userRole === 'rps'
) {

    $displayRole =
        'Research Processing Staff (RPS)';

} else {

    $displayRole =
        roleLabel(
            $userRole
        );
}


/*
|--------------------------------------------------------------------------
| DEFAULT VALUES
|--------------------------------------------------------------------------
*/

$activeResearch = 0;

$extensionPrograms = 0;

$facultyResearchers = 0;

$completedProjects = 0;

$proposalsThisMonth = 0;

$pendingApprovals = 0;

$communityParticipants = 0;

$reportsGenerated = 0;


/*
|--------------------------------------------------------------------------
| RPS VALUES
|--------------------------------------------------------------------------
*/

$rpsPendingSubmissions = 0;

$rpsEthicsQueue = 0;

$rpsUrrcQueue = 0;

$rpsInhouseQueue = 0;

$rpsReadyForNtp = 0;

$rpsPermitQueue = 0;


/*
|--------------------------------------------------------------------------
| FACULTY COUNT
|--------------------------------------------------------------------------
*/

try {

    $facultyStmt =
        $pdo->prepare("
            SELECT COUNT(*)

            FROM users

            WHERE role = 'faculty'

              AND status = 'Active'
        ");

    $facultyStmt->execute();

    $facultyResearchers =
        (int)$facultyStmt
            ->fetchColumn();


} catch (Throwable $e) {

    $facultyResearchers = 0;

    error_log(
        'Dashboard Faculty Count Error: '
        .
        $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| RESEARCH COUNTS
|--------------------------------------------------------------------------
*/

try {

    /*
    |----------------------------------------------------------------------
    | IMPORTANT
    |----------------------------------------------------------------------
    | This dashboard must count the same table used by the Research module
    | and RPS queue: research_proposals.
    |
    | Queue counts are based on workflow_status, because the detailed
    | flowchart process uses:
    | SUBMITTED, FOR_ETHICS_REVIEW, FOR_URRC, FOR_INHOUSE,
    | READY_FOR_NTP, TERMINAL_REPORT_SUBMITTED.
    */

    if (
        $userRole === 'faculty'
    ) {

        $stmt =
            $pdo->prepare("
                SELECT COUNT(*)

                FROM research_proposals

                WHERE researcher_id = ?

                  AND COALESCE(is_archived, 0) = 0

                  AND status NOT IN
                  (
                      'Completed',
                      'Rejected',
                      'Archived'
                  )
            ");

        $stmt->execute([
            $userId
        ]);

        $activeResearch =
            (int)$stmt->fetchColumn();


        $stmt =
            $pdo->prepare("
                SELECT COUNT(*)

                FROM research_proposals

                WHERE researcher_id = ?

                  AND status = 'Completed'
            ");

        $stmt->execute([
            $userId
        ]);

        $completedProjects =
            (int)$stmt->fetchColumn();


        $stmt =
            $pdo->prepare("
                SELECT COUNT(*)

                FROM research_proposals

                WHERE researcher_id = ?

                  AND submitted_at >=
                      DATE_FORMAT(
                          CURRENT_DATE,
                          '%Y-%m-01'
                      )
            ");

        $stmt->execute([
            $userId
        ]);

        $proposalsThisMonth =
            (int)$stmt->fetchColumn();
    }


    if (
        in_array(
            $userRole,
            [
                'admin',
                'rps'
            ],
            true
        )
    ) {

        $activeResearch =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE COALESCE(is_archived, 0) = 0

                      AND status NOT IN
                      (
                          'Draft',
                          'Completed',
                          'Rejected',
                          'Archived'
                      )
                ")
                ->fetchColumn();


        $completedProjects =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE status = 'Completed'
                ")
                ->fetchColumn();


        $proposalsThisMonth =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE submitted_at >=
                        DATE_FORMAT(
                            CURRENT_DATE,
                            '%Y-%m-01'
                        )
                ")
                ->fetchColumn();
    }


    /*
    |----------------------------------------------------------------------
    | RPS QUEUES
    |----------------------------------------------------------------------
    */

    if (
        $userRole === 'rps'
    ) {

        $rpsPendingSubmissions =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status = 'SUBMITTED'

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $rpsEthicsQueue =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status = 'FOR_ETHICS_REVIEW'

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $rpsUrrcQueue =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status IN
                    (
                        'FOR_URRC',
                        'URRC_REVISED_SUBMITTED'
                    )

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $rpsInhouseQueue =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status IN
                    (
                        'FOR_INHOUSE',
                        'INHOUSE_REVISED_SUBMITTED'
                    )

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $rpsReadyForNtp =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status = 'READY_FOR_NTP'

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $rpsPermitQueue =
            (int)$pdo
                ->query("
                    SELECT COUNT(*)

                    FROM research_proposals

                    WHERE workflow_status = 'TERMINAL_REPORT_SUBMITTED'

                      AND COALESCE(is_archived, 0) = 0
                ")
                ->fetchColumn();


        $pendingApprovals =
            $rpsPendingSubmissions
            +
            $rpsEthicsQueue
            +
            $rpsUrrcQueue
            +
            $rpsInhouseQueue
            +
            $rpsReadyForNtp
            +
            $rpsPermitQueue;
    }


} catch (Throwable $e) {

    error_log(
        'Dashboard Research Statistics Error: '
        .
        $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| RECENT RESEARCH
|--------------------------------------------------------------------------
*/

$recentResearch = [];


try {

    if (
        $userRole === 'faculty'
    ) {

        $stmt =
            $pdo->prepare("
                SELECT
                    rp.research_id AS id,
                    rp.manuscript_no,
                    rp.research_title AS title,
                    COALESCE(
                        NULLIF(rp.workflow_status, ''),
                        UPPER(REPLACE(rp.status, ' ', '_'))
                    ) AS current_status,
                    rp.workflow_stage AS current_stage,
                    rp.created_at,
                    rp.submitted_at,

                    u.first_name,
                    u.last_name

                FROM research_proposals rp

                LEFT JOIN users u
                    ON u.user_id = rp.researcher_id

                WHERE rp.researcher_id = ?

                ORDER BY
                    COALESCE(
                        rp.workflow_updated_at,
                        rp.submitted_at,
                        rp.created_at
                    ) DESC

                LIMIT 5
            ");

        $stmt->execute([
            $userId
        ]);

        $recentResearch =
            $stmt->fetchAll();


    } elseif (
        in_array(
            $userRole,
            [
                'admin',
                'rps'
            ],
            true
        )
    ) {

        $stmt =
            $pdo->query("
                SELECT
                    rp.research_id AS id,
                    rp.manuscript_no,
                    rp.research_title AS title,
                    COALESCE(
                        NULLIF(rp.workflow_status, ''),
                        UPPER(REPLACE(rp.status, ' ', '_'))
                    ) AS current_status,
                    rp.workflow_stage AS current_stage,
                    rp.created_at,
                    rp.submitted_at,

                    u.first_name,
                    u.last_name

                FROM research_proposals rp

                LEFT JOIN users u
                    ON u.user_id = rp.researcher_id

                WHERE rp.status <> 'Draft'

                ORDER BY
                    COALESCE(
                        rp.workflow_updated_at,
                        rp.submitted_at,
                        rp.created_at
                    ) DESC

                LIMIT 5
            ");

        $recentResearch =
            $stmt->fetchAll();
    }


} catch (Throwable $e) {

    error_log(
        'Dashboard Recent Research Error: '
        .
        $e->getMessage()
    );

    $recentResearch = [];
}


/*
|--------------------------------------------------------------------------
| STATUS LABEL
|--------------------------------------------------------------------------
*/

function dashboardResearchStatusLabel(
    string $status
): string {

    $labels = [

        'DRAFT' =>
            'Draft',

        'SUBMITTED' =>
            'Submitted',

        'FOR_ETHICS_REVIEW' =>
            'For UREC/IACUC Review',

        'ETHICS_COMPLETED' =>
            'UREC/IACUC Completed',

        'SELF_INITIATED_UPE_REQUIRED' =>
            'UPE Certificates Required',

        'SELF_INITIATED_UPE_SUBMITTED' =>
            'UPE Certificates Submitted',

        'FOR_URRC' =>
            'For URRC Review',

        'URRC_REVISION_REQUIRED' =>
            'URRC Revision Required',

        'URRC_REVISED_SUBMITTED' =>
            'URRC Revision Submitted',

        'URRC_REJECTED' =>
            'URRC Rejected',

        'FOR_INHOUSE' =>
            'For In-House Review',

        'INHOUSE_REVISION_REQUIRED' =>
            'In-House Revision Required',

        'INHOUSE_REVISED_SUBMITTED' =>
            'In-House Revision Submitted',

        'INHOUSE_FAILED' =>
            'In-House Failed',

        'READY_FOR_NTP' =>
            'Ready for Notice to Proceed',

        'NTP_ISSUED' =>
            'Notice to Proceed Issued',

        'COMPLETED_MANUSCRIPT_SUBMITTED' =>
            'Completed Manuscript Submitted',

        'TERMINAL_REPORT_SUBMITTED' =>
            'Terminal Report Submitted',

        'PERMIT_ISSUED' =>
            'Permit Issued',

        'COMPLETED' =>
            'Completed',

        'ARCHIVED_NO_REVISION' =>
            'Archived'
    ];


    return
        $labels[$status]
        ?? $status;
}


/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

require __DIR__ . '/includes/header.php';

require __DIR__ . '/includes/sidebar.php';

?>

<?php

/*
|--------------------------------------------------------------------------
| DASHBOARD UI HELPERS
|--------------------------------------------------------------------------
*/

$dashboardUnreadCount = 0;

try {
    require_once __DIR__ . '/includes/notifications.php';

    if (function_exists('unreadNotificationCount')) {
        $dashboardUnreadCount = unreadNotificationCount($pdo, $userId);
    }
} catch (Throwable $e) {
    $dashboardUnreadCount = 0;
}

$dashboardGreeting = 'Welcome,';

function asuDashboardTimeAgo(?string $dateTime): string
{
    if (!$dateTime) {
        return '';
    }

    $timestamp = strtotime($dateTime);

    if (!$timestamp) {
        return '';
    }

    $seconds = time() - $timestamp;

    if ($seconds < 60) {
        return 'Just now';
    }

    if ($seconds < 3600) {
        return floor($seconds / 60) . ' mins ago';
    }

    if ($seconds < 86400) {
        return floor($seconds / 3600) . ' hours ago';
    }

    if ($seconds < 172800) {
        return '1 day ago';
    }

    return date('M d, Y', $timestamp);
}

function asuDashboardActionLabel(string $status): string
{
    return match (strtoupper($status)) {
        'SUBMITTED' => 'New research proposal submitted',
        'FOR_ETHICS_REVIEW' => 'Research moved to UREC / IACUC',
        'ETHICS_COMPLETED' => 'UREC review completed',
        'FOR_URRC' => 'Research forwarded to URRC',
        'URRC_REVISION_REQUIRED' => 'URRC revision requested',
        'URRC_REVISED_SUBMITTED' => 'URRC revision submitted',
        'FOR_INHOUSE' => 'Research moved to In-House Review',
        'INHOUSE_REVISION_REQUIRED' => 'In-House revision requested',
        'INHOUSE_REVISED_SUBMITTED' => 'In-House revision submitted',
        'READY_FOR_NTP' => 'Research ready for Notice to Proceed',
        'NTP_ISSUED' => 'Research marked as Ongoing',
        'COMPLETED_MANUSCRIPT_SUBMITTED' => 'Completed manuscript submitted',
        'TERMINAL_REPORT_SUBMITTED' => 'Terminal report submitted',
        'PERMIT_ISSUED' => 'Permit issued',
        'COMPLETED' => 'Research completed',
        default => dashboardResearchStatusLabel($status),
    };
}

$dashboardActivities = [];

try {
    if ($userRole === 'faculty') {
        $activityStmt = $pdo->prepare("
            SELECT
                rsh.new_status,
                rsh.remarks,
                rsh.changed_at,
                rp.research_title,
                rp.manuscript_no,
                u.first_name,
                u.last_name
            FROM research_status_history rsh
            INNER JOIN research_proposals rp
                ON rp.research_id = rsh.research_id
            LEFT JOIN users u
                ON u.user_id = rsh.changed_by
            WHERE rp.researcher_id = ?
            ORDER BY rsh.changed_at DESC, rsh.history_id DESC
            LIMIT 5
        ");

        $activityStmt->execute([$userId]);
    } else {
        $activityStmt = $pdo->query("
            SELECT
                rsh.new_status,
                rsh.remarks,
                rsh.changed_at,
                rp.research_title,
                rp.manuscript_no,
                u.first_name,
                u.last_name
            FROM research_status_history rsh
            INNER JOIN research_proposals rp
                ON rp.research_id = rsh.research_id
            LEFT JOIN users u
                ON u.user_id = rsh.changed_by
            WHERE rp.status <> 'Draft'
            ORDER BY rsh.changed_at DESC, rsh.history_id DESC
            LIMIT 5
        ");
    }

    $dashboardActivities = $activityStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $dashboardActivities = [];
}

$rpsDashboardTotal =
    (int)$rpsPendingSubmissions
    + (int)$rpsEthicsQueue
    + (int)$rpsUrrcQueue
    + (int)$rpsInhouseQueue
    + (int)$rpsReadyForNtp
    + (int)$rpsPermitQueue;

$rpsStatCards = [
    [
        'label' => 'New Submissions',
        'sub' => 'For initial processing',
        'count' => $rpsPendingSubmissions,
        'icon' => 'bi-file-earmark-plus',
        'tone' => 'green',
        'url' => BASE_URL . '/research/rps_queue.php?queue=submissions',
    ],
    [
        'label' => 'UREC / IACUC',
        'sub' => 'For ethics review',
        'count' => $rpsEthicsQueue,
        'icon' => 'bi-shield-check',
        'tone' => 'yellow',
        'url' => BASE_URL . '/research/rps_queue.php?queue=ethics',
    ],
    [
        'label' => 'URRC Review',
        'sub' => 'For technical review',
        'count' => $rpsUrrcQueue,
        'icon' => 'bi-journal-check',
        'tone' => 'green',
        'url' => BASE_URL . '/research/rps_queue.php?queue=urrc',
    ],
    [
        'label' => 'In-House Review',
        'sub' => 'For final review',
        'count' => $rpsInhouseQueue,
        'icon' => 'bi-clipboard-check',
        'tone' => 'yellow',
        'url' => BASE_URL . '/research/rps_queue.php?queue=inhouse',
    ],
];

$rpsQueueItems = [
    [
        'label' => 'New Research Submissions',
        'sub' => 'Submitted research waiting for initial processing.',
        'count' => $rpsPendingSubmissions,
        'icon' => 'bi-file-earmark-plus',
        'tone' => 'green',
        'url' => BASE_URL . '/research/rps_queue.php?queue=submissions',
    ],
    [
        'label' => 'UREC / IACUC Review',
        'sub' => 'Research awaiting ethics review results.',
        'count' => $rpsEthicsQueue,
        'icon' => 'bi-shield-check',
        'tone' => 'orange',
        'url' => BASE_URL . '/research/rps_queue.php?queue=ethics',
    ],
    [
        'label' => 'URRC Review',
        'sub' => 'Research for technical review.',
        'count' => $rpsUrrcQueue,
        'icon' => 'bi-check2-square',
        'tone' => 'green',
        'url' => BASE_URL . '/research/rps_queue.php?queue=urrc',
    ],
    [
        'label' => 'In-House Review',
        'sub' => 'Research for final review.',
        'count' => $rpsInhouseQueue,
        'icon' => 'bi-folder2-open',
        'tone' => 'yellow',
        'url' => BASE_URL . '/research/rps_queue.php?queue=inhouse',
    ],
    [
        'label' => 'Notice to Proceed',
        'sub' => 'Passed research ready for NTP processing.',
        'count' => $rpsReadyForNtp,
        'icon' => 'bi-file-earmark-play',
        'tone' => 'green',
        'url' => BASE_URL . '/research/rps_queue.php?queue=ntp',
    ],
    [
        'label' => 'Permit Processing',
        'sub' => 'Terminal reports awaiting permit action.',
        'count' => $rpsPermitQueue,
        'icon' => 'bi-file-earmark-check',
        'tone' => 'yellow',
        'url' => BASE_URL . '/research/rps_queue.php?queue=permit',
    ],
];

$generalStatCards = [
    [
        'label' => 'Active Research',
        'sub' => 'Ongoing research records',
        'count' => $activeResearch,
        'icon' => 'bi-journal-text',
        'tone' => 'green',
        'url' => BASE_URL . '/research/index.php',
    ],
    [
        'label' => 'Extension Programs',
        'sub' => 'Community programs',
        'count' => $extensionPrograms,
        'icon' => 'bi-megaphone',
        'tone' => 'yellow',
        'url' => BASE_URL . '/extension/index.php',
    ],
    [
        'label' => 'Faculty Researchers',
        'sub' => 'Active faculty users',
        'count' => $facultyResearchers,
        'icon' => 'bi-people',
        'tone' => 'green',
        'url' => BASE_URL . '/admin/users/index.php',
    ],
    [
        'label' => 'Completed Projects',
        'sub' => 'Finished research work',
        'count' => $completedProjects,
        'icon' => 'bi-check-circle',
        'tone' => 'yellow',
        'url' => BASE_URL . '/reports/index.php',
    ],
];

$statCards = $userRole === 'rps' ? $rpsStatCards : $generalStatCards;

?>

<style>
:root {
    --asu-green: #007a33;
    --asu-green-dark: #005c26;
    --asu-green-deep: #003f1a;
    --asu-yellow: #ffd51f;
    --asu-orange: #ff6a00;
    --asu-white: #ffffff;
    --asu-black: #101810;
    --asu-muted: #657068;
    --asu-line: rgba(0, 122, 51, .16);
    --asu-soft: #f5faf6;
}

.main-page {
    background: #ffffff;
}

.page-content.dashboard-page {
    padding: 24px 28px 22px;
    background:
        radial-gradient(circle at 16% 2%, rgba(255, 213, 31, .13), transparent 28%),
        radial-gradient(circle at 92% 6%, rgba(0, 122, 51, .10), transparent 30%),
        linear-gradient(180deg, #f8fbf7 0%, #f3f8f4 100%);
}

.asu-dashboard-topbar {
    height: 76px;
    padding: 0 30px;
    border-bottom: 1px solid rgba(0, 122, 51, .12);
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: 0 10px 26px rgba(16, 24, 16, .035);
}

.asu-dashboard-brandline {
    display: flex;
    align-items: center;
    gap: 14px;
}

.asu-dashboard-brandline::before {
    content: '';
    width: 3px;
    height: 38px;
    border-radius: 999px;
    background: var(--asu-green);
}

.asu-dashboard-brandline strong {
    display: block;
    color: var(--asu-black);
    font-size: 17px;
    font-weight: 800;
    letter-spacing: -.015em;
}

.asu-dashboard-brandline span {
    display: block;
    margin-top: 2px;
    color: var(--asu-muted);
    font-size: 13px;
}

.asu-dashboard-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12px;
}

.dashboard-bell {
    position: relative;
    width: 42px;
    height: 42px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1px solid rgba(0, 122, 51, .13);
    border-radius: 14px;
    color: var(--asu-green-dark);
    background: #ffffff;
    text-decoration: none;
}

.dashboard-bell i {
    font-size: 20px;
}

.dashboard-bell-count {
    position: absolute;
    top: -8px;
    right: -8px;
    min-width: 22px;
    height: 22px;
    padding: 0 6px;
    border: 2px solid #ffffff;
    border-radius: 999px;
    background: var(--asu-orange);
    color: #ffffff;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 800;
}

.dashboard-user-mini {
    display: flex;
    align-items: center;
    gap: 12px;
}

.dashboard-user-copy {
    text-align: right;
}

.dashboard-user-copy strong {
    display: block;
    color: var(--asu-black);
    font-size: 15px;
    line-height: 1.1;
}

.dashboard-user-copy span {
    display: block;
    margin-top: 4px;
    color: var(--asu-muted);
    font-size: 12px;
}

.dashboard-avatar {
    width: 46px;
    height: 46px;
    border-radius: 50%;
    background: var(--asu-yellow);
    color: var(--asu-green-deep);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    box-shadow: 0 8px 18px rgba(255, 213, 31, .25);
}

.dashboard-shell {
    max-width: 1320px;
    margin: 0 auto;
}

.dashboard-hero {
    position: relative;
    overflow: hidden;
    min-height: 154px;
    padding: 28px 32px;
    border-radius: 18px;
    background:
        linear-gradient(112deg, rgba(0, 64, 28, .98), rgba(0, 122, 51, .96)),
        radial-gradient(circle at 80% 0%, rgba(255, 213, 31, .25), transparent 26%);
    color: #ffffff;
    box-shadow: 0 18px 42px rgba(0, 90, 40, .18);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 22px;
}

.dashboard-hero::before {
    content: '';
    display: none;
}

.dashboard-hero::after {
    content: '';
    position: absolute;
    right: -90px;
    top: -80px;
    width: 420px;
    height: 280px;
    border-radius: 42px;
    transform: rotate(-10deg);
    background: linear-gradient(135deg, rgba(255, 213, 31, .16), rgba(255, 255, 255, .035));
}

.hero-copy,
.hero-mark {
    position: relative;
    z-index: 1;
}

.hero-copy .greeting {
    margin: 0 0 6px;
    font-size: 21px;
    font-weight: 500;
    opacity: .95;
}

.hero-copy h1 {
    margin: 0 0 7px;
    font-size: 34px;
    font-weight: 900;
    letter-spacing: -.035em;
}

.hero-copy .role {
    margin: 0 0 16px;
    font-size: 16px;
    opacity: .96;
}

.hero-copy .tagline {
    margin: 0;
    font-size: 14px;
    opacity: .82;
}

.hero-mark {
    min-width: 330px;
    text-align: right;
}

.hero-mark strong {
    display: block;
    color: #ffffff;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: .42em;
}

.hero-mark span {
    display: inline-block;
    margin-top: 10px;
    padding-top: 9px;
    border-top: 2px solid var(--asu-yellow);
    color: rgba(255,255,255,.82);
    font-size: 11px;
    letter-spacing: .42em;
}

.dashboard-stat-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 16px;
    margin-top: 20px;
}

.dashboard-stat-card {
    position: relative;
    overflow: hidden;
    min-height: 132px;
    padding: 18px 18px 26px;
    border: 1px solid rgba(0, 122, 51, .14);
    border-radius: 16px;
    background: #ffffff;
    color: var(--asu-black);
    text-decoration: none;
    display: grid;
    grid-template-columns: 56px minmax(0, 1fr);
    align-items: center;
    gap: 14px;
    box-shadow: 0 14px 35px rgba(16, 24, 16, .055);
    transition: transform .20s ease, box-shadow .20s ease, border-color .20s ease;
}

.dashboard-stat-card:hover {
    transform: translateY(-3px);
    border-color: rgba(0, 122, 51, .24);
    box-shadow: 0 20px 42px rgba(16, 24, 16, .085);
}

.dashboard-stat-card::after {
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    bottom: -34px;
    height: 48px;
    border-radius: 50% 50% 0 0;
    opacity: .20;
    pointer-events: none;
}

.dashboard-stat-card.tone-green::after {
    background: var(--asu-green);
}

.dashboard-stat-card.tone-yellow::after {
    background: var(--asu-yellow);
    opacity: .32;
}

.stat-badge-icon {
    position: relative;
    z-index: 1;
    width: 56px;
    height: 56px;
    flex: 0 0 56px;
    border-radius: 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 25px;
}

.tone-green .stat-badge-icon {
    background: linear-gradient(135deg, var(--asu-green), var(--asu-green-dark));
    color: #ffffff;
    box-shadow: 0 12px 20px rgba(0, 122, 51, .25);
}

.tone-yellow .stat-badge-icon {
    background: linear-gradient(135deg, var(--asu-yellow), #f0bd00);
    color: var(--asu-green-deep);
    box-shadow: 0 12px 20px rgba(255, 213, 31, .30);
}

.stat-number-wrap {
    position: relative;
    z-index: 2;
    min-width: 0;
    align-self: center;
    padding-bottom: 8px;
}

.stat-number-wrap strong {
    display: block;
    margin-bottom: 5px;
    color: var(--asu-black);
    font-size: clamp(28px, 2.3vw, 34px);
    line-height: .95;
    font-weight: 900;
    letter-spacing: -.04em;
}

.stat-number-wrap span {
    display: block;
    max-width: 100%;
    color: var(--asu-black);
    font-size: clamp(13px, .98vw, 15px);
    line-height: 1.18;
    font-weight: 850;
    overflow-wrap: anywhere;
}

.stat-number-wrap small {
    display: block;
    max-width: 100%;
    margin-top: 5px;
    padding-right: 4px;
    color: #4e5f54;
    font-size: clamp(10.5px, .82vw, 12px);
    line-height: 1.22;
    overflow-wrap: anywhere;
}

.dashboard-two-column {
    display: grid;
    grid-template-columns: minmax(0, 1.18fr) minmax(360px, .82fr);
    gap: 16px;
    margin-top: 18px;
}

.dashboard-panel {
    overflow: hidden;
    border: 1px solid rgba(0, 122, 51, .13);
    border-radius: 16px;
    background: #ffffff;
    box-shadow: 0 14px 35px rgba(16, 24, 16, .055);
}

.dashboard-panel-header {
    padding: 18px 22px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
}

.dashboard-panel-title {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0;
    color: var(--asu-black);
    font-size: 19px;
    font-weight: 900;
    letter-spacing: -.02em;
}

.panel-icon-soft {
    width: 38px;
    height: 38px;
    border-radius: 12px;
    background: rgba(0, 122, 51, .09);
    color: var(--asu-green);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.panel-link-modern {
    padding: 9px 13px;
    border: 1px solid rgba(0, 122, 51, .13);
    border-radius: 12px;
    color: var(--asu-green-dark);
    background: #fbfefc;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    font-size: 12px;
    font-weight: 800;
}

.panel-link-modern:hover {
    color: var(--asu-green-dark);
    border-color: rgba(0, 122, 51, .24);
    background: rgba(0, 122, 51, .05);
}

.queue-list-modern,
.activity-list-modern {
    padding: 0 22px 14px;
}

.queue-row-modern {
    display: grid;
    grid-template-columns: minmax(0, 1fr) 52px 22px;
    align-items: center;
    gap: 12px;
    padding: 14px 0;
    border-top: 1px solid rgba(0, 122, 51, .10);
    color: var(--asu-black);
    text-decoration: none;
}

.queue-row-modern:first-child,
.activity-row-modern:first-child {
    border-top: 0;
}

.queue-row-left {
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr);
    align-items: center;
    gap: 13px;
    min-width: 0;
}

.queue-icon-modern {
    width: 42px;
    height: 42px;
    flex: 0 0 42px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 19px;
}

.queue-icon-modern.tone-green {
    background: rgba(0, 122, 51, .10);
    color: var(--asu-green);
}

.queue-icon-modern.tone-yellow {
    background: rgba(255, 213, 31, .25);
    color: #9a7500;
}

.queue-icon-modern.tone-orange {
    background: rgba(255, 106, 0, .12);
    color: var(--asu-orange);
}

.queue-copy-modern strong {
    display: block;
    color: var(--asu-black);
    font-size: 14px;
    font-weight: 850;
}

.queue-copy-modern span {
    display: block;
    margin-top: 2px;
    color: var(--asu-muted);
    font-size: 12px;
}

.queue-count-modern {
    width: 42px;
    min-width: 42px;
    height: 34px;
    padding: 0 10px;
    border-radius: 999px;
    background: rgba(0, 122, 51, .10);
    color: var(--asu-green-dark);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    justify-self: end;
    font-weight: 900;
    font-variant-numeric: tabular-nums;
}

.queue-row-modern.has-count .queue-count-modern {
    background: var(--asu-green);
    color: #ffffff;
}

.queue-arrow-modern {
    width: 22px;
    color: var(--asu-black);
    opacity: .75;
    font-size: 18px;
    text-align: right;
}

.activity-row-modern {
    display: grid;
    grid-template-columns: 14px minmax(0, 1fr) auto;
    gap: 12px;
    padding: 13px 0;
    border-top: 1px solid rgba(0, 122, 51, .10);
    align-items: start;
}

.activity-dot-modern {
    width: 12px;
    height: 12px;
    margin-top: 4px;
    border-radius: 50%;
    background: var(--asu-green);
}

.activity-dot-modern.orange {
    background: var(--asu-orange);
}

.activity-dot-modern.yellow {
    background: var(--asu-yellow);
    box-shadow: inset 0 0 0 1px rgba(0,0,0,.07);
}

.activity-copy-modern strong {
    display: block;
    color: var(--asu-black);
    font-size: 14px;
    font-weight: 850;
}

.activity-copy-modern span {
    display: block;
    margin-top: 2px;
    color: var(--asu-muted);
    font-size: 12px;
    line-height: 1.35;
}

.activity-time-modern {
    white-space: nowrap;
    color: var(--asu-muted);
    font-size: 12px;
}

.dashboard-announcement {
    margin-top: 18px;
}

.announcement-body {
    padding: 0 22px 20px;
}

.announcement-card {
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr) auto;
    gap: 14px;
    align-items: center;
    padding: 15px 18px;
    border-left: 4px solid var(--asu-orange);
    border-radius: 12px;
    background: linear-gradient(90deg, rgba(255, 106, 0, .13), rgba(255, 213, 31, .13));
}

.announcement-card i {
    color: var(--asu-orange);
    font-size: 21px;
}

.announcement-card strong {
    display: block;
    color: var(--asu-black);
    font-size: 14px;
}

.announcement-card span,
.announcement-date {
    color: var(--asu-muted);
    font-size: 12px;
}

.dashboard-empty-modern {
    padding: 28px 22px 34px;
    border-top: 1px solid rgba(0, 122, 51, .10);
    color: var(--asu-muted);
    text-align: center;
}

.dashboard-empty-modern i {
    display: inline-flex;
    width: 48px;
    height: 48px;
    align-items: center;
    justify-content: center;
    margin-bottom: 10px;
    border-radius: 50%;
    background: rgba(0, 122, 51, .08);
    color: var(--asu-green);
    font-size: 22px;
}

.dashboard-footer-clean {
    padding: 20px 0 0;
    color: rgba(16, 24, 16, .55);
    text-align: center;
    font-size: 12px;
}


/* Minimal dashboard motion: professional, not flashy */
@keyframes asuFadeUp {
    from {
        opacity: 0;
        transform: translateY(8px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes asuSoftGlow {
    0%, 100% {
        box-shadow: 0 14px 35px rgba(16, 24, 16, .055);
    }

    50% {
        box-shadow: 0 16px 38px rgba(0, 122, 51, .085);
    }
}

@media (prefers-reduced-motion: no-preference) {
    .dashboard-hero,
    .dashboard-stat-card,
    .dashboard-panel,
    .announcement-card {
        animation: asuFadeUp .36s ease both;
    }

    .dashboard-stat-card:nth-child(2) { animation-delay: .04s; }
    .dashboard-stat-card:nth-child(3) { animation-delay: .08s; }
    .dashboard-stat-card:nth-child(4) { animation-delay: .12s; }

    .dashboard-panel:nth-of-type(1) { animation-delay: .10s; }
    .dashboard-panel:nth-of-type(2) { animation-delay: .14s; }

    .queue-modern-row,
    .activity-modern-row,
    .panel-link-modern,
    .dashboard-user-mini,
    .dashboard-avatar {
        transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, background-color .18s ease;
    }

    .queue-modern-row:hover,
    .activity-modern-row:hover,
    .panel-link-modern:hover {
        transform: translateY(-1px);
    }
}

@media (max-width: 1180px) {
    .dashboard-stat-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .dashboard-two-column {
        grid-template-columns: 1fr;
    }

    .hero-mark {
        display: none;
    }
}

@media (max-width: 760px) {
    .page-content.dashboard-page {
        padding: 18px 14px;
    }

    .asu-dashboard-topbar {
        padding: 0 16px;
    }

    .dashboard-user-copy {
        display: none;
    }

    .dashboard-hero {
        padding: 24px 20px;
    }

    .hero-copy h1 {
        font-size: 27px;
    }

    .dashboard-stat-grid {
        grid-template-columns: 1fr;
    }

    .activity-row-modern {
        grid-template-columns: 14px minmax(0, 1fr);
    }

    .activity-time-modern {
        grid-column: 2;
    }

    .announcement-card {
        grid-template-columns: 36px 1fr;
    }

    .announcement-date {
        grid-column: 2;
    }
}


/* ==========================================================
   STAT CARDS FIT FIX
   Keeps labels inside each card and prevents overlap with wave.
========================================================== */
.dashboard-stat-grid {
    grid-template-columns: repeat(4, minmax(0, 1fr));
    align-items: stretch;
}

.dashboard-stat-card {
    min-height: 145px;
    padding: 18px 18px 24px;
    grid-template-columns: 58px minmax(0, 1fr);
    align-items: center;
    gap: 16px;
}

.dashboard-stat-card::after {
    z-index: 0;
    bottom: -34px;
    height: 54px;
    opacity: .20;
}

.dashboard-stat-card.tone-yellow::after {
    opacity: .32;
}

.stat-badge-icon,
.stat-number-wrap {
    position: relative;
    z-index: 2;
}

.stat-number-wrap {
    min-width: 0;
    padding-bottom: 8px;
}

.stat-number-wrap strong {
    margin-bottom: 6px;
    font-size: clamp(28px, 2.2vw, 34px);
    line-height: .95;
}

.stat-number-wrap span {
    max-width: 100%;
    font-size: clamp(13px, 1.05vw, 15px);
    line-height: 1.2;
    font-weight: 850;
    overflow-wrap: break-word;
    word-break: normal;
}

.stat-number-wrap small {
    max-width: 100%;
    margin-top: 6px;
    padding-right: 2px;
    color: #4e5f54;
    font-size: clamp(11px, .9vw, 12px);
    line-height: 1.25;
    overflow-wrap: break-word;
}

@media (max-width: 1280px) {
    .dashboard-stat-card {
        min-height: 138px;
        padding: 16px 15px 22px;
        grid-template-columns: 52px minmax(0, 1fr);
        gap: 14px;
    }

    .stat-badge-icon {
        width: 52px;
        height: 52px;
        flex-basis: 52px;
        font-size: 23px;
        border-radius: 15px;
    }

    .stat-number-wrap span {
        font-size: 13px;
        line-height: 1.18;
    }

    .stat-number-wrap small {
        font-size: 11px;
        line-height: 1.22;
    }
}

@media (max-width: 1100px) {
    .dashboard-stat-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 640px) {
    .dashboard-stat-grid {
        grid-template-columns: 1fr;
    }
}

</style>

<div class="main-page">

    <header class="asu-dashboard-topbar">
        <div class="asu-dashboard-brandline">
            <div>
                <strong>Research &amp; Extension Management System</strong>
                <span>Aklan State University</span>
            </div>
        </div>

        <div class="asu-dashboard-actions">

            <div class="dashboard-user-mini">
                <div class="dashboard-user-copy">
                    <strong><?= e(fullName($user)); ?></strong>
                    <span><?= e($displayRole); ?></span>
                </div>
                <div class="dashboard-avatar"><?= e($initials ?: 'U'); ?></div>
            </div>
        </div>
    </header>

    <main class="page-content dashboard-page">
        <div class="dashboard-shell">

            <section class="dashboard-hero">
                <div class="hero-copy">
                    <p class="greeting"><?= e($dashboardGreeting); ?></p>
                    <h1><?= e($firstName); ?>!</h1>
                    <p class="role"><?= e($displayRole); ?></p>
                    <p class="tagline">
                        <?php if ($userRole === 'rps'): ?>
                            Together for a stronger research culture.
                        <?php elseif ($userRole === 'faculty'): ?>
                            Track your research submissions, progress updates, and review results in one place.
                        <?php else: ?>
                            Manage research and extension records with clarity, security, and accountability.
                        <?php endif; ?>
                    </p>
                </div>

                <div class="hero-mark">
                    <strong>AKLAN STATE UNIVERSITY</strong>
                    <span>TRUTH · SERVICE · EXCELLENCE</span>
                </div>
            </section>

            <section class="dashboard-stat-grid">
                <?php foreach ($statCards as $card): ?>
                    <a href="<?= e($card['url']); ?>" class="dashboard-stat-card tone-<?= e($card['tone']); ?>">
                        <div class="stat-badge-icon">
                            <i class="bi <?= e($card['icon']); ?>"></i>
                        </div>
                        <div class="stat-number-wrap">
                            <strong><?= number_format((int)$card['count']); ?></strong>
                            <span><?= e($card['label']); ?></span>
                            <small><?= e($card['sub']); ?></small>
                        </div>
                    </a>
                <?php endforeach; ?>
            </section>

            <?php if ($userRole === 'rps'): ?>

                <section class="dashboard-two-column">
                    <div class="dashboard-panel">
                        <div class="dashboard-panel-header">
                            <h2 class="dashboard-panel-title">
                                <span class="panel-icon-soft"><i class="bi bi-list-task"></i></span>
                                Processing Queues
                            </h2>
                            <a href="<?= BASE_URL; ?>/dashboard.php?view=processing" class="panel-link-modern">
                                View All <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>

                        <div class="queue-list-modern">
                            <?php foreach ($rpsQueueItems as $item): ?>
                                <a
                                    href="<?= e($item['url']); ?>"
                                    class="queue-row-modern <?= ((int)$item['count'] > 0) ? 'has-count' : ''; ?>"
                                >
                                    <div class="queue-row-left">
                                        <span class="queue-icon-modern tone-<?= e($item['tone']); ?>">
                                            <i class="bi <?= e($item['icon']); ?>"></i>
                                        </span>
                                        <span class="queue-copy-modern">
                                            <strong><?= e($item['label']); ?></strong>
                                            <span><?= e($item['sub']); ?></span>
                                        </span>
                                    </div>

                                    <span class="queue-count-modern"><?= number_format((int)$item['count']); ?></span>
                                    <span class="queue-arrow-modern"><i class="bi bi-chevron-right"></i></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="dashboard-panel">
                        <div class="dashboard-panel-header">
                            <h2 class="dashboard-panel-title">
                                <span class="panel-icon-soft"><i class="bi bi-clock-history"></i></span>
                                Recent Activity
                            </h2>
                            <a href="<?= BASE_URL; ?>/notifications/index.php" class="panel-link-modern">
                                View All <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>

                        <?php if (!empty($dashboardActivities)): ?>
                            <div class="activity-list-modern">
                                <?php foreach ($dashboardActivities as $activity): ?>
                                    <?php
                                        $activityStatus = strtoupper((string)($activity['new_status'] ?? ''));
                                        $dotClass = str_contains($activityStatus, 'ETHICS') || str_contains($activityStatus, 'INHOUSE')
                                            ? 'yellow'
                                            : (str_contains($activityStatus, 'REVISION') || str_contains($activityStatus, 'REJECTED') || str_contains($activityStatus, 'FAILED') ? 'orange' : '');

                                        $activityBy = trim(
                                            (string)($activity['first_name'] ?? '') . ' ' .
                                            (string)($activity['last_name'] ?? '')
                                        );
                                    ?>
                                    <div class="activity-row-modern">
                                        <span class="activity-dot-modern <?= e($dotClass); ?>"></span>
                                        <span class="activity-copy-modern">
                                            <strong><?= e(asuDashboardActionLabel($activityStatus)); ?></strong>
                                            <span>
                                                <?= e($activityBy ?: 'System'); ?>
                                                ·
                                                <?= e($activity['manuscript_no'] ?: 'No manuscript number'); ?>
                                            </span>
                                        </span>
                                        <span class="activity-time-modern">
                                            <?= e(asuDashboardTimeAgo($activity['changed_at'] ?? null)); ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="dashboard-empty-modern">
                                <i class="bi bi-inbox"></i>
                                <p class="mb-0">No recent workflow activity yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

            <?php else: ?>

                <section class="dashboard-two-column">
                    <div class="dashboard-panel">
                        <div class="dashboard-panel-header">
                            <h2 class="dashboard-panel-title">
                                <span class="panel-icon-soft"><i class="bi bi-file-earmark-text"></i></span>
                                Recent Submissions
                            </h2>
                            <a href="<?= BASE_URL; ?>/research/index.php" class="panel-link-modern">
                                View Research <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>

                        <?php if (!empty($recentResearch)): ?>
                            <div class="queue-list-modern">
                                <?php foreach ($recentResearch as $item): ?>
                                    <a href="<?= BASE_URL; ?>/research/view.php?id=<?= (int)$item['id']; ?>" class="queue-row-modern">
                                        <div class="queue-row-left">
                                            <span class="queue-icon-modern tone-green">
                                                <i class="bi bi-journal-text"></i>
                                            </span>
                                            <span class="queue-copy-modern">
                                                <strong><?= e($item['title']); ?></strong>
                                                <span>
                                                    <?= e($item['manuscript_no'] ?: 'Draft'); ?>
                                                    ·
                                                    <?= e(dashboardResearchStatusLabel($item['current_status'])); ?>
                                                </span>
                                            </span>
                                        </div>
                                        <span class="queue-arrow-modern"><i class="bi bi-chevron-right"></i></span>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="dashboard-empty-modern">
                                <i class="bi bi-inbox"></i>
                                <p class="mb-0">No submissions yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="dashboard-panel">
                        <div class="dashboard-panel-header">
                            <h2 class="dashboard-panel-title">
                                <span class="panel-icon-soft"><i class="bi bi-clock-history"></i></span>
                                Recent Activity
                            </h2>
                            <a href="<?= BASE_URL; ?>/notifications/index.php" class="panel-link-modern">
                                View All <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>

                        <?php if (!empty($dashboardActivities)): ?>
                            <div class="activity-list-modern">
                                <?php foreach ($dashboardActivities as $activity): ?>
                                    <div class="activity-row-modern">
                                        <span class="activity-dot-modern"></span>
                                        <span class="activity-copy-modern">
                                            <strong><?= e(asuDashboardActionLabel((string)($activity['new_status'] ?? ''))); ?></strong>
                                            <span><?= e($activity['manuscript_no'] ?: 'No manuscript number'); ?></span>
                                        </span>
                                        <span class="activity-time-modern">
                                            <?= e(asuDashboardTimeAgo($activity['changed_at'] ?? null)); ?>
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="dashboard-empty-modern">
                                <i class="bi bi-inbox"></i>
                                <p class="mb-0">No recent activity yet.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

            <?php endif; ?>

            <section class="dashboard-panel dashboard-announcement">
                <div class="dashboard-panel-header">
                    <h2 class="dashboard-panel-title">
                        <span class="panel-icon-soft"><i class="bi bi-megaphone"></i></span>
                        Announcements
                    </h2>
                    <a href="<?= BASE_URL; ?>/notifications/index.php" class="panel-link-modern">
                        View All <i class="bi bi-arrow-right"></i>
                    </a>
                </div>

                <div class="announcement-body">
                    <div class="announcement-card">
                        <i class="bi bi-bell-fill"></i>
                        <div>
                            <strong>Call for Research Proposals</strong>
                            <span>Submission and processing updates will appear in ASU-REMS notifications.</span>
                        </div>
                        <span class="announcement-date"><?= date('M d, Y'); ?></span>
                    </div>
                </div>
            </section>

            <footer class="dashboard-footer-clean">
                © <?= date('Y'); ?> Aklan State University &nbsp; • &nbsp; Research &amp; Extension Management System
            </footer>

        </div>
    </main>
</div>

<?php
require __DIR__ . '/includes/footer.php';
?>
