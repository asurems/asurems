<?php

require_once __DIR__ . '/../includes/auth.php';

requireRole('admin');

$user = currentUser();

$pageTitle = 'Activity Logs';
$activePage = 'activity';


/*
|--------------------------------------------------------------------------
| PHASE 2 DESIGN VALUES
|--------------------------------------------------------------------------
|
| Activity logging is not yet connected to the database.
| Do not display fabricated audit records.
|
*/

$activityLogs = [];


/*
|--------------------------------------------------------------------------
| USER INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';

if (!empty($user['first_name'])) {

    $initials .= strtoupper(
        substr(
            $user['first_name'],
            0,
            1
        )
    );
}

if (!empty($user['last_name'])) {

    $initials .= strtoupper(
        substr(
            $user['last_name'],
            0,
            1
        )
    );
}


/*
|--------------------------------------------------------------------------
| LOAD LAYOUT
|--------------------------------------------------------------------------
*/

require __DIR__ . '/../includes/header.php';

require __DIR__ . '/../includes/sidebar.php';

?>


<div class="main-page">


    <!-- =====================================================
         TOP HEADER
    ====================================================== -->

    <header class="asu-topbar">


        <div class="topbar-left">


            <button
                id="sidebarToggle"
                type="button"
                class="sidebar-toggle"
                aria-label="Open navigation"
            >

                <i class="bi bi-list"></i>

            </button>


            <span class="system-name">

                Research & Extension Management System

            </span>


        </div>



        <div class="topbar-user">


            <div class="topbar-user-text">


                <strong>

                    <?= e(
                        fullName($user)
                    ); ?>

                </strong>


                <span>

                    Administrator

                </span>


            </div>



            <div class="user-avatar">

                <?= e($initials); ?>

            </div>


        </div>


    </header>



    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <main class="page-content">


        <!-- =================================================
             PAGE HEADING
        ================================================== -->

        <div class="page-heading">


            <div>


                <h1>

                    Activity Logs

                </h1>


                <p>

                    Review important system actions
                    for accountability and auditing.

                </p>


            </div>


        </div>



        <!-- =================================================
             FILTERS
        ================================================== -->

        <section class="filter-card">


            <div class="row g-2">


                <!-- SEARCH -->

                <div class="col-md-4">


                    <div class="input-group">


                        <span
                            class="input-group-text bg-white"
                        >

                            <i class="bi bi-search"></i>

                        </span>


                        <input
                            type="search"
                            class="form-control"
                            placeholder="Search user or action"
                            disabled
                        >


                    </div>


                </div>



                <!-- MODULE -->

                <div class="col-md-3">


                    <select
                        class="form-select"
                        disabled
                    >

                        <option selected>

                            All Modules

                        </option>


                        <option>

                            Authentication

                        </option>


                        <option>

                            Research

                        </option>


                        <option>

                            Extension

                        </option>


                        <option>

                            Users

                        </option>


                        <option>

                            Reports

                        </option>


                    </select>


                </div>



                <!-- DATE -->

                <div class="col-md-3">


                    <input
                        type="date"
                        class="form-control"
                        disabled
                    >


                </div>



                <!-- FILTER BUTTON -->

                <div class="col-md-2">


                    <button
                        type="button"
                        class="
                            btn
                            btn-outline-asu
                            w-100
                        "
                        disabled
                    >

                        <i class="bi bi-funnel me-1"></i>

                        Filter

                    </button>


                </div>


            </div>


        </section>



        <!-- =================================================
             ACTIVITY LOG PANEL
        ================================================== -->

        <section class="asu-panel">


            <div class="panel-header">


                <h2 class="panel-title">


                    <span class="panel-title-icon">

                        <i class="bi bi-clock-history"></i>

                    </span>


                    Recent Activities


                </h2>



                <span class="text-muted small">

                    0 records

                </span>


            </div>



            <!-- =================================================
                 EMPTY STATE
            ================================================== -->

            <div class="dashboard-empty-state">


                <div class="empty-state-icon">

                    <i class="bi bi-clock-history"></i>

                </div>


                <h3>

                    No activity logs available yet

                </h3>


                <p>

                    System activities will appear here
                    once actual audit logging is connected
                    to authentication, research, extension,
                    user management, and reporting actions.

                </p>


            </div>


        </section>



        <!-- =================================================
             MODULE INFORMATION
        ================================================== -->

        <section class="asu-panel mt-4">


            <div class="panel-header">


                <h2 class="panel-title">


                    <span class="panel-title-icon">

                        <i class="bi bi-shield-check"></i>

                    </span>


                    Audit Trail Coverage


                </h2>


            </div>



            <div class="panel-body">


                <div class="feature-grid">


                    <!-- AUTHENTICATION -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-box-arrow-in-right"></i>

                        </div>


                        <h5>

                            Authentication

                        </h5>


                        <p>

                            Login-related activity may be
                            recorded for authorized audit
                            and security review.

                        </p>


                    </div>



                    <!-- RESEARCH -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-journal-text"></i>

                        </div>


                        <h5>

                            Research Actions

                        </h5>


                        <p>

                            Proposal submission, evaluation,
                            revision, approval and project
                            updates may be recorded.

                        </p>


                    </div>



                    <!-- EXTENSION -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-megaphone"></i>

                        </div>


                        <h5>

                            Extension Actions

                        </h5>


                        <p>

                            Program creation, updates,
                            accomplishment reports and
                            document actions may be logged.

                        </p>


                    </div>



                    <!-- USERS -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-people"></i>

                        </div>


                        <h5>

                            User Management

                        </h5>


                        <p>

                            Account creation, editing,
                            activation and deactivation
                            may be included in the audit trail.

                        </p>


                    </div>



                    <!-- REPORTS -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-file-earmark-bar-graph"></i>

                        </div>


                        <h5>

                            Reports

                        </h5>


                        <p>

                            Important report-generation
                            actions may be recorded when
                            the reporting module is functional.

                        </p>


                    </div>



                    <!-- PRIVACY -->

                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-shield-lock"></i>

                        </div>


                        <h5>

                            Privacy-Aware Logging

                        </h5>


                        <p>

                            Logs should capture only the
                            information required for audit
                            purposes and avoid unnecessary
                            sensitive personal data.

                        </p>


                    </div>


                </div>


            </div>


        </section>



        <!-- =================================================
             DESIGN NOTICE
        ================================================== -->

        <div class="design-notice">


            <strong>
                Activity Logs Module:
            </strong>

            No sample activity records are displayed.
            Actual logs will appear only after the
            audit logging workflow is connected to
            real system actions.


        </div>



        <!-- =================================================
             FOOTER
        ================================================== -->

        <footer class="content-footer">


            <span>

                © <?= date('Y'); ?>
                Aklan State University

            </span>


            <span class="footer-divider">

                •

            </span>


            <span>

                Research & Extension Management System

            </span>


        </footer>


    </main>


</div>


<?php

require __DIR__ . '/../includes/footer.php';

?>