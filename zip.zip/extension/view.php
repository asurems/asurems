<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notifications.php';

requireLogin();


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    !in_array(
        $_SESSION['role'] ?? '',
        [
            'admin',
            'extension_coordinator'
        ],
        true
    )
) {

    redirect(
        BASE_URL . '/dashboard.php'
    );
}


/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/

$user = currentUser();

$pageTitle = 'Extension Program Details';
$activePage = 'extension';

$errors = [];


/*
|--------------------------------------------------------------------------
| EXTENSION ID
|--------------------------------------------------------------------------
*/

$extensionId =
    isset($_GET['id'])
        ? (int)$_GET['id']
        : 0;


if ($extensionId <= 0) {

    setFlash(
        'danger',
        'Invalid extension program record.'
    );

    redirect(
        BASE_URL . '/extension/index.php'
    );
}


/*
|--------------------------------------------------------------------------
| LOAD EXTENSION PROGRAM
|--------------------------------------------------------------------------
*/

function loadExtensionProgram(
    PDO $pdo,
    int $extensionId
): array|false {

    $stmt = $pdo->prepare("
        SELECT

            ep.extension_id,
            ep.coordinator_id,

            ep.program_title,
            ep.program_category,
            ep.program_type,

            ep.target_community,
            ep.municipality,
            ep.province,

            ep.objectives,
            ep.program_description,
            ep.expected_output,

            ep.funding_source,
            ep.estimated_budget,
            ep.target_participants,

            ep.start_date,
            ep.end_date,

            ep.status,
            ep.progress_percentage,

            ep.submitted_at,
            ep.approved_at,
            ep.completed_at,

            ep.created_at,
            ep.updated_at,

            u.first_name,
            u.middle_name,
            u.last_name,
            u.email,

            c.college_name,
            d.department_name

        FROM extension_programs ep

        INNER JOIN users u
            ON u.user_id = ep.coordinator_id

        LEFT JOIN colleges c
            ON c.college_id = ep.college_id

        LEFT JOIN departments d
            ON d.department_id = ep.department_id

        WHERE ep.extension_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $extensionId
    ]);

    return $stmt->fetch(
        PDO::FETCH_ASSOC
    );
}


$program =
    loadExtensionProgram(
        $pdo,
        $extensionId
    );


if (!$program) {

    setFlash(
        'danger',
        'Extension program not found.'
    );

    redirect(
        BASE_URL . '/extension/index.php'
    );
}


/*
|--------------------------------------------------------------------------
| RECORD ACCESS
|--------------------------------------------------------------------------
*/

if (
    $user['role'] === 'extension_coordinator'
    &&
    (int)$program['coordinator_id']
    !==
    (int)$user['user_id']
) {

    setFlash(
        'danger',
        'You are not authorized to view this extension program.'
    );

    redirect(
        BASE_URL . '/extension/index.php'
    );
}


if (
    $user['role'] === 'admin'
    &&
    $program['status'] === 'Draft'
) {

    setFlash(
        'danger',
        'Draft extension programs are private to the Extension Coordinator.'
    );

    redirect(
        BASE_URL . '/extension/index.php'
    );
}


/*
|--------------------------------------------------------------------------
| LOAD DOCUMENTS
|--------------------------------------------------------------------------
*/

$documentStmt =
    $pdo->prepare("
        SELECT

            document_id,
            extension_id,
            uploaded_by,
            document_type,

            original_name,
            stored_name,
            file_path,

            file_extension,
            file_size,

            uploaded_at

        FROM extension_documents

        WHERE extension_id = ?

        ORDER BY
            uploaded_at DESC,
            document_id DESC
    ");


$documentStmt->execute([
    $extensionId
]);


$documents =
    $documentStmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| DOCUMENT VIEWER / FILE HANDLER
|--------------------------------------------------------------------------
|
| file_mode=view
| - Shows an ASU-REMS document viewer page with a Download button.
|
| file_mode=inline
| - Streams PDF only inside the viewer iframe.
|
| file_mode=download
| - Downloads the actual uploaded file.
|
*/

$viewerDocument = null;
$viewerPhysicalPath = null;
$viewerExtension = null;
$viewerDownloadUrl = null;
$viewerInlineUrl = null;
$viewerPreviewText = null;
$viewerPreviewError = null;


function streamExtensionUploadedFile(
    string $physicalPath,
    string $originalName,
    string $extension,
    bool $inline = false
): never {

    $mimeTypes = [

        'pdf' =>
            'application/pdf',

        'doc' =>
            'application/msword',

        'docx' =>
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'

    ];


    $mimeType =
        $mimeTypes[$extension]
        ??
        'application/octet-stream';


    $downloadName =
        basename(
            $originalName
        );


    $asciiName =
        preg_replace(
            '/[^A-Za-z0-9._-]/',
            '_',
            $downloadName
        );


    header(
        'Content-Type: ' .
        $mimeType
    );


    header(
        'Content-Length: ' .
        filesize(
            $physicalPath
        )
    );


    header(
        'Content-Disposition: ' .
        (
            $inline
                ? 'inline'
                : 'attachment'
        )
        .
        '; filename="' .
        $asciiName .
        '"; filename*=UTF-8\'\'' .
        rawurlencode(
            $downloadName
        )
    );


    header(
        'X-Content-Type-Options: nosniff'
    );


    header(
        'Cache-Control: private, max-age=0, must-revalidate'
    );


    readfile(
        $physicalPath
    );


    exit;
}


function extractExtensionDocxText(
    string $physicalPath
): array {

    if (
        !class_exists(
            'ZipArchive'
        )
    ) {

        return [
            false,
            '',
            'DOCX preview requires the PHP ZIP extension. You can still download the uploaded file.'
        ];
    }


    $zip =
        new ZipArchive();


    if (
        $zip->open(
            $physicalPath
        )
        !== true
    ) {

        return [
            false,
            '',
            'Unable to read this DOCX file for browser preview. You can still download the uploaded file.'
        ];
    }


    $xml =
        $zip->getFromName(
            'word/document.xml'
        );


    $zip->close();


    if (
        $xml === false
        ||
        trim(
            $xml
        )
        === ''
    ) {

        return [
            false,
            '',
            'No readable document text was found in this DOCX file. You can still download the uploaded file.'
        ];
    }


    $xml =
        preg_replace(
            '/<w:tab\s*\/>/i',
            "\t",
            $xml
        );


    $xml =
        preg_replace(
            '/<w:br\s*\/>/i',
            "\n",
            $xml
        );


    $xml =
        preg_replace(
            '/<\/w:p>/i',
            "\n\n",
            $xml
        );


    $text =
        strip_tags(
            $xml
        );


    $text =
        html_entity_decode(
            $text,
            ENT_QUOTES | ENT_XML1,
            'UTF-8'
        );


    $text =
        preg_replace(
            "/[ \t]+/",
            ' ',
            $text
        );


    $text =
        preg_replace(
            "/\n{3,}/",
            "\n\n",
            $text
        );


    $text =
        trim(
            $text
        );


    if (
        $text === ''
    ) {

        return [
            false,
            '',
            'The DOCX file was opened, but no readable text was detected. You can still download the uploaded file.'
        ];
    }


    return [
        true,
        $text,
        null
    ];
}


if (
    isset(
        $_GET['document_id']
    )
) {

    $documentId =
        (int)$_GET['document_id'];

    $fileMode =
        $_GET['file_mode']
        ?? 'view';


    if (
        $documentId <= 0
    ) {

        http_response_code(400);

        exit(
            'Invalid document request.'
        );
    }


    if (
        !in_array(
            $fileMode,
            [
                'view',
                'inline',
                'download'
            ],
            true
        )
    ) {

        $fileMode =
            'view';
    }


    $fileStmt =
        $pdo->prepare("
            SELECT

                document_id,
                extension_id,

                document_type,
                original_name,
                stored_name,
                file_path,

                file_extension,
                file_size,
                uploaded_at

            FROM extension_documents

            WHERE document_id = ?
              AND extension_id = ?

            LIMIT 1
        ");


    $fileStmt->execute([
        $documentId,
        $extensionId
    ]);


    $fileDocument =
        $fileStmt->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$fileDocument) {

        http_response_code(404);

        exit(
            'Document record not found.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | RESOLVE PHYSICAL FILE
    |--------------------------------------------------------------------------
    */

    $relativePath =
        str_replace(
            [
                '\\',
                "\0"
            ],
            [
                '/',
                ''
            ],
            $fileDocument['file_path']
        );


    $relativePath =
        ltrim(
            $relativePath,
            '/'
        );


    if (
        !str_starts_with(
            $relativePath,
            'uploads/extension/'
        )
    ) {

        http_response_code(403);

        exit(
            'Invalid document path.'
        );
    }


    $projectRoot =
        realpath(
            __DIR__ . '/..'
        );


    $physicalPath =
        $projectRoot
        .
        DIRECTORY_SEPARATOR
        .
        str_replace(
            '/',
            DIRECTORY_SEPARATOR,
            $relativePath
        );


    if (
        !is_file(
            $physicalPath
        )
    ) {

        http_response_code(404);

        exit(
            'The uploaded document file could not be found.'
        );
    }


    $extension =
        strtolower(
            (string)$fileDocument[
                'file_extension'
            ]
        );


    /*
    |--------------------------------------------------------------------------
    | DOWNLOAD
    |--------------------------------------------------------------------------
    */

    if (
        $fileMode === 'download'
    ) {

        streamExtensionUploadedFile(
            $physicalPath,
            $fileDocument['original_name'],
            $extension,
            false
        );
    }


    /*
    |--------------------------------------------------------------------------
    | INLINE PDF STREAM FOR VIEWER IFRAME
    |--------------------------------------------------------------------------
    */

    if (
        $fileMode === 'inline'
    ) {

        if (
            $extension !== 'pdf'
        ) {

            http_response_code(415);

            exit(
                'Inline preview is available for PDF files only.'
            );
        }


        streamExtensionUploadedFile(
            $physicalPath,
            $fileDocument['original_name'],
            $extension,
            true
        );
    }


    /*
    |--------------------------------------------------------------------------
    | VIEWER PAGE
    |--------------------------------------------------------------------------
    */

    $viewerDocument =
        $fileDocument;

    $viewerPhysicalPath =
        $physicalPath;

    $viewerExtension =
        $extension;

    $viewerDownloadUrl =
        BASE_URL .
        '/extension/view.php?id=' .
        $extensionId .
        '&document_id=' .
        $documentId .
        '&file_mode=download';

    $viewerInlineUrl =
        BASE_URL .
        '/extension/view.php?id=' .
        $extensionId .
        '&document_id=' .
        $documentId .
        '&file_mode=inline';


    if (
        $viewerExtension === 'docx'
    ) {

        [
            $previewSuccess,
            $previewText,
            $previewError
        ] =
            extractExtensionDocxText(
                $viewerPhysicalPath
            );


        if (
            $previewSuccess
        ) {

            $viewerPreviewText =
                $previewText;

        } else {

            $viewerPreviewError =
                $previewError;
        }
    }


    if (
        $viewerExtension === 'doc'
    ) {

        $viewerPreviewError =
            'DOC files cannot be reliably previewed in the browser. Please download the uploaded file to open it in Microsoft Word or another compatible application.';
    }
}


/*
|--------------------------------------------------------------------------
| DOCUMENT REQUIREMENT
|--------------------------------------------------------------------------
*/

$hasProgramProposalDocument = false;


foreach (
    $documents
    as
    $document
) {

    if (
        $document['document_type']
        === 'Program Proposal'
    ) {

        $hasProgramProposalDocument = true;

        break;
    }
}


/*
|--------------------------------------------------------------------------
| SUBMIT PROGRAM FOR REVIEW
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    $action =
        $_POST['action']
        ?? '';


    if (
        !verifyCsrfToken(
            $_POST['csrf_token'] ?? ''
        )
    ) {

        $errors[] =
            'Invalid request. Please refresh the page and try again.';
    }


    if (
        $action === 'submit_for_review'
        &&
        !$errors
    ) {

        if (
            $user['role']
            !== 'extension_coordinator'
        ) {

            $errors[] =
                'Only the assigned Extension Coordinator may submit this program.';
        }


        if (
            (int)$program['coordinator_id']
            !==
            (int)$user['user_id']
        ) {

            $errors[] =
                'You are not authorized to submit this extension program.';
        }


        if (
            $program['status']
            !== 'Draft'
        ) {

            $errors[] =
                'Only Draft extension programs can be submitted for review.';
        }


        if (
            !$hasProgramProposalDocument
        ) {

            $errors[] =
                'A supporting Program Proposal document is required before submission.';
        }


        if (!$errors) {

            try {

                $pdo->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | LOCK CURRENT RECORD
                |--------------------------------------------------------------------------
                */

                $checkStmt =
                    $pdo->prepare("
                        SELECT
                            coordinator_id,
                            status

                        FROM extension_programs

                        WHERE extension_id = ?

                        FOR UPDATE
                    ");


                $checkStmt->execute([
                    $extensionId
                ]);


                $currentRecord =
                    $checkStmt->fetch(
                        PDO::FETCH_ASSOC
                    );


                if (
                    !$currentRecord
                    ||
                    (int)$currentRecord['coordinator_id']
                    !==
                    (int)$user['user_id']
                    ||
                    $currentRecord['status']
                    !== 'Draft'
                ) {

                    throw new RuntimeException(
                        'Extension program is no longer available for submission.'
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | UPDATE STATUS
                |--------------------------------------------------------------------------
                */

                $update =
                    $pdo->prepare("
                        UPDATE extension_programs

                        SET
                            status = 'Submitted',
                            submitted_at = NOW()

                        WHERE extension_id = ?
                          AND coordinator_id = ?
                          AND status = 'Draft'
                    ");


                $update->execute([

                    $extensionId,

                    (int)$user['user_id']

                ]);


                if (
                    $update->rowCount()
                    !== 1
                ) {

                    throw new RuntimeException(
                        'Unable to update extension program status.'
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | STATUS HISTORY
                |--------------------------------------------------------------------------
                */

                $history =
                    $pdo->prepare("
                        INSERT INTO extension_status_history
                        (
                            extension_id,
                            changed_by,
                            old_status,
                            new_status,
                            remarks
                        )
                        VALUES
                        (
                            ?,
                            ?,
                            'Draft',
                            'Submitted',
                            ?
                        )
                    ");


                $history->execute([

                    $extensionId,

                    (int)$user['user_id'],

                    'Extension program submitted for administrative review.'

                ]);


                notifyUsersByRole(
                    $pdo,
                    ['admin'],
                    'New extension program submitted',
                    fullName($user) .
                    ' submitted an extension program for administrative review: ' .
                    $program['program_title'],
                    'extension',
                    $extensionId,
                    BASE_URL . '/extension/view.php?id=' . $extensionId,
                    (int)$user['user_id']
                );


                $pdo->commit();


                setFlash(
                    'success',
                    'Extension program submitted successfully for review.'
                );


                redirect(
                    BASE_URL .
                    '/extension/view.php?id=' .
                    $extensionId
                );


            } catch (
                Throwable $e
            ) {

                if (
                    $pdo->inTransaction()
                ) {

                    $pdo->rollBack();
                }


                $errors[] =
                    'Unable to submit the extension program. Please try again.';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| RELOAD AFTER POST
|--------------------------------------------------------------------------
*/

$program =
    loadExtensionProgram(
        $pdo,
        $extensionId
    );


/*
|--------------------------------------------------------------------------
| STATUS HISTORY
|--------------------------------------------------------------------------
*/

$historyStmt =
    $pdo->prepare("
        SELECT

            esh.history_id,
            esh.old_status,
            esh.new_status,
            esh.remarks,
            esh.changed_at,

            u.first_name,
            u.middle_name,
            u.last_name

        FROM extension_status_history esh

        INNER JOIN users u
            ON u.user_id = esh.changed_by

        WHERE esh.extension_id = ?

        ORDER BY
            esh.changed_at DESC,
            esh.history_id DESC
    ");


$historyStmt->execute([
    $extensionId
]);


$statusHistory =
    $historyStmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| COORDINATOR NAME
|--------------------------------------------------------------------------
*/

$coordinatorName =
    trim(
        $program['first_name']
        .
        ' '
        .
        (
            !empty(
                $program['middle_name']
            )
                ? $program['middle_name']
                . ' '
                : ''
        )
        .
        $program['last_name']
    );


/*
|--------------------------------------------------------------------------
| STATUS CLASS / ICON
|--------------------------------------------------------------------------
*/

$statusClass =
    'extension-status-draft';

$statusIcon =
    'bi-pencil-square';


switch (
    $program['status']
) {

    case 'Submitted':

        $statusClass =
            'extension-status-submitted';

        $statusIcon =
            'bi-send-check';

        break;


    case 'Under Review':

        $statusClass =
            'extension-status-review';

        $statusIcon =
            'bi-search';

        break;


    case 'For Revision':

        $statusClass =
            'extension-status-revision';

        $statusIcon =
            'bi-arrow-repeat';

        break;


    case 'Approved':

        $statusClass =
            'extension-status-approved';

        $statusIcon =
            'bi-check-circle';

        break;


    case 'Ongoing':

        $statusClass =
            'extension-status-ongoing';

        $statusIcon =
            'bi-play-circle';

        break;


    case 'Completed':

        $statusClass =
            'extension-status-completed';

        $statusIcon =
            'bi-award';

        break;


    case 'Rejected':

        $statusClass =
            'extension-status-rejected';

        $statusIcon =
            'bi-x-circle';

        break;


    case 'Archived':

        $statusClass =
            'extension-status-archived';

        $statusIcon =
            'bi-archive';

        break;
}


/*
|--------------------------------------------------------------------------
| FILE SIZE
|--------------------------------------------------------------------------
*/

function extensionFileSize(
    ?int $bytes
): string {

    if (
        !$bytes
        ||
        $bytes <= 0
    ) {

        return 'Unknown size';
    }


    if (
        $bytes >=
        1024 * 1024
    ) {

        return
            number_format(
                $bytes /
                (1024 * 1024),
                2
            )
            .
            ' MB';
    }


    if (
        $bytes >= 1024
    ) {

        return
            number_format(
                $bytes / 1024,
                2
            )
            .
            ' KB';
    }


    return
        number_format(
            $bytes
        )
        .
        ' bytes';
}


/*
|--------------------------------------------------------------------------
| EDIT PAGE AVAILABILITY
|--------------------------------------------------------------------------
*/

$editPageExists =
    is_file(
        __DIR__ .
        '/edit.php'
    );


/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$flash =
    getFlash();


/*
|--------------------------------------------------------------------------
| INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';

if (
    !empty(
        $user['first_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['first_name'],
                0,
                1
            )
        );
}


if (
    !empty(
        $user['last_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['last_name'],
                0,
                1
            )
        );
}


/*
|--------------------------------------------------------------------------
| LOAD LAYOUT
|--------------------------------------------------------------------------
*/

require __DIR__ .
    '/../includes/header.php';

require __DIR__ .
    '/../includes/sidebar.php';

?>


<style>

/* =========================================================
   PAGE
========================================================= */

.extension-view {
    max-width: 1200px;
    margin: 0 auto;
}


.extension-view-heading {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 22px;
}


.extension-view-heading h1 {
    margin: 0 0 5px;
    font-size: 25px;
    font-weight: 700;
}


.extension-view-heading p {
    margin: 0;
    color: var(--asu-muted);
    font-size: 11px;
}


.extension-heading-actions {
    display: flex;
    gap: 8px;
}


/* =========================================================
   ERROR
========================================================= */

.extension-errors {
    margin-bottom: 18px;
    padding: 14px 17px;
    border: 1px solid #edcccc;
    border-radius: 10px;
    background: #fff6f6;
    color: #873b3b;
    font-size: 11px;
}


/* =========================================================
   SUMMARY
========================================================= */

.extension-summary {
    margin-bottom: 16px;
    padding: 22px;
    border-radius: 15px;
    background:
        linear-gradient(
            120deg,
            #08742c,
            #086126
        );
    color: #ffffff;
}


.extension-summary-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
}


.extension-summary h2 {
    max-width: 850px;
    margin: 0 0 9px;
    color: #ffffff;
    font-size: 20px;
    font-weight: 700;
    line-height: 1.4;
}


.extension-summary-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 8px 18px;
    color: rgba(255, 255, 255, .77);
    font-size: 10px;
}


/* =========================================================
   STATUS
========================================================= */

.extension-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 29px;
    padding: 5px 11px;
    border-radius: 50px;
    font-size: 9px;
    font-weight: 700;
    white-space: nowrap;
}


.extension-status-draft {
    background: #eef1ef;
    color: #626b64;
}


.extension-status-submitted {
    background: #e7f0ff;
    color: #365f99;
}


.extension-status-review {
    background: #fff4c8;
    color: #78620b;
}


.extension-status-revision {
    background: #fff0e2;
    color: #9a551c;
}


.extension-status-approved,
.extension-status-ongoing,
.extension-status-completed {
    background: #e4f4e8;
    color: #23703e;
}


.extension-status-rejected {
    background: #fde8e8;
    color: #a13939;
}


.extension-status-archived {
    background: #ebecef;
    color: #60656e;
}


/* =========================================================
   CURRENT STATUS
========================================================= */

.extension-status-overview {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
    padding: 17px 19px;
    background: #ffffff;
    border: 1px solid var(--asu-border);
    border-radius: 13px;
}


.extension-status-overview-icon {
    width: 45px;
    height: 45px;
    min-width: 45px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: #edf7ef;
    color: var(--asu-green);
    font-size: 19px;
}


.extension-status-overview-content {
    flex: 1;
    min-width: 0;
}


.extension-status-label {
    display: block;
    margin-bottom: 2px;
    color: #8a938c;
    font-size: 8px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .05em;
}


.extension-status-overview h3 {
    margin: 0 0 4px;
    color: #293129;
    font-size: 14px;
    font-weight: 700;
}


.extension-status-overview p {
    max-width: 750px;
    margin: 0;
    color: #727c74;
    font-size: 9px;
    line-height: 1.65;
}


/* =========================================================
   GRID
========================================================= */

.extension-grid {
    display: grid;
    grid-template-columns:
        minmax(0, 1.6fr)
        minmax(280px, .75fr);
    gap: 20px;
    align-items: start;
}


.extension-column {
    display: grid;
    gap: 20px;
}


/* =========================================================
   PANEL
========================================================= */

.extension-panel {
    overflow: hidden;
    background: #ffffff;
    border: 1px solid var(--asu-border);
    border-radius: 14px;
}


.extension-panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    min-height: 60px;
    padding: 15px 20px;
    border-bottom: 1px solid #edf1ed;
}


.extension-panel-title {
    display: flex;
    align-items: center;
    gap: 9px;
    margin: 0;
    color: #283029;
    font-size: 13px;
    font-weight: 700;
}


.extension-panel-icon {
    width: 34px;
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: #edf7ef;
    color: var(--asu-green);
    font-size: 15px;
}


.extension-panel-body {
    padding: 20px;
}


/* =========================================================
   INFORMATION
========================================================= */

.info-grid {
    display: grid;
    grid-template-columns:
        repeat(
            2,
            minmax(0, 1fr)
        );
    gap: 18px;
}


.info-item label {
    display: block;
    margin-bottom: 5px;
    color: #8a938c;
    font-size: 9px;
    font-weight: 600;
    text-transform: uppercase;
}


.info-item strong {
    display: block;
    color: #343c36;
    font-size: 11px;
    line-height: 1.6;
}


/* =========================================================
   CONTENT
========================================================= */

.content-block {
    padding: 17px 0;
    border-bottom: 1px solid #edf1ed;
}


.content-block:first-child {
    padding-top: 0;
}


.content-block:last-child {
    padding-bottom: 0;
    border-bottom: 0;
}


.content-block h4 {
    margin: 0 0 7px;
    font-size: 11px;
    font-weight: 700;
}


.content-block p {
    margin: 0;
    color: #626c64;
    font-size: 11px;
    line-height: 1.75;
    white-space: pre-line;
}


/* =========================================================
   DOCUMENTS
========================================================= */

.document-list {
    display: grid;
    gap: 10px;
}


.document-item {
    display: flex;
    align-items: center;

    gap: 11px;

    padding: 12px;

    border:
        1px solid #e4e9e5;

    border-radius: 9px;

    background: #fafcfa;
}


.document-item-link {
    width: 100%;

    color: inherit;

    text-decoration: none;

    cursor: pointer;

    transition:
        background .18s ease,
        border-color .18s ease,
        transform .18s ease;
}


.document-item-link:hover {
    color: inherit;

    background: #f2f8f3;

    border-color: #b7cfbd;

    transform: translateY(-1px);
}


.document-item-link:focus-visible {
    outline: 3px solid rgba(8, 117, 44, .16);

    outline-offset: 2px;
}


.document-icon {
    width: 38px;
    height: 38px;

    min-width: 38px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: #eaf5ec;

    color: var(--asu-green);
}


.document-info {
    flex: 1;

    min-width: 0;
}


.document-open-icon {
    width: 34px;
    height: 34px;

    min-width: 34px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 8px;

    background: #edf7ef;

    color: var(--asu-green);

    font-size: 13px;
}


.document-info strong {
    display: block;

    overflow: hidden;

    margin-bottom: 3px;

    color: #343c36;

    font-size: 10px;

    text-overflow: ellipsis;

    white-space: nowrap;
}


.document-info small {
    color: #8a928c;

    font-size: 8px;
}


/* =========================================================
   EMPTY
========================================================= */

.empty-data {
    padding: 20px 10px;
    color: #8a938c;
    font-size: 10px;
    text-align: center;
}


/* =========================================================
   HISTORY
========================================================= */

.timeline-item {
    padding: 12px 0;
    border-bottom: 1px solid #edf1ed;
}


.timeline-item:first-child {
    padding-top: 0;
}


.timeline-item:last-child {
    border-bottom: 0;
    padding-bottom: 0;
}


.timeline-item strong {
    display: block;
    margin-bottom: 4px;
    font-size: 10px;
}


.timeline-item small {
    display: block;
    color: #8a938c;
    font-size: 8px;
}


.timeline-item p {
    margin: 5px 0 0;
    color: #656e67;
    font-size: 9px;
    line-height: 1.6;
}


/* =========================================================
   WORKFLOW
========================================================= */

.workflow-card {
    margin-top: 20px;
    padding: 18px 20px;
    border: 1px solid #e2e8e2;
    border-radius: 13px;
    background: #ffffff;
}


.workflow-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}


.workflow-text h4 {
    margin: 0 0 4px;
    color: #303830;
    font-size: 12px;
    font-weight: 700;
}


.workflow-text p {
    max-width: 680px;
    margin: 0;
    color: #7a837c;
    font-size: 9px;
    line-height: 1.6;
}


.workflow-buttons {
    display: flex;
    gap: 8px;
    flex-shrink: 0;
}


.workflow-notice {
    margin-top: 12px;
    padding: 10px 12px;
    border-left: 3px solid #d7ad23;
    border-radius: 7px;
    background: #fff9e5;
    color: #6e5d23;
    font-size: 9px;
    line-height: 1.6;
}


/* =========================================================
   DOCUMENT VIEWER
========================================================= */

.extension-document-viewer {
    overflow: hidden;

    background: #ffffff;

    border:
        1px solid
        var(--asu-border);

    border-radius: 14px;
}


.extension-document-viewer-header {
    display: flex;
    align-items: center;
    justify-content: space-between;

    gap: 16px;

    padding: 15px 18px;

    border-bottom:
        1px solid #edf1ed;
}


.extension-document-viewer-title {
    display: flex;
    align-items: center;

    gap: 11px;

    min-width: 0;
}


.extension-document-viewer-title strong {
    display: block;

    overflow: hidden;

    color: #293129;

    font-size: 13px;

    text-overflow: ellipsis;

    white-space: nowrap;
}


.extension-document-viewer-title small {
    display: block;

    margin-top: 3px;

    color: #838c85;

    font-size: 9px;
}


.extension-document-viewer-actions {
    display: flex;
    align-items: center;

    gap: 8px;

    flex-shrink: 0;
}


.extension-document-frame {
    width: 100%;
    min-height: 760px;

    border: 0;

    background: #f8faf8;
}


.extension-docx-preview {
    min-height: 650px;

    padding: 28px;

    background: #f8faf8;
}


.extension-docx-page {
    max-width: 820px;

    margin: 0 auto;

    padding: 34px 40px;

    background: #ffffff;

    border:
        1px solid #e1e8e1;

    border-radius: 10px;

    color: #2f3831;

    font-size: 12px;

    line-height: 1.75;

    white-space: pre-wrap;

    box-shadow:
        0 10px 28px rgba(30, 64, 34, .08);
}


.extension-preview-message {
    min-height: 430px;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 34px;

    background: #f8faf8;

    text-align: center;
}


.extension-preview-message-box {
    max-width: 520px;

    padding: 28px;

    background: #ffffff;

    border:
        1px solid #e1e8e1;

    border-radius: 13px;
}


.extension-preview-message-icon {
    width: 58px;
    height: 58px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin: 0 auto 14px;

    border-radius: 50%;

    background: #edf7ef;

    color: var(--asu-green);

    font-size: 24px;
}


.extension-preview-message-box h3 {
    margin: 0 0 8px;

    color: #293129;

    font-size: 15px;

    font-weight: 700;
}


.extension-preview-message-box p {
    margin: 0 0 16px;

    color: #6f7871;

    font-size: 10px;

    line-height: 1.7;
}



/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 1000px) {

    .extension-grid {
        grid-template-columns: 1fr;
    }
}


@media (max-width: 700px) {

    .extension-view-heading,
    .extension-summary-top,
    .workflow-content {

        flex-direction: column;
    }


    .info-grid {
        grid-template-columns: 1fr;
    }


    .extension-heading-actions,
    .workflow-buttons {
        width: 100%;
        flex-direction: column;
    }


    .extension-heading-actions .btn,
    .workflow-buttons .btn {
        width: 100%;
    }


    .extension-status-overview {
        align-items: flex-start;
        flex-wrap: wrap;
    }
}

</style>


<div class="main-page">


<header class="asu-topbar">


<div class="topbar-left">


<button
    id="sidebarToggle"
    type="button"
    class="sidebar-toggle"
>

<i class="bi bi-list"></i>

</button>


<span class="system-name">

Research & Extension Management System

</span>


</div>



<div class="topbar-user">


<div class="topbar-user-text">


<strong>

<?= e(
    fullName($user)
); ?>

</strong>


<span>

<?= e(
    roleLabel(
        $user['role']
    )
); ?>

</span>


</div>


<div class="user-avatar">

<?= e(
    $initials
); ?>

</div>


</div>


</header>



<main class="page-content">


<div class="extension-view">


<?php if (
    $viewerDocument
): ?>


<!-- =====================================================
     DOCUMENT VIEWER
====================================================== -->

<div class="extension-view-heading">


<div>


<h1>

Document Viewer

</h1>


<p>

View or read the uploaded extension document
inside ASU-REMS, then download the file when needed.

</p>


</div>


<div class="extension-heading-actions">


<a
    href="<?= BASE_URL; ?>/extension/view.php?id=<?= $extensionId; ?>"
    class="btn btn-outline-asu"
>

<i class="bi bi-arrow-left me-1"></i>

Back to Program Details

</a>


<a
    href="<?= e($viewerDownloadUrl); ?>"
    class="btn btn-asu"
>

<i class="bi bi-download me-1"></i>

Download

</a>


</div>


</div>


<section class="extension-document-viewer">


<div class="extension-document-viewer-header">


<div class="extension-document-viewer-title">


<div class="document-icon">


<?php if (
    $viewerExtension === 'pdf'
): ?>

<i class="bi bi-file-earmark-pdf"></i>

<?php else: ?>

<i class="bi bi-file-earmark-word"></i>

<?php endif; ?>


</div>


<div>


<strong>

<?= e(
    $viewerDocument[
        'original_name'
    ]
); ?>

</strong>


<small>

<?= e(
    $viewerDocument[
        'document_type'
    ]
); ?>

·

<?= e(
    extensionFileSize(
        $viewerDocument[
            'file_size'
        ]
        !== null
            ? (int)$viewerDocument[
                'file_size'
            ]
            : null
    )
); ?>

· Uploaded

<?= e(
    date(
        'M d, Y',
        strtotime(
            $viewerDocument[
                'uploaded_at'
            ]
        )
    )
); ?>

</small>


</div>


</div>


<div class="extension-document-viewer-actions">


<a
    href="<?= e($viewerDownloadUrl); ?>"
    class="btn btn-asu btn-sm"
>

<i class="bi bi-download me-1"></i>

Download File

</a>


</div>


</div>



<?php if (
    $viewerExtension === 'pdf'
): ?>


<iframe
    src="<?= e($viewerInlineUrl); ?>"
    class="extension-document-frame"
    title="<?= e(
        $viewerDocument[
            'original_name'
        ]
    ); ?>"
></iframe>


<?php elseif (
    $viewerExtension === 'docx'
    &&
    $viewerPreviewText !== null
): ?>


<div class="extension-docx-preview">


<div class="extension-docx-page">

<?= e(
    $viewerPreviewText
); ?>

</div>


</div>


<?php else: ?>


<div class="extension-preview-message">


<div class="extension-preview-message-box">


<div class="extension-preview-message-icon">

<i class="bi bi-file-earmark-word"></i>

</div>


<h3>

Preview Not Available

</h3>


<p>

<?= e(
    $viewerPreviewError
    ?: 'This document type cannot be previewed in the browser. Please download the file to open it.'
); ?>

</p>


<a
    href="<?= e($viewerDownloadUrl); ?>"
    class="btn btn-asu"
>

<i class="bi bi-download me-1"></i>

Download Document

</a>


</div>


</div>


<?php endif; ?>


</section>


<footer class="content-footer">


<span>

© <?= date('Y'); ?>
Aklan State University

</span>


<span class="footer-divider">

•

</span>


<span>

Research & Extension Management System

</span>


</footer>


<?php else: ?>


<!-- =====================================================
     HEADING
====================================================== -->

<div class="extension-view-heading">


<div>


<h1>

Extension Program Details

</h1>


<p>

View the complete extension program,
supporting documents and workflow status.

</p>


</div>


<div class="extension-heading-actions">


<a
    href="<?= BASE_URL; ?>/extension/index.php"
    class="btn btn-outline-asu"
>

<i class="bi bi-arrow-left me-1"></i>

Back to Extension

</a>


</div>


</div>



<!-- =====================================================
     FLASH
====================================================== -->

<?php if ($flash): ?>


<div
    class="
        alert
        alert-<?= e(
            $flash['type']
        ); ?>
        alert-dismissible
        fade
        show
    "
>


<?= e(
    $flash['message']
); ?>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="alert"
></button>


</div>


<?php endif; ?>



<!-- =====================================================
     ERRORS
====================================================== -->

<?php if ($errors): ?>


<div class="extension-errors">


<strong>

Unable to complete the requested action.

</strong>


<ul class="mb-0 mt-2">


<?php foreach (
    $errors
    as
    $error
): ?>


<li>

<?= e(
    $error
); ?>

</li>


<?php endforeach; ?>


</ul>


</div>


<?php endif; ?>



<!-- =====================================================
     SUMMARY
====================================================== -->

<section class="extension-summary">


<div class="extension-summary-top">


<div>


<h2>

<?= e(
    $program[
        'program_title'
    ]
); ?>

</h2>


<div class="extension-summary-meta">


<span>

<i class="bi bi-person-badge me-1"></i>

<?= e(
    $coordinatorName
); ?>

</span>


<?php if (
    !empty(
        $program[
            'college_name'
        ]
    )
): ?>


<span>

<i class="bi bi-building me-1"></i>

<?= e(
    $program[
        'college_name'
    ]
); ?>

</span>


<?php endif; ?>


<span>

<i class="bi bi-calendar3 me-1"></i>

Created

<?= e(
    date(
        'M d, Y',
        strtotime(
            $program[
                'created_at'
            ]
        )
    )
); ?>

</span>


<?php if (
    !empty(
        $program[
            'submitted_at'
        ]
    )
): ?>


<span>

<i class="bi bi-send-check me-1"></i>

Submitted

<?= e(
    date(
        'M d, Y',
        strtotime(
            $program[
                'submitted_at'
            ]
        )
    )
); ?>

</span>


<?php endif; ?>


</div>


</div>


<span
    class="
        extension-status
        <?= e(
            $statusClass
        ); ?>
    "
>

<?= e(
    $program[
        'status'
    ]
); ?>

</span>


</div>


</section>



<!-- =====================================================
     CURRENT STATUS
====================================================== -->

<section class="extension-status-overview">


<div class="extension-status-overview-icon">

<i
    class="
        bi
        <?= e(
            $statusIcon
        ); ?>
    "
></i>

</div>


<div class="extension-status-overview-content">


<span class="extension-status-label">

Current Program Status

</span>


<h3>

<?= e(
    $program[
        'status'
    ]
); ?>

</h3>


<p>


<?php switch (
    $program['status']
):


case 'Draft':
?>

The extension program is still being prepared.
The assigned Extension Coordinator may review
the details and submit the program when the
required supporting document is available.

<?php
break;


case 'Submitted':
?>

The extension program has been formally submitted
and is waiting for administrative review.

<?php
break;


case 'Under Review':
?>

The extension program is currently under
administrative evaluation.

<?php
break;


case 'For Revision':
?>

The program has been returned for revision.
The Extension Coordinator will need to address
the review remarks before resubmission.

<?php
break;


case 'Approved':
?>

The extension program has been approved.
Implementation and program monitoring may
proceed in the succeeding workflow.

<?php
break;


case 'Ongoing':
?>

The extension program is currently being
implemented and monitored.

<?php
break;


case 'Completed':
?>

The extension program has completed the
required implementation and completion process.

<?php
break;


case 'Rejected':
?>

The extension program was not approved.
Review information will be available in the
administrative evaluation workflow.

<?php
break;


case 'Archived':
?>

This extension program has been archived
as part of the institutional extension records.

<?php
break;


default:
?>

Current extension workflow information
is shown on this page.

<?php endswitch; ?>


</p>


</div>


</section>



<!-- =====================================================
     MAIN GRID
====================================================== -->

<div class="extension-grid">


<!-- =====================================================
     LEFT
====================================================== -->

<div class="extension-column">


<!-- PROGRAM INFORMATION -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-megaphone"></i>

</span>

Program Information

</h2>


</div>


<div class="extension-panel-body">


<div class="info-grid">


<div class="info-item">

<label>
Program Category
</label>

<strong>

<?= e(
    $program[
        'program_category'
    ]
    ?: 'Not specified'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Program Type
</label>

<strong>

<?= e(
    $program[
        'program_type'
    ]
    ?: 'Not specified'
); ?>

</strong>

</div>


<div class="info-item">

<label>
College
</label>

<strong>

<?= e(
    $program[
        'college_name'
    ]
    ?: 'Not assigned'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Department
</label>

<strong>

<?= e(
    $program[
        'department_name'
    ]
    ?: 'Not assigned'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Target Community / Barangay
</label>

<strong>

<?= e(
    $program[
        'target_community'
    ]
); ?>

</strong>

</div>


<div class="info-item">

<label>
Municipality
</label>

<strong>

<?= e(
    $program[
        'municipality'
    ]
    ?: 'Not specified'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Province
</label>

<strong>

<?= e(
    $program[
        'province'
    ]
    ?: 'Not specified'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Target Participants
</label>

<strong>

<?php if (
    $program[
        'target_participants'
    ]
    !== null
): ?>

<?= number_format(
    (int)$program[
        'target_participants'
    ]
); ?>

<?php else: ?>

Not specified

<?php endif; ?>

</strong>

</div>


</div>


</div>


</section>



<!-- PROGRAM CONTENT -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-file-text"></i>

</span>

Program Content

</h2>


</div>


<div class="extension-panel-body">


<div class="content-block">

<h4>
Objectives
</h4>

<p><?= e(
    $program[
        'objectives'
    ]
); ?></p>

</div>


<div class="content-block">

<h4>
Program Description
</h4>

<p><?= e(
    $program[
        'program_description'
    ]
); ?></p>

</div>


<div class="content-block">

<h4>
Expected Output
</h4>

<p><?= e(
    $program[
        'expected_output'
    ]
); ?></p>

</div>


</div>


</section>



<!-- FUNDING / SCHEDULE -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-calendar3"></i>

</span>

Funding & Schedule

</h2>


</div>


<div class="extension-panel-body">


<div class="info-grid">


<div class="info-item">

<label>
Funding Source
</label>

<strong>

<?= e(
    $program[
        'funding_source'
    ]
    ?: 'Not specified'
); ?>

</strong>

</div>


<div class="info-item">

<label>
Estimated Budget
</label>

<strong>

<?php if (
    $program[
        'estimated_budget'
    ]
    !== null
): ?>

₱<?= number_format(
    (float)$program[
        'estimated_budget'
    ],
    2
); ?>

<?php else: ?>

Not specified

<?php endif; ?>

</strong>

</div>


<div class="info-item">

<label>
Start Date
</label>

<strong>

<?php if (
    !empty(
        $program[
            'start_date'
        ]
    )
): ?>

<?= e(
    date(
        'F d, Y',
        strtotime(
            $program[
                'start_date'
            ]
        )
    )
); ?>

<?php else: ?>

Not specified

<?php endif; ?>

</strong>

</div>


<div class="info-item">

<label>
End Date
</label>

<strong>

<?php if (
    !empty(
        $program[
            'end_date'
        ]
    )
): ?>

<?= e(
    date(
        'F d, Y',
        strtotime(
            $program[
                'end_date'
            ]
        )
    )
); ?>

<?php else: ?>

Not specified

<?php endif; ?>

</strong>

</div>


</div>


</div>


</section>


</div>



<!-- =====================================================
     RIGHT
====================================================== -->

<div class="extension-column">


<!-- COORDINATOR -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-person-badge"></i>

</span>

Program Coordinator

</h2>


</div>


<div class="extension-panel-body">


<strong
    style="
        display:block;
        margin-bottom:4px;
        font-size:11px;
    "
>

<?= e(
    $coordinatorName
); ?>

</strong>


<span
    style="
        display:block;
        color:#818982;
        font-size:9px;
    "
>

<?= e(
    $program[
        'email'
    ]
); ?>

</span>


<span
    style="
        display:block;
        margin-top:3px;
        color:#818982;
        font-size:9px;
    "
>

Extension Coordinator

</span>


</div>


</section>



<!-- DOCUMENTS -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-paperclip"></i>

</span>

Documents

</h2>


<small class="text-muted">

<?= count(
    $documents
); ?>

</small>


</div>


<div class="extension-panel-body">


<?php if (
    empty(
        $documents
    )
): ?>


<div class="empty-data">

No supporting documents uploaded yet.

</div>


<?php else: ?>


<div class="document-list">


<?php foreach (
    $documents
    as
    $document
): ?>


<?php

$documentExtension =
    strtolower(
        (string)$document[
            'file_extension'
        ]
    );


$documentUrl =
    BASE_URL .
    '/extension/view.php?id=' .
    $extensionId .
    '&document_id=' .
    (int)$document[
        'document_id'
    ] .
    '&file_mode=view';

?>


<a
    href="<?= e($documentUrl); ?>"
    class="document-item document-item-link"
    target="_blank"
    rel="noopener noreferrer"
    title="Open <?= e(
        $document[
            'original_name'
        ]
    ); ?>"
>


<div class="document-icon">


<?php if (
    $documentExtension === 'pdf'
): ?>

<i class="bi bi-file-earmark-pdf"></i>

<?php else: ?>

<i class="bi bi-file-earmark-word"></i>

<?php endif; ?>


</div>


<div class="document-info">


<strong>

<?= e(
    $document[
        'original_name'
    ]
); ?>

</strong>


<small>

<?= e(
    $document[
        'document_type'
    ]
); ?>

·

<?= e(
    extensionFileSize(
        $document[
            'file_size'
        ]
        !== null
            ? (int)$document[
                'file_size'
            ]
            : null
    )
); ?>

<br>

Uploaded

<?= e(
    date(
        'M d, Y',
        strtotime(
            $document[
                'uploaded_at'
            ]
        )
    )
); ?>

</small>


</div>


<div
    class="document-open-icon"
    aria-hidden="true"
>

<i class="bi bi-box-arrow-up-right"></i>

</div>


</a>


<?php endforeach; ?>


</div>


<?php endif; ?>


</div>


</section>



<!-- STATUS HISTORY -->

<section class="extension-panel">


<div class="extension-panel-header">


<h2 class="extension-panel-title">


<span class="extension-panel-icon">

<i class="bi bi-clock-history"></i>

</span>

Status History

</h2>


</div>


<div class="extension-panel-body">


<?php if (
    empty(
        $statusHistory
    )
): ?>


<div class="empty-data">

No status history available.

</div>


<?php else: ?>


<?php foreach (
    $statusHistory
    as
    $history
): ?>


<?php

$changedBy =
    trim(
        $history[
            'first_name'
        ]
        .
        ' '
        .
        (
            !empty(
                $history[
                    'middle_name'
                ]
            )
                ? $history[
                    'middle_name'
                ]
                . ' '
                : ''
        )
        .
        $history[
            'last_name'
        ]
    );

?>


<div class="timeline-item">


<strong>

<?= e(
    $history[
        'new_status'
    ]
); ?>

</strong>


<small>

<?= e(
    $changedBy
); ?>

·

<?= e(
    date(
        'M d, Y h:i A',
        strtotime(
            $history[
                'changed_at'
            ]
        )
    )
); ?>

</small>


<?php if (
    !empty(
        $history[
            'remarks'
        ]
    )
): ?>


<p>

<?= e(
    $history[
        'remarks'
    ]
); ?>

</p>


<?php endif; ?>


</div>


<?php endforeach; ?>


<?php endif; ?>


</div>


</section>


</div>


</div>



<!-- =====================================================
     COORDINATOR DRAFT ACTIONS
====================================================== -->

<?php if (
    $user['role']
    === 'extension_coordinator'
    &&
    $program['status']
    === 'Draft'
): ?>


<section class="workflow-card">


<div class="workflow-content">


<div class="workflow-text">


<h4>

Draft Extension Program

</h4>


<p>

Review the program information and supporting
document before submitting the extension program
for administrative review.

</p>


<?php if (
    !$hasProgramProposalDocument
): ?>


<div class="workflow-notice">

A Program Proposal document is required before
submission. Return to the program form when the
document upload/edit function is available.

</div>


<?php endif; ?>


</div>


<div class="workflow-buttons">


<?php if (
    $editPageExists
): ?>


<a
    href="<?= BASE_URL; ?>/extension/edit.php?id=<?= $extensionId; ?>"
    class="btn btn-outline-asu"
>

<i class="bi bi-pencil-square me-1"></i>

Edit Program

</a>


<?php endif; ?>


<button
    type="button"
    class="btn btn-asu"
    data-bs-toggle="modal"
    data-bs-target="#submitProgramModal"
    <?= !$hasProgramProposalDocument
        ? 'disabled'
        : ''; ?>
>

<i class="bi bi-send me-1"></i>

Submit for Review

</button>


</div>


</div>


</section>


<?php endif; ?>



<!-- =====================================================
     SUBMITTED NOTICE
====================================================== -->

<?php if (
    $user['role']
    === 'extension_coordinator'
    &&
    in_array(
        $program['status'],
        [
            'Submitted',
            'Under Review'
        ],
        true
    )
): ?>


<div class="design-notice">

<strong>
Program Under Review:
</strong>

This extension program is currently within
the administrative review workflow.

</div>


<?php endif; ?>



<!-- =====================================================
     ADMIN SUBMITTED NOTICE
====================================================== -->

<?php if (
    $user['role']
    === 'admin'
    &&
    $program['status']
    === 'Submitted'
): ?>


<div class="design-notice">

<strong>
Ready for Administrative Review:
</strong>

This extension program has been formally submitted.
The administrative evaluation actions will be
connected in the next Extension workflow step.

</div>


<?php endif; ?>



<footer class="content-footer">


<span>

© <?= date('Y'); ?>
Aklan State University

</span>


<span class="footer-divider">

•

</span>


<span>

Research & Extension Management System

</span>


</footer>


<?php endif; ?>


</div>


</main>


</div>



<!-- =========================================================
     SUBMIT PROGRAM MODAL
========================================================= -->

<?php if (
    $user['role']
    === 'extension_coordinator'
    &&
    $program['status']
    === 'Draft'
    &&
    $hasProgramProposalDocument
): ?>


<div
    class="modal fade"
    id="submitProgramModal"
    tabindex="-1"
>


<div
    class="
        modal-dialog
        modal-dialog-centered
    "
>


<div class="modal-content">


<div class="modal-header">


<h5 class="modal-title">

Submit Extension Program

</h5>


<button
    type="button"
    class="btn-close"
    data-bs-dismiss="modal"
></button>


</div>


<form method="POST">


<div class="modal-body">


<input
    type="hidden"
    name="csrf_token"
    value="<?= e(
        generateCsrfToken()
    ); ?>"
>


<input
    type="hidden"
    name="action"
    value="submit_for_review"
>


<p>

Submit this extension program
for administrative review?

</p>


<div class="alert alert-warning mb-0">

After submission, the program will no longer
be treated as a private Draft and will become
available to the Administrator for review.

</div>


</div>


<div class="modal-footer">


<button
    type="button"
    class="btn btn-outline-secondary"
    data-bs-dismiss="modal"
>

Cancel

</button>


<button
    type="submit"
    class="btn btn-asu"
>

<i class="bi bi-send me-1"></i>

Confirm Submission

</button>


</div>


</form>


</div>


</div>


</div>


<?php endif; ?>


<?php

require __DIR__ .
    '/../includes/footer.php';

?>
