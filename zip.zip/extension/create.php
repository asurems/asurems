<?php

require_once __DIR__ . '/../includes/auth.php';

requireLogin();


/*
|--------------------------------------------------------------------------
| EXTENSION COORDINATOR ONLY
|--------------------------------------------------------------------------
*/

if (
    ($_SESSION['role'] ?? '') !== 'extension_coordinator'
) {

    redirect(
        BASE_URL . '/extension/index.php'
    );
}


$user = currentUser();

$pageTitle = 'Create Extension Program';
$activePage = 'extension';

$errors = [];


/*
|--------------------------------------------------------------------------
| FILE SETTINGS
|--------------------------------------------------------------------------
*/

$maxFileSize =
    10 * 1024 * 1024;

$allowedExtensions = [
    'pdf',
    'doc',
    'docx'
];

$allowedMimeTypes = [

    'pdf' => [
        'application/pdf'
    ],

    'doc' => [
        'application/msword',
        'application/vnd.ms-office',
        'application/x-ole-storage',
        'application/CDFV2',
        'application/octet-stream'
    ],

    'docx' => [
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip',
        'application/octet-stream'
    ]
];

$uploadDirectory =
    __DIR__ .
    '/../uploads/extension/programs';


/*
|--------------------------------------------------------------------------
| LOAD COORDINATOR INSTITUTIONAL ASSIGNMENT
|--------------------------------------------------------------------------
*/

$userStmt =
    $pdo->prepare("
        SELECT
            u.user_id,
            u.college_id,
            u.department_id,

            c.college_name,
            d.department_name

        FROM users u

        LEFT JOIN colleges c
            ON c.college_id = u.college_id

        LEFT JOIN departments d
            ON d.department_id = u.department_id

        WHERE u.user_id = ?

        LIMIT 1
    ");

$userStmt->execute([
    (int)$user['user_id']
]);

$institutionalData =
    $userStmt->fetch(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| DEFAULT FORM VALUES
|--------------------------------------------------------------------------
*/

$programTitle = '';
$programCategory = '';
$programType = '';

$targetCommunity = '';
$municipality = '';
$province = 'Aklan';

$objectives = '';
$programDescription = '';
$expectedOutput = '';

$fundingSource = '';
$estimatedBudget = '';
$targetParticipants = '';

$startDate = '';
$endDate = '';


/*
|--------------------------------------------------------------------------
| HANDLE FORM SUBMISSION
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
) {

    if (
        !verifyCsrfToken(
            $_POST['csrf_token'] ?? ''
        )
    ) {

        $errors[] =
            'Invalid request. Please refresh the page and try again.';
    }


    $programTitle =
        trim(
            $_POST['program_title'] ?? ''
        );

    $programCategory =
        trim(
            $_POST['program_category'] ?? ''
        );

    $programType =
        trim(
            $_POST['program_type'] ?? ''
        );

    $targetCommunity =
        trim(
            $_POST['target_community'] ?? ''
        );

    $municipality =
        trim(
            $_POST['municipality'] ?? ''
        );

    $province =
        trim(
            $_POST['province'] ?? ''
        );

    $objectives =
        trim(
            $_POST['objectives'] ?? ''
        );

    $programDescription =
        trim(
            $_POST['program_description'] ?? ''
        );

    $expectedOutput =
        trim(
            $_POST['expected_output'] ?? ''
        );

    $fundingSource =
        trim(
            $_POST['funding_source'] ?? ''
        );

    $estimatedBudget =
        trim(
            $_POST['estimated_budget'] ?? ''
        );

    $targetParticipants =
        trim(
            $_POST['target_participants'] ?? ''
        );

    $startDate =
        trim(
            $_POST['start_date'] ?? ''
        );

    $endDate =
        trim(
            $_POST['end_date'] ?? ''
        );


    /*
    |--------------------------------------------------------------------------
    | BASIC VALIDATION
    |--------------------------------------------------------------------------
    */

    if ($programTitle === '') {
        $errors[] =
            'Program title is required.';
    }

    if (
        mb_strlen(
            $programTitle
        ) > 255
    ) {
        $errors[] =
            'Program title must not exceed 255 characters.';
    }

    if ($programCategory === '') {
        $errors[] =
            'Program category is required.';
    }

    if ($programType === '') {
        $errors[] =
            'Program type is required.';
    }

    if ($targetCommunity === '') {
        $errors[] =
            'Target community or barangay is required.';
    }

    if ($objectives === '') {
        $errors[] =
            'Program objectives are required.';
    }

    if ($programDescription === '') {
        $errors[] =
            'Program description is required.';
    }

    if ($expectedOutput === '') {
        $errors[] =
            'Expected output is required.';
    }


    /*
    |--------------------------------------------------------------------------
    | BUDGET
    |--------------------------------------------------------------------------
    */

    $budgetValue = null;

    if ($estimatedBudget !== '') {

        if (
            !is_numeric(
                $estimatedBudget
            )
        ) {

            $errors[] =
                'Estimated budget must be a valid number.';

        } elseif (
            (float)$estimatedBudget < 0
        ) {

            $errors[] =
                'Estimated budget cannot be negative.';

        } else {

            $budgetValue =
                round(
                    (float)$estimatedBudget,
                    2
                );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | TARGET PARTICIPANTS
    |--------------------------------------------------------------------------
    */

    $participantValue = null;

    if ($targetParticipants !== '') {

        if (
            filter_var(
                $targetParticipants,
                FILTER_VALIDATE_INT
            ) === false
            ||
            (int)$targetParticipants < 0
        ) {

            $errors[] =
                'Target participants must be a valid non-negative whole number.';

        } else {

            $participantValue =
                (int)$targetParticipants;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | DATE VALIDATION
    |--------------------------------------------------------------------------
    */

    if (
        $startDate !== ''
        &&
        $endDate !== ''
    ) {

        $startTimestamp =
            strtotime(
                $startDate
            );

        $endTimestamp =
            strtotime(
                $endDate
            );

        if (
            $startTimestamp === false
            ||
            $endTimestamp === false
        ) {

            $errors[] =
                'Please enter valid program dates.';

        } elseif (
            $endTimestamp <
            $startTimestamp
        ) {

            $errors[] =
                'Program end date cannot be earlier than the start date.';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | OPTIONAL SUPPORTING DOCUMENT
    |--------------------------------------------------------------------------
    */

    $uploadedFile = null;
    $originalFileName = null;
    $fileExtension = null;
    $fileMimeType = null;
    $fileSize = null;

    if (
        isset(
            $_FILES['program_file']
        )
        &&
        (
            $_FILES['program_file']['error']
            ?? UPLOAD_ERR_NO_FILE
        ) !== UPLOAD_ERR_NO_FILE
    ) {

        $uploadedFile =
            $_FILES['program_file'];

        if (
            $uploadedFile['error']
            !== UPLOAD_ERR_OK
        ) {

            switch (
                $uploadedFile['error']
            ) {

                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:

                    $errors[] =
                        'The uploaded document exceeds the allowed file size.';

                    break;

                case UPLOAD_ERR_PARTIAL:

                    $errors[] =
                        'The document was only partially uploaded.';

                    break;

                default:

                    $errors[] =
                        'Unable to upload the supporting document.';

                    break;
            }

        } else {

            $fileSize =
                (int)$uploadedFile['size'];

            if ($fileSize <= 0) {
                $errors[] =
                    'The uploaded document is empty.';
            }

            if (
                $fileSize >
                $maxFileSize
            ) {
                $errors[] =
                    'Supporting document must not exceed 10 MB.';
            }

            $originalFileName =
                basename(
                    $uploadedFile['name']
                );

            $fileExtension =
                strtolower(
                    pathinfo(
                        $originalFileName,
                        PATHINFO_EXTENSION
                    )
                );

            if (
                !in_array(
                    $fileExtension,
                    $allowedExtensions,
                    true
                )
            ) {
                $errors[] =
                    'Only PDF, DOC, and DOCX documents are allowed.';
            }

            if (
                empty(
                    $uploadedFile['tmp_name']
                )
                ||
                !is_uploaded_file(
                    $uploadedFile['tmp_name']
                )
            ) {

                $errors[] =
                    'The uploaded supporting document is invalid.';
            }

            if (
                function_exists(
                    'finfo_open'
                )
                &&
                !$errors
            ) {

                $fileInfo =
                    finfo_open(
                        FILEINFO_MIME_TYPE
                    );

                if (
                    $fileInfo !== false
                ) {

                    $fileMimeType =
                        finfo_file(
                            $fileInfo,
                            $uploadedFile['tmp_name']
                        );

                    finfo_close(
                        $fileInfo
                    );
                }

                if (
                    $fileMimeType
                    &&
                    isset(
                        $allowedMimeTypes[
                            $fileExtension
                        ]
                    )
                    &&
                    !in_array(
                        $fileMimeType,
                        $allowedMimeTypes[
                            $fileExtension
                        ],
                        true
                    )
                ) {

                    $errors[] =
                        'The uploaded file does not match the selected document format.';
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE PROGRAM
    |--------------------------------------------------------------------------
    */

    if (!$errors) {

        $storedFileName = null;
        $physicalFilePath = null;
        $databaseFilePath = null;
        $fileMoved = false;

        try {

            $pdo->beginTransaction();


            $stmt =
                $pdo->prepare("
                    INSERT INTO extension_programs
                    (
                        coordinator_id,
                        college_id,
                        department_id,

                        program_title,
                        program_category,
                        program_type,

                        target_community,
                        municipality,
                        province,

                        objectives,
                        program_description,
                        expected_output,

                        funding_source,
                        estimated_budget,
                        target_participants,

                        start_date,
                        end_date,

                        status,
                        progress_percentage
                    )
                    VALUES
                    (
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?, ?,
                        ?, ?,
                        'Draft',
                        0
                    )
                ");


            $stmt->execute([

                (int)$user['user_id'],

                !empty(
                    $institutionalData['college_id']
                )
                    ? (int)$institutionalData['college_id']
                    : null,

                !empty(
                    $institutionalData['department_id']
                )
                    ? (int)$institutionalData['department_id']
                    : null,

                $programTitle,
                $programCategory,
                $programType,

                $targetCommunity,

                $municipality !== ''
                    ? $municipality
                    : null,

                $province !== ''
                    ? $province
                    : null,

                $objectives,
                $programDescription,
                $expectedOutput,

                $fundingSource !== ''
                    ? $fundingSource
                    : null,

                $budgetValue,
                $participantValue,

                $startDate !== ''
                    ? $startDate
                    : null,

                $endDate !== ''
                    ? $endDate
                    : null

            ]);


            $extensionId =
                (int)$pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | SAVE DOCUMENT
            |--------------------------------------------------------------------------
            */

            if (
                $uploadedFile !== null
                &&
                $uploadedFile['error']
                === UPLOAD_ERR_OK
            ) {

                if (
                    !is_dir(
                        $uploadDirectory
                    )
                ) {

                    if (
                        !mkdir(
                            $uploadDirectory,
                            0755,
                            true
                        )
                        &&
                        !is_dir(
                            $uploadDirectory
                        )
                    ) {

                        throw new RuntimeException(
                            'Unable to create extension upload directory.'
                        );
                    }
                }


                $storedFileName =
                    'extension_' .
                    $extensionId .
                    '_' .
                    date('YmdHis') .
                    '_' .
                    bin2hex(
                        random_bytes(8)
                    ) .
                    '.' .
                    $fileExtension;


                $physicalFilePath =
                    $uploadDirectory .
                    DIRECTORY_SEPARATOR .
                    $storedFileName;


                $databaseFilePath =
                    'uploads/extension/programs/' .
                    $storedFileName;


                if (
                    !move_uploaded_file(
                        $uploadedFile['tmp_name'],
                        $physicalFilePath
                    )
                ) {

                    throw new RuntimeException(
                        'Unable to save the extension supporting document.'
                    );
                }


                $fileMoved = true;


                $documentStmt =
                    $pdo->prepare("
                        INSERT INTO extension_documents
                        (
                            extension_id,
                            uploaded_by,
                            document_type,

                            original_name,
                            stored_name,
                            file_path,

                            file_extension,
                            file_size
                        )
                        VALUES
                        (
                            ?, ?, 'Program Proposal',
                            ?, ?, ?,
                            ?, ?
                        )
                    ");


                $documentStmt->execute([

                    $extensionId,

                    (int)$user['user_id'],

                    $originalFileName,
                    $storedFileName,
                    $databaseFilePath,

                    $fileExtension,
                    $fileSize

                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | STATUS HISTORY
            |--------------------------------------------------------------------------
            */

            $historyStmt =
                $pdo->prepare("
                    INSERT INTO extension_status_history
                    (
                        extension_id,
                        changed_by,
                        old_status,
                        new_status,
                        remarks
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        NULL,
                        'Draft',
                        ?
                    )
                ");


            $historyRemarks =
                $uploadedFile !== null
                &&
                $uploadedFile['error']
                === UPLOAD_ERR_OK
                    ? 'Extension program draft created with supporting document.'
                    : 'Extension program draft created.';


            $historyStmt->execute([

                $extensionId,

                (int)$user['user_id'],

                $historyRemarks

            ]);


            $pdo->commit();


            setFlash(
                'success',
                'Extension program was saved successfully as a draft.'
            );


            redirect(
                BASE_URL .
                '/extension/index.php'
            );


        } catch (
            Throwable $e
        ) {

            if (
                $pdo->inTransaction()
            ) {
                $pdo->rollBack();
            }

            if (
                $fileMoved
                &&
                $physicalFilePath
                &&
                is_file(
                    $physicalFilePath
                )
            ) {
                @unlink(
                    $physicalFilePath
                );
            }

            $errors[] =
                'Unable to save the extension program. Please try again.';
        }
    }
}


/*
|--------------------------------------------------------------------------
| INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';

if (
    !empty(
        $user['first_name']
    )
) {
    $initials .=
        strtoupper(
            substr(
                $user['first_name'],
                0,
                1
            )
        );
}

if (
    !empty(
        $user['last_name']
    )
) {
    $initials .=
        strtoupper(
            substr(
                $user['last_name'],
                0,
                1
            )
        );
}


require __DIR__ .
    '/../includes/header.php';

require __DIR__ .
    '/../includes/sidebar.php';

?>


<style>

.extension-form-wrapper {
    max-width: 1150px;
    margin: 0 auto;
}

.extension-form-heading {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 22px;
}

.extension-form-heading h1 {
    margin: 0 0 5px;
    font-size: 25px;
    font-weight: 700;
}

.extension-form-heading p {
    margin: 0;
    color: var(--asu-muted);
    font-size: 11px;
    line-height: 1.6;
}

.extension-form-card {
    overflow: hidden;
    background: #ffffff;
    border: 1px solid var(--asu-border);
    border-radius: 15px;
    box-shadow: 0 4px 16px rgba(30, 64, 34, .035);
}

.extension-form-header {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 20px 23px;
    border-bottom: 1px solid #edf1ec;
}

.extension-form-header-icon {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 9px;
    background: #edf7ef;
    color: var(--asu-green);
    font-size: 18px;
}

.extension-form-header h2 {
    margin: 0 0 2px;
    font-size: 15px;
    font-weight: 700;
}

.extension-form-header p {
    margin: 0;
    color: #818982;
    font-size: 10px;
}

.extension-form-body {
    padding: 24px;
}

.extension-form-section {
    margin-bottom: 30px;
}

.extension-form-section:last-child {
    margin-bottom: 0;
}

.extension-form-section-title {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 16px;
    padding-bottom: 10px;
    border-bottom: 1px solid #edf1ec;
    color: #333c35;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.extension-form-section-title i {
    color: var(--asu-green);
    font-size: 14px;
}

.extension-form-card .form-label {
    margin-bottom: 6px;
    color: #404841;
    font-size: 11px;
    font-weight: 600;
}

.extension-form-card .form-control,
.extension-form-card .form-select {
    min-height: 44px;
    border: 1px solid #d8dfd7;
    border-radius: 8px;
    background: #fbfcfb;
    font-size: 12px;
}

.extension-form-card textarea.form-control {
    min-height: 115px;
    resize: vertical;
    line-height: 1.6;
}

.assignment-box {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
    padding: 15px;
    border: 1px solid #e1e8e1;
    border-radius: 10px;
    background: #f8faf8;
}

.assignment-box small {
    display: block;
    margin-bottom: 3px;
    color: #878f89;
    font-size: 9px;
    text-transform: uppercase;
}

.assignment-box strong {
    display: block;
    color: #303830;
    font-size: 11px;
    font-weight: 600;
}

.upload-box {
    padding: 22px;
    border: 1px dashed #adc4b2;
    border-radius: 11px;
    background: #f8fbf8;
    text-align: center;
}

.upload-icon {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
    border-radius: 50%;
    background: #e7f4e9;
    color: var(--asu-green);
    font-size: 20px;
}

.upload-box h5 {
    margin: 0 0 5px;
    color: #333c35;
    font-size: 12px;
    font-weight: 700;
}

.upload-box p {
    margin: 0 0 14px;
    color: #838c85;
    font-size: 9px;
    line-height: 1.55;
}

.upload-box .form-control {
    max-width: 520px;
    margin: 0 auto;
    background: #ffffff;
}

.form-errors {
    margin-bottom: 18px;
    padding: 14px 17px;
    border: 1px solid #edcccc;
    border-radius: 10px;
    background: #fff6f6;
    color: #873b3b;
    font-size: 11px;
}

.form-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 9px;
    margin-top: 28px;
    padding-top: 20px;
    border-top: 1px solid #edf1ec;
}

@media (max-width: 768px) {

    .extension-form-heading {
        flex-direction: column;
    }

    .assignment-box {
        grid-template-columns: 1fr;
    }

    .extension-form-body {
        padding: 19px;
    }

    .form-actions {
        flex-direction: column-reverse;
    }

    .form-actions .btn {
        width: 100%;
    }
}

</style>


<div class="main-page">


<header class="asu-topbar">


<div class="topbar-left">

<button
    id="sidebarToggle"
    class="sidebar-toggle"
    type="button"
>
    <i class="bi bi-list"></i>
</button>

<span class="system-name">
Research & Extension Management System
</span>

</div>


<div class="topbar-user">

<div class="topbar-user-text">

<strong>
<?= e(fullName($user)); ?>
</strong>

<span>
<?= e(roleLabel($user['role'])); ?>
</span>

</div>

<div class="user-avatar">
<?= e($initials); ?>
</div>

</div>


</header>


<main class="page-content">


<div class="extension-form-wrapper">


<div class="extension-form-heading">

<div>

<h1>
Create Extension Program
</h1>

<p>
Create a new extension program record.
The program will initially be saved as Draft.
</p>

</div>


<a
    href="<?= BASE_URL; ?>/extension/index.php"
    class="btn btn-outline-asu"
>
    <i class="bi bi-arrow-left me-1"></i>
    Back to Extension
</a>

</div>


<?php if ($errors): ?>

<div class="form-errors">

<strong>
Please review the following:
</strong>

<ul class="mb-0 mt-2">

<?php foreach (
    $errors
    as
    $error
): ?>

<li>
<?= e($error); ?>
</li>

<?php endforeach; ?>

</ul>

</div>

<?php endif; ?>


<section class="extension-form-card">


<div class="extension-form-header">

<div class="extension-form-header-icon">
<i class="bi bi-megaphone"></i>
</div>

<div>

<h2>
Extension Program Information
</h2>

<p>
Enter the official program details and target community information.
</p>

</div>

</div>


<div class="extension-form-body">


<form
    method="POST"
    enctype="multipart/form-data"
    autocomplete="off"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= e(generateCsrfToken()); ?>"
>


<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-person-badge"></i>
Program Coordinator
</div>


<div class="row g-3">


<div class="col-md-6">

<label class="form-label">
Coordinator
</label>

<input
    type="text"
    class="form-control"
    value="<?= e(fullName($user)); ?>"
    disabled
>

</div>


<div class="col-md-6">

<label class="form-label">
Institutional Assignment
</label>

<div class="assignment-box">

<div>

<small>
College
</small>

<strong>
<?= e(
    $institutionalData['college_name']
    ?: 'Not Assigned'
); ?>
</strong>

</div>

<div>

<small>
Department
</small>

<strong>
<?= e(
    $institutionalData['department_name']
    ?: 'Not Assigned'
); ?>
</strong>

</div>

</div>

</div>


</div>


</div>



<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-journal-text"></i>
Basic Program Information
</div>


<div class="row g-3">


<div class="col-12">

<label class="form-label">
Program Title *
</label>

<input
    type="text"
    name="program_title"
    class="form-control"
    maxlength="255"
    value="<?= e($programTitle); ?>"
    required
>

</div>


<div class="col-md-6">

<label class="form-label">
Program Category *
</label>

<input
    type="text"
    name="program_category"
    class="form-control"
    maxlength="150"
    value="<?= e($programCategory); ?>"
    required
>

</div>


<div class="col-md-6">

<label class="form-label">
Program Type *
</label>

<select
    name="program_type"
    class="form-select"
    required
>

<option value="">
Select Program Type
</option>

<?php

$programTypes = [
    'Training / Seminar',
    'Community Outreach',
    'Technical Assistance',
    'Livelihood Program',
    'Technology Transfer',
    'Information Campaign',
    'Other'
];

?>

<?php foreach (
    $programTypes
    as
    $type
): ?>

<option
    value="<?= e($type); ?>"
    <?= $programType === $type
        ? 'selected'
        : ''; ?>
>
<?= e($type); ?>
</option>

<?php endforeach; ?>

</select>

</div>


</div>


</div>



<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-geo-alt"></i>
Target Community
</div>


<div class="row g-3">


<div class="col-md-6">

<label class="form-label">
Target Community / Barangay *
</label>

<input
    type="text"
    name="target_community"
    class="form-control"
    maxlength="255"
    value="<?= e($targetCommunity); ?>"
    required
>

</div>


<div class="col-md-3">

<label class="form-label">
Municipality
</label>

<input
    type="text"
    name="municipality"
    class="form-control"
    maxlength="150"
    value="<?= e($municipality); ?>"
>

</div>


<div class="col-md-3">

<label class="form-label">
Province
</label>

<input
    type="text"
    name="province"
    class="form-control"
    maxlength="150"
    value="<?= e($province); ?>"
>

</div>


</div>


</div>



<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-file-text"></i>
Program Content
</div>


<div class="row g-3">


<div class="col-12">

<label class="form-label">
Objectives *
</label>

<textarea
    name="objectives"
    class="form-control"
    required
><?= e($objectives); ?></textarea>

</div>


<div class="col-12">

<label class="form-label">
Program Description *
</label>

<textarea
    name="program_description"
    class="form-control"
    required
><?= e($programDescription); ?></textarea>

</div>


<div class="col-12">

<label class="form-label">
Expected Output *
</label>

<textarea
    name="expected_output"
    class="form-control"
    required
><?= e($expectedOutput); ?></textarea>

</div>


</div>


</div>



<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-calendar3"></i>
Funding, Participants & Schedule
</div>


<div class="row g-3">


<div class="col-md-4">

<label class="form-label">
Funding Source
</label>

<input
    type="text"
    name="funding_source"
    class="form-control"
    maxlength="150"
    value="<?= e($fundingSource); ?>"
>

</div>


<div class="col-md-4">

<label class="form-label">
Estimated Budget
</label>

<div class="input-group">

<span class="input-group-text">
₱
</span>

<input
    type="number"
    name="estimated_budget"
    class="form-control"
    min="0"
    step="0.01"
    value="<?= e($estimatedBudget); ?>"
>

</div>

</div>


<div class="col-md-4">

<label class="form-label">
Target Participants
</label>

<input
    type="number"
    name="target_participants"
    class="form-control"
    min="0"
    step="1"
    value="<?= e($targetParticipants); ?>"
>

</div>


<div class="col-md-6">

<label class="form-label">
Program Start Date
</label>

<input
    type="date"
    name="start_date"
    class="form-control"
    value="<?= e($startDate); ?>"
>

</div>


<div class="col-md-6">

<label class="form-label">
Program End Date
</label>

<input
    type="date"
    name="end_date"
    class="form-control"
    value="<?= e($endDate); ?>"
>

</div>


</div>


</div>



<div class="extension-form-section">


<div class="extension-form-section-title">
<i class="bi bi-cloud-arrow-up"></i>
Supporting Document
</div>


<div class="upload-box">

<div class="upload-icon">
<i class="bi bi-file-earmark-arrow-up"></i>
</div>

<h5>
Upload Extension Program Document
</h5>

<p>
Optional while the program is still a Draft.
Accepted formats: PDF, DOC, DOCX.
Maximum file size: 10 MB.
</p>

<input
    type="file"
    name="program_file"
    class="form-control"
    accept=".pdf,.doc,.docx"
>

</div>


</div>



<div class="form-actions">


<a
    href="<?= BASE_URL; ?>/extension/index.php"
    class="btn btn-outline-asu"
>
Cancel
</a>


<button
    type="submit"
    class="btn btn-asu"
>
<i class="bi bi-save me-1"></i>
Save as Draft
</button>


</div>


</form>


</div>


</section>


<footer class="content-footer">

<span>
© <?= date('Y'); ?>
Aklan State University
</span>

<span class="footer-divider">
•
</span>

<span>
Research & Extension Management System
</span>

</footer>


</div>


</main>


</div>


<?php

require __DIR__ .
    '/../includes/footer.php';

?>
