<?php

require_once __DIR__ . '/../includes/auth.php';

requireLogin();


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    !in_array(
        $_SESSION['role'] ?? '',
        [
            'admin',
            'extension_coordinator'
        ],
        true
    )
) {

    redirect(
        BASE_URL . '/dashboard.php'
    );
}


/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/

$user = currentUser();

$pageTitle = 'Extension Management';
$activePage = 'extension';


/*
|--------------------------------------------------------------------------
| FILTER VALUES
|--------------------------------------------------------------------------
*/

$search =
    trim(
        $_GET['search'] ?? ''
    );

$status =
    trim(
        $_GET['status'] ?? ''
    );

$year =
    trim(
        $_GET['year'] ?? ''
    );


$validStatuses = [
    'Draft',
    'Submitted',
    'Under Review',
    'For Revision',
    'Approved',
    'Ongoing',
    'Completed',
    'Rejected',
    'Archived'
];


/*
|--------------------------------------------------------------------------
| ACCESS CONDITION
|--------------------------------------------------------------------------
|
| Extension Coordinator:
| - Can see only programs they created.
|
| Administrator:
| - Can see institutional programs after submission.
| - Drafts remain private to the coordinator.
|
*/

if (
    $user['role'] === 'extension_coordinator'
) {

    $accessSql =
        "ep.coordinator_id = ?";

    $accessParams = [
        (int)$user['user_id']
    ];

} else {

    $accessSql =
        "ep.status <> 'Draft'";

    $accessParams = [];
}


/*
|--------------------------------------------------------------------------
| STATISTIC HELPER
|--------------------------------------------------------------------------
*/

function extensionCount(
    PDO $pdo,
    string $accessSql,
    array $accessParams,
    ?string $condition = null
): int {

    $sql = "
        SELECT COUNT(*)
        FROM extension_programs ep
        WHERE {$accessSql}
    ";

    $params = $accessParams;


    if ($condition !== null) {

        $sql .= "
            AND {$condition}
        ";
    }


    $stmt =
        $pdo->prepare($sql);

    $stmt->execute($params);

    return (int)$stmt->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| TOTAL PROGRAMS
|--------------------------------------------------------------------------
*/

$totalPrograms =
    extensionCount(
        $pdo,
        $accessSql,
        $accessParams
    );


/*
|--------------------------------------------------------------------------
| ACTIVE PROGRAMS
|--------------------------------------------------------------------------
*/

$activePrograms =
    extensionCount(
        $pdo,
        $accessSql,
        $accessParams,
        "ep.status = 'Ongoing'"
    );


/*
|--------------------------------------------------------------------------
| TOTAL TARGET PARTICIPANTS
|--------------------------------------------------------------------------
|
| For now this is based on the actual target_participants saved
| in extension_programs. Later, when participant attendance is
| implemented, this can be changed to actual participant counts.
|
*/

$participantSql = "
    SELECT
        COALESCE(
            SUM(ep.target_participants),
            0
        )
    FROM extension_programs ep
    WHERE {$accessSql}
";

$participantStmt =
    $pdo->prepare(
        $participantSql
    );

$participantStmt->execute(
    $accessParams
);

$totalParticipants =
    (int)$participantStmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| BARANGAYS / COMMUNITIES REACHED
|--------------------------------------------------------------------------
|
| Counts distinct non-empty target community values from actual records.
|
*/

$barangaySql = "
    SELECT
        COUNT(
            DISTINCT NULLIF(
                TRIM(ep.target_community),
                ''
            )
        )
    FROM extension_programs ep
    WHERE {$accessSql}
";

$barangayStmt =
    $pdo->prepare(
        $barangaySql
    );

$barangayStmt->execute(
    $accessParams
);

$barangaysReached =
    (int)$barangayStmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| BUILD PROGRAM QUERY
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT

        ep.extension_id,
        ep.coordinator_id,

        ep.program_title,
        ep.program_category,
        ep.program_type,

        ep.target_community,
        ep.municipality,
        ep.province,

        ep.target_participants,

        ep.start_date,
        ep.end_date,

        ep.status,
        ep.progress_percentage,

        ep.submitted_at,
        ep.created_at,
        ep.updated_at,

        u.first_name,
        u.middle_name,
        u.last_name,

        c.college_name,
        d.department_name

    FROM extension_programs ep

    INNER JOIN users u
        ON u.user_id = ep.coordinator_id

    LEFT JOIN colleges c
        ON c.college_id = ep.college_id

    LEFT JOIN departments d
        ON d.department_id = ep.department_id

    WHERE {$accessSql}
";

$params =
    $accessParams;


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $sql .= "
        AND (
            ep.program_title LIKE ?
            OR ep.program_category LIKE ?
            OR ep.program_type LIKE ?
            OR ep.target_community LIKE ?
            OR ep.municipality LIKE ?
            OR ep.province LIKE ?
            OR u.first_name LIKE ?
            OR u.middle_name LIKE ?
            OR u.last_name LIKE ?
        )
    ";

    $searchTerm =
        '%' . $search . '%';

    for ($i = 0; $i < 9; $i++) {
        $params[] = $searchTerm;
    }
}


/*
|--------------------------------------------------------------------------
| STATUS FILTER
|--------------------------------------------------------------------------
*/

if (
    $status !== ''
    &&
    in_array(
        $status,
        $validStatuses,
        true
    )
) {

    $sql .= "
        AND ep.status = ?
    ";

    $params[] = $status;
}


/*
|--------------------------------------------------------------------------
| YEAR FILTER
|--------------------------------------------------------------------------
*/

if (
    $year !== ''
    &&
    preg_match(
        '/^\d{4}$/',
        $year
    )
) {

    $sql .= "
        AND (
            YEAR(ep.start_date) = ?
            OR YEAR(ep.created_at) = ?
        )
    ";

    $params[] =
        (int)$year;

    $params[] =
        (int)$year;
}


/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/

$sql .= "
    ORDER BY
        ep.updated_at DESC,
        ep.created_at DESC
";


$stmt =
    $pdo->prepare($sql);

$stmt->execute($params);

$programs =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| FLASH MESSAGE
|--------------------------------------------------------------------------
*/

$flash =
    getFlash();


/*
|--------------------------------------------------------------------------
| USER INITIALS
|--------------------------------------------------------------------------
*/

$initials = '';

if (
    !empty(
        $user['first_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['first_name'],
                0,
                1
            )
        );
}


if (
    !empty(
        $user['last_name']
    )
) {

    $initials .=
        strtoupper(
            substr(
                $user['last_name'],
                0,
                1
            )
        );
}


/*
|--------------------------------------------------------------------------
| LOAD LAYOUT
|--------------------------------------------------------------------------
*/

require __DIR__ . '/../includes/header.php';

require __DIR__ . '/../includes/sidebar.php';

?>


<style>

/* =========================================================
   EXTENSION TABLE
========================================================= */

.extension-table-wrapper {
    overflow-x: auto;
}


.extension-table {
    width: 100%;
    margin: 0;
}


.extension-table thead th {
    padding: 14px 16px;
    border-bottom: 1px solid #e3e9e3;
    background: #f8faf8;
    color: #687269;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: .035em;
    text-transform: uppercase;
    white-space: nowrap;
}


.extension-table tbody td {
    padding: 16px;
    border-bottom: 1px solid #edf1ed;
    color: #343c36;
    font-size: 11px;
    vertical-align: middle;
}


.extension-table tbody tr:last-child td {
    border-bottom: none;
}


.extension-title-cell {
    min-width: 250px;
}


.extension-title-cell strong {
    display: block;
    margin-bottom: 4px;
    color: #222a24;
    font-size: 12px;
    font-weight: 700;
    line-height: 1.45;
}


.extension-title-cell small {
    display: block;
    color: #868f88;
    font-size: 9px;
    line-height: 1.5;
}


.extension-coordinator {
    min-width: 145px;
}


.extension-coordinator strong {
    display: block;
    margin-bottom: 3px;
    font-size: 11px;
    font-weight: 600;
}


.extension-coordinator small {
    color: #8a928c;
    font-size: 9px;
}


/* =========================================================
   STATUS BADGES
========================================================= */

.extension-status {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 27px;
    padding: 4px 10px;
    border-radius: 50px;
    font-size: 9px;
    font-weight: 700;
    white-space: nowrap;
}


.extension-status-draft {
    background: #eef1ef;
    color: #626b64;
}


.extension-status-submitted {
    background: #e7f0ff;
    color: #365f99;
}


.extension-status-review {
    background: #fff4c8;
    color: #78620b;
}


.extension-status-revision {
    background: #fff0e2;
    color: #9a551c;
}


.extension-status-approved {
    background: #e4f4e8;
    color: #23703e;
}


.extension-status-ongoing {
    background: #e6f5ea;
    color: #08752c;
}


.extension-status-completed {
    background: #ddf1e2;
    color: #12652e;
}


.extension-status-rejected {
    background: #fde8e8;
    color: #a13939;
}


.extension-status-archived {
    background: #ebecef;
    color: #60656e;
}


/* =========================================================
   EMPTY STATE
========================================================= */

.extension-empty-state {
    min-height: 300px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 40px 25px;
    text-align: center;
}


.extension-empty-icon {
    width: 68px;
    height: 68px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 15px;
    border-radius: 50%;
    background: #edf7ef;
    color: var(--asu-green);
    font-size: 27px;
}


.extension-empty-state h3 {
    margin: 0 0 7px;
    color: #283029;
    font-size: 15px;
    font-weight: 700;
}


.extension-empty-state p {
    max-width: 440px;
    margin: 0 0 17px;
    color: #7d867f;
    font-size: 10px;
    line-height: 1.65;
}


.extension-result-info {
    color: #828b84;
    font-size: 10px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 768px) {

    .extension-table {
        min-width: 980px;
    }
}

</style>


<div class="main-page">


    <!-- =====================================================
         TOP HEADER
    ====================================================== -->

    <header class="asu-topbar">


        <div class="topbar-left">


            <button
                id="sidebarToggle"
                class="sidebar-toggle"
                type="button"
                aria-label="Open navigation"
            >

                <i class="bi bi-list"></i>

            </button>


            <span class="system-name">

                Research & Extension Management System

            </span>


        </div>



        <div class="topbar-user">


            <div class="topbar-user-text">


                <strong>

                    <?= e(
                        fullName($user)
                    ); ?>

                </strong>


                <span>

                    <?= e(
                        roleLabel(
                            $user['role']
                        )
                    ); ?>

                </span>


            </div>



            <div class="dropdown">


                <button
                    type="button"
                    class="user-dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >

                    <div class="user-avatar">

                        <?= e(
                            $initials
                        ); ?>

                    </div>

                </button>


                <ul
                    class="
                        dropdown-menu
                        dropdown-menu-end
                    "
                >


                    <li>

                        <div class="dropdown-item-text">

                            <strong class="d-block">

                                <?= e(
                                    fullName($user)
                                ); ?>

                            </strong>


                            <small class="text-muted">

                                <?= e(
                                    $user['email']
                                ); ?>

                            </small>

                        </div>

                    </li>


                    <li>

                        <hr class="dropdown-divider">

                    </li>


                    <li>

                        <a
                            href="<?= BASE_URL; ?>/logout.php"
                            class="dropdown-item"
                        >

                            <i
                                class="
                                    bi
                                    bi-box-arrow-right
                                    me-2
                                "
                            ></i>

                            Logout

                        </a>

                    </li>


                </ul>


            </div>


        </div>


    </header>



    <!-- =====================================================
         PAGE CONTENT
    ====================================================== -->

    <main class="page-content">


        <!-- =================================================
             PAGE HEADING
        ================================================== -->

        <div class="page-heading">


            <div>


                <h1>

                    Extension Management

                </h1>


                <p>

                    <?php if (
                        $user['role'] ===
                        'extension_coordinator'
                    ): ?>

                        Manage your extension programs,
                        documents and implementation records.

                    <?php else: ?>

                        Review submitted extension programs
                        and monitor institutional extension
                        records.

                    <?php endif; ?>

                </p>


            </div>



            <?php if (
                $user['role'] ===
                'extension_coordinator'
            ): ?>


                <a
                    href="<?= BASE_URL; ?>/extension/create.php"
                    class="btn btn-asu"
                >

                    <i class="bi bi-plus-lg me-1"></i>

                    Add Program

                </a>


            <?php endif; ?>


        </div>



        <!-- =================================================
             FLASH MESSAGE
        ================================================== -->

        <?php if ($flash): ?>


            <div
                class="
                    alert
                    alert-<?= e(
                        $flash['type']
                    ); ?>
                    alert-dismissible
                    fade
                    show
                "
                role="alert"
            >

                <?= e(
                    $flash['message']
                ); ?>


                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"
                ></button>


            </div>


        <?php endif; ?>



        <!-- =================================================
             STATISTIC CARDS
        ================================================== -->

        <section class="stats-row">


            <div class="stat-card">


                <div class="stat-icon green">

                    <i class="bi bi-megaphone"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $totalPrograms
                        ); ?>

                    </strong>


                    <span>

                        <?=
                            $user['role'] ===
                            'extension_coordinator'
                                ? 'My Programs'
                                : 'Extension Programs';
                        ?>

                    </span>


                </div>


            </div>



            <div class="stat-card">


                <div class="stat-icon yellow">

                    <i class="bi bi-play-circle"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $activePrograms
                        ); ?>

                    </strong>


                    <span>

                        Active Programs

                    </span>


                </div>


            </div>



            <div class="stat-card">


                <div class="stat-icon green">

                    <i class="bi bi-people"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $totalParticipants
                        ); ?>

                    </strong>


                    <span>

                        Target Participants

                    </span>


                </div>


            </div>



            <div class="stat-card">


                <div class="stat-icon yellow">

                    <i class="bi bi-geo-alt"></i>

                </div>


                <div class="stat-content">


                    <strong>

                        <?= number_format(
                            $barangaysReached
                        ); ?>

                    </strong>


                    <span>

                        Target Communities

                    </span>


                </div>


            </div>


        </section>



        <!-- =================================================
             SEARCH AND FILTERS
        ================================================== -->

        <section class="filter-card">


            <form
                method="GET"
                action=""
            >


                <div class="row g-2">


                    <div class="col-lg-5">


                        <div class="input-group">


                            <span
                                class="
                                    input-group-text
                                    bg-white
                                "
                            >

                                <i class="bi bi-search"></i>

                            </span>


                            <input
                                type="search"
                                name="search"
                                class="form-control"
                                placeholder="Search program, community or coordinator"
                                value="<?= e(
                                    $search
                                ); ?>"
                            >


                        </div>


                    </div>



                    <div class="col-lg-3">


                        <select
                            name="status"
                            class="form-select"
                        >


                            <option value="">

                                All Status

                            </option>


                            <?php foreach (
                                $validStatuses
                                as
                                $statusOption
                            ): ?>


                                <?php

                                if (
                                    $user['role'] === 'admin'
                                    &&
                                    $statusOption === 'Draft'
                                ) {

                                    continue;
                                }

                                ?>


                                <option
                                    value="<?= e(
                                        $statusOption
                                    ); ?>"
                                    <?= $status ===
                                        $statusOption
                                            ? 'selected'
                                            : ''; ?>
                                >

                                    <?= e(
                                        $statusOption
                                    ); ?>

                                </option>


                            <?php endforeach; ?>


                        </select>


                    </div>



                    <div class="col-lg-2">


                        <input
                            type="number"
                            name="year"
                            class="form-control"
                            placeholder="Year"
                            min="2000"
                            max="2100"
                            value="<?= e(
                                $year
                            ); ?>"
                        >


                    </div>



                    <div class="col-lg-2">


                        <button
                            type="submit"
                            class="
                                btn
                                btn-outline-asu
                                w-100
                            "
                        >

                            <i class="bi bi-funnel me-1"></i>

                            Filter

                        </button>


                    </div>


                </div>



                <?php if (
                    $search !== ''
                    ||
                    $status !== ''
                    ||
                    $year !== ''
                ): ?>


                    <div class="mt-3">


                        <a
                            href="<?= BASE_URL; ?>/extension/index.php"
                            class="small"
                            style="
                                color:
                                var(--asu-green);
                            "
                        >

                            <i class="bi bi-x-circle me-1"></i>

                            Clear Filters

                        </a>


                    </div>


                <?php endif; ?>


            </form>


        </section>



        <!-- =================================================
             EXTENSION PROGRAM RECORDS
        ================================================== -->

        <section class="asu-panel">


            <div class="panel-header">


                <h2 class="panel-title">


                    <span class="panel-title-icon">

                        <i class="bi bi-megaphone"></i>

                    </span>


                    Extension Programs


                </h2>



                <span class="extension-result-info">

                    <?= number_format(
                        count(
                            $programs
                        )
                    ); ?>

                    record<?= count(
                        $programs
                    ) === 1
                        ? ''
                        : 's'; ?>

                </span>


            </div>



            <?php if (
                empty(
                    $programs
                )
            ): ?>


                <div class="extension-empty-state">


                    <div class="extension-empty-icon">

                        <i class="bi bi-folder2-open"></i>

                    </div>


                    <h3>

                        <?php if (
                            $search !== ''
                            ||
                            $status !== ''
                            ||
                            $year !== ''
                        ): ?>

                            No matching extension programs

                        <?php else: ?>

                            No extension programs yet

                        <?php endif; ?>

                    </h3>


                    <p>

                        <?php if (
                            $search !== ''
                            ||
                            $status !== ''
                            ||
                            $year !== ''
                        ): ?>

                            No extension program records
                            match the selected search or
                            filter criteria.

                        <?php elseif (
                            $user['role'] ===
                            'extension_coordinator'
                        ): ?>

                            You have not created an extension
                            program yet. Create your first
                            program and save it as a draft.

                        <?php else: ?>

                            No extension programs have been
                            submitted for administrative
                            review yet.

                        <?php endif; ?>

                    </p>



                    <?php if (
                        $user['role'] ===
                        'extension_coordinator'
                        &&
                        $search === ''
                        &&
                        $status === ''
                        &&
                        $year === ''
                    ): ?>


                        <a
                            href="<?= BASE_URL; ?>/extension/create.php"
                            class="btn btn-asu"
                        >

                            <i class="bi bi-plus-lg me-1"></i>

                            Add First Program

                        </a>


                    <?php endif; ?>


                </div>


            <?php else: ?>


                <div class="extension-table-wrapper">


                    <table
                        class="
                            table
                            extension-table
                            align-middle
                        "
                    >


                        <thead>


                            <tr>


                                <th>

                                    Program

                                </th>


                                <?php if (
                                    $user['role'] === 'admin'
                                ): ?>

                                    <th>

                                        Coordinator

                                    </th>

                                <?php endif; ?>


                                <th>

                                    Community

                                </th>


                                <th>

                                    College / Department

                                </th>


                                <th>

                                    Status

                                </th>


                                <th>

                                    Schedule

                                </th>


                                <th class="text-end">

                                    Action

                                </th>


                            </tr>


                        </thead>



                        <tbody>


                            <?php foreach (
                                $programs
                                as
                                $program
                            ): ?>


                                <?php

                                $coordinatorName =
                                    trim(
                                        $program[
                                            'first_name'
                                        ]
                                        .
                                        ' '
                                        .
                                        (
                                            !empty(
                                                $program[
                                                    'middle_name'
                                                ]
                                            )
                                                ? $program[
                                                    'middle_name'
                                                ]
                                                . ' '
                                                : ''
                                        )
                                        .
                                        $program[
                                            'last_name'
                                        ]
                                    );


                                $statusClass =
                                    'extension-status-draft';


                                switch (
                                    $program['status']
                                ) {

                                    case 'Submitted':

                                        $statusClass =
                                            'extension-status-submitted';

                                        break;


                                    case 'Under Review':

                                        $statusClass =
                                            'extension-status-review';

                                        break;


                                    case 'For Revision':

                                        $statusClass =
                                            'extension-status-revision';

                                        break;


                                    case 'Approved':

                                        $statusClass =
                                            'extension-status-approved';

                                        break;


                                    case 'Ongoing':

                                        $statusClass =
                                            'extension-status-ongoing';

                                        break;


                                    case 'Completed':

                                        $statusClass =
                                            'extension-status-completed';

                                        break;


                                    case 'Rejected':

                                        $statusClass =
                                            'extension-status-rejected';

                                        break;


                                    case 'Archived':

                                        $statusClass =
                                            'extension-status-archived';

                                        break;
                                }

                                ?>


                                <tr>


                                    <td class="extension-title-cell">


                                        <strong>

                                            <?= e(
                                                $program[
                                                    'program_title'
                                                ]
                                            ); ?>

                                        </strong>


                                        <small>

                                            <?= e(
                                                $program[
                                                    'program_type'
                                                ]
                                                ?: 'No program type'
                                            ); ?>


                                            <?php if (
                                                !empty(
                                                    $program[
                                                        'program_category'
                                                    ]
                                                )
                                            ): ?>

                                                ·

                                                <?= e(
                                                    $program[
                                                        'program_category'
                                                    ]
                                                ); ?>

                                            <?php endif; ?>

                                        </small>


                                    </td>



                                    <?php if (
                                        $user['role'] === 'admin'
                                    ): ?>


                                        <td class="extension-coordinator">


                                            <strong>

                                                <?= e(
                                                    $coordinatorName
                                                ); ?>

                                            </strong>


                                            <small>

                                                Extension Coordinator

                                            </small>


                                        </td>


                                    <?php endif; ?>



                                    <td>


                                        <strong
                                            style="
                                                display:block;
                                                font-size:10px;
                                                font-weight:600;
                                            "
                                        >

                                            <?= e(
                                                $program[
                                                    'target_community'
                                                ]
                                            ); ?>

                                        </strong>


                                        <small
                                            class="text-muted"
                                            style="
                                                font-size:9px;
                                            "
                                        >

                                            <?php

                                            $location = [];

                                            if (
                                                !empty(
                                                    $program[
                                                        'municipality'
                                                    ]
                                                )
                                            ) {

                                                $location[] =
                                                    $program[
                                                        'municipality'
                                                    ];
                                            }

                                            if (
                                                !empty(
                                                    $program[
                                                        'province'
                                                    ]
                                                )
                                            ) {

                                                $location[] =
                                                    $program[
                                                        'province'
                                                    ];
                                            }

                                            echo e(
                                                $location
                                                    ? implode(
                                                        ', ',
                                                        $location
                                                    )
                                                    : 'Location not specified'
                                            );

                                            ?>

                                        </small>


                                    </td>



                                    <td>


                                        <?php if (
                                            !empty(
                                                $program[
                                                    'college_name'
                                                ]
                                            )
                                        ): ?>


                                            <strong
                                                style="
                                                    display:block;
                                                    font-size:10px;
                                                    font-weight:600;
                                                "
                                            >

                                                <?= e(
                                                    $program[
                                                        'college_name'
                                                    ]
                                                ); ?>

                                            </strong>


                                            <small
                                                class="text-muted"
                                                style="
                                                    font-size:9px;
                                                "
                                            >

                                                <?= e(
                                                    $program[
                                                        'department_name'
                                                    ]
                                                    ?: 'No department'
                                                ); ?>

                                            </small>


                                        <?php else: ?>


                                            <span class="text-muted">

                                                Not Assigned

                                            </span>


                                        <?php endif; ?>


                                    </td>



                                    <td>


                                        <span
                                            class="
                                                extension-status
                                                <?= e(
                                                    $statusClass
                                                ); ?>
                                            "
                                        >

                                            <?= e(
                                                $program[
                                                    'status'
                                                ]
                                            ); ?>

                                        </span>


                                    </td>



                                    <td>


                                        <?php if (
                                            !empty(
                                                $program[
                                                    'start_date'
                                                ]
                                            )
                                        ): ?>


                                            <?= e(
                                                date(
                                                    'M d, Y',
                                                    strtotime(
                                                        $program[
                                                            'start_date'
                                                        ]
                                                    )
                                                )
                                            ); ?>


                                            <?php if (
                                                !empty(
                                                    $program[
                                                        'end_date'
                                                    ]
                                                )
                                            ): ?>


                                                <div
                                                    class="text-muted"
                                                    style="
                                                        margin-top:3px;
                                                        font-size:9px;
                                                    "
                                                >

                                                    to

                                                    <?= e(
                                                        date(
                                                            'M d, Y',
                                                            strtotime(
                                                                $program[
                                                                    'end_date'
                                                                ]
                                                            )
                                                        )
                                                    ); ?>

                                                </div>


                                            <?php endif; ?>


                                        <?php else: ?>


                                            <span class="text-muted">

                                                Not set

                                            </span>


                                        <?php endif; ?>


                                    </td>



                                    <td class="text-end">


                                        <a
                                            href="<?= BASE_URL; ?>/extension/view.php?id=<?= (int)$program['extension_id']; ?>"
                                            class="btn btn-outline-asu btn-sm"
                                            title="View extension program"
                                        >

                                            <i class="bi bi-eye me-1"></i>

                                            View

                                        </a>


                                    </td>


                                </tr>


                            <?php endforeach; ?>


                        </tbody>


                    </table>


                </div>


            <?php endif; ?>


        </section>



        <!-- =================================================
             MODULE INFORMATION
        ================================================== -->

        <section class="asu-panel mt-4">


            <div class="panel-header">


                <h2 class="panel-title">


                    <span class="panel-title-icon">

                        <i class="bi bi-info-circle"></i>

                    </span>


                    Extension Module


                </h2>


            </div>



            <div class="panel-body">


                <div class="feature-grid">


                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-folder2-open"></i>

                        </div>


                        <h5>

                            Program Records

                        </h5>


                        <p>

                            Store actual extension program
                            information including dates,
                            target community, coordinator,
                            description and implementation
                            status.

                        </p>


                    </div>



                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-people"></i>

                        </div>


                        <h5>

                            Participant Management

                        </h5>


                        <p>

                            Participant and attendance
                            management will be connected
                            to each approved extension
                            program.

                        </p>


                    </div>



                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-file-earmark-text"></i>

                        </div>


                        <h5>

                            Documents

                        </h5>


                        <p>

                            Program proposals and supporting
                            documents uploaded by authorized
                            users will be attached to the
                            corresponding program record.

                        </p>


                    </div>



                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-check2-square"></i>

                        </div>


                        <h5>

                            Accomplishment Reports

                        </h5>


                        <p>

                            Approved programs will later
                            support accomplishment reports,
                            actual outputs and supporting
                            documentation.

                        </p>


                    </div>



                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-arrow-repeat"></i>

                        </div>


                        <h5>

                            Program Monitoring

                        </h5>


                        <p>

                            Program status and implementation
                            progress will follow the approved
                            extension workflow.

                        </p>


                    </div>



                    <div class="feature-card">


                        <div class="feature-card-icon">

                            <i class="bi bi-archive"></i>

                        </div>


                        <h5>

                            Institutional Records

                        </h5>


                        <p>

                            Completed extension records will
                            remain available to authorized
                            users for historical retrieval
                            and institutional reporting.

                        </p>


                    </div>


                </div>


            </div>


        </section>



        <!-- =================================================
             WORKFLOW NOTICE
        ================================================== -->

        <div class="design-notice">


            <strong>

                Extension Workflow:

            </strong>


            <?php if (
                $user['role'] ===
                'extension_coordinator'
            ): ?>

                New programs are saved as Draft records.
                Drafts remain private until they are
                formally submitted for administrative
                review.

            <?php else: ?>

                Draft programs remain private to their
                Extension Coordinator. Submitted programs
                become available for administrative
                review and monitoring.

            <?php endif; ?>


        </div>



        <!-- =================================================
             FOOTER
        ================================================== -->

        <footer class="content-footer">


            <span>

                © <?= date('Y'); ?>
                Aklan State University

            </span>


            <span class="footer-divider">

                •

            </span>


            <span>

                Research & Extension Management System

            </span>


        </footer>


    </main>


</div>


<?php

require __DIR__ .
    '/../includes/footer.php';

?>
