<?php

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';


function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}


function requireLogin()
{
    global $pdo;

    if (!isLoggedIn()) {

        setFlash(
            'danger',
            'Please log in to continue.'
        );

        redirect(BASE_URL . '/login.php');
    }

    $stmt = $pdo->prepare("
        SELECT status
        FROM users
        WHERE user_id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $_SESSION['user_id']
    ]);

    $user = $stmt->fetch();

    if (!$user || $user['status'] !== 'Active') {

        session_unset();
        session_destroy();

        session_start();

        setFlash(
            'danger',
            'Your account is inactive or unavailable.'
        );

        redirect(BASE_URL . '/login.php');
    }
}


function requireRole($allowedRoles)
{
    requireLogin();

    if (!is_array($allowedRoles)) {
        $allowedRoles = [$allowedRoles];
    }

    $currentRole =
        $_SESSION['role'] ?? '';

    if (
        !in_array(
            $currentRole,
            $allowedRoles,
            true
        )
    ) {

        http_response_code(403);

        require __DIR__ . '/header.php';

        echo '
        <div class="container py-5">
            <div class="alert alert-danger">
                <h4>Access Denied</h4>
                <p>You are not authorized to access this page.</p>
            </div>

            <a href="' . BASE_URL . '/dashboard.php"
               class="btn btn-success">
                Return to Dashboard
            </a>
        </div>
        ';

        require __DIR__ . '/footer.php';

        exit;
    }
}


function currentUser()
{
    global $pdo;

    if (!isLoggedIn()) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT
            u.*,
            c.college_name,
            d.department_name
        FROM users u

        LEFT JOIN colleges c
            ON c.college_id = u.college_id

        LEFT JOIN departments d
            ON d.department_id = u.department_id

        WHERE u.user_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $_SESSION['user_id']
    ]);

    return $stmt->fetch();
}