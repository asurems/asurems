<?php

$user = currentUser();

$activePage = $activePage ?? '';
$currentRole = $user['role'] ?? '';
$currentView = $_GET['view'] ?? '';

/*
|--------------------------------------------------------------------------
| NOTIFICATION BADGE COUNT
|--------------------------------------------------------------------------
*/

$sidebarUnreadNotifications = 0;

$notificationHelperPath = __DIR__ . '/notifications.php';

if (is_file($notificationHelperPath)) {
    require_once $notificationHelperPath;
}

if (
    isset($pdo)
    && function_exists('unreadNotificationCount')
    && !empty($user['user_id'])
) {
    try {
        $sidebarUnreadNotifications = unreadNotificationCount(
            $pdo,
            (int)$user['user_id']
        );
    } catch (Throwable $e) {
        $sidebarUnreadNotifications = 0;
    }
}

$isDashboardActive =
    $activePage === 'dashboard'
    && $currentView !== 'processing';

$isProcessingActive =
    $activePage === 'processing'
    || (
        $activePage === 'dashboard'
        && $currentView === 'processing'
    );

?>

<style>

.asu-sidebar {
    display: flex;
    flex-direction: column;
}

.asu-sidebar .sidebar-brand {
    min-height: 105px;
}

.asu-sidebar .sidebar-menu {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding-top: 12px;
    padding-bottom: 8px;
}

.asu-sidebar .sidebar-link {
    position: relative;
    display: flex;
    align-items: center;
}

.asu-sidebar .sidebar-menu-spacer {
    flex: 1;
}

.asu-sidebar .sidebar-logout {
    margin-top: 25px;
    padding-top: 14px;
    border-top: 1px solid rgba(255, 255, 255, 0.12);
}

.asu-sidebar .sidebar-logout:hover {
    background: rgba(255, 255, 255, 0.10);
    color: #ffffff;
}

.asu-sidebar .sidebar-footer {
    padding-top: 10px;
    padding-bottom: 18px;
}

.asu-sidebar .sidebar-notification-badge,
.asu-sidebar .sidebar-soft-badge {
    min-width: 22px;
    height: 22px;
    margin-left: auto;
    padding: 0 7px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    color: #ffffff;
    font-size: 10px;
    font-weight: 800;
    line-height: 1;
    box-shadow: 0 3px 8px rgba(0, 0, 0, .16);
}

.asu-sidebar .sidebar-notification-badge {
    background: #dc3545;
}

.asu-sidebar .sidebar-soft-badge {
    background: rgba(255, 255, 255, .18);
}

.asu-sidebar .sidebar-link.active .sidebar-notification-badge,
.asu-sidebar .sidebar-link.active .sidebar-soft-badge {
    background: #08752c;
    color: #ffffff;
}



/* =========================================================
   ASU PROFESSIONAL PALETTE POLISH
   Green dominant • Yellow secondary • Orange notifications
   Design-only override: no workflow/database logic changed.
========================================================= */

:root {
    --asu-green: #006B2E;
    --asu-green-dark: #004F22;
    --asu-green-deep: #003F1A;
    --asu-yellow: #FFD21F;
    --asu-yellow-dark: #E5B800;
    --asu-orange: #F28C28;
    --asu-orange-dark: #C96800;
    --asu-white: #FFFFFF;
    --asu-black: #111711;
    --asu-bg: #F7FAF4;
    --asu-card: #FFFFFF;
    --asu-border: rgba(0, 107, 46, .16);
    --asu-muted: #4C554F;
}

html,
body {
    color: var(--asu-black) !important;
    background:
        radial-gradient(circle at top right, rgba(255, 210, 31, .10), transparent 32%),
        linear-gradient(180deg, #FFFFFF 0%, #F7FAF4 100%) !important;
}

.page-content {
    background:
        radial-gradient(circle at top right, rgba(255, 210, 31, .10), transparent 34%),
        linear-gradient(180deg, #FAFCF8 0%, #F4F8F1 100%) !important;
}

.asu-sidebar {
    background:
        linear-gradient(180deg, #007A34 0%, #006B2E 52%, #004F22 100%) !important;
    box-shadow: 12px 0 32px rgba(0, 63, 26, .14) !important;
}

.sidebar-brand {
    border-bottom-color: rgba(255, 255, 255, .14) !important;
}

.brand-logo,
.user-avatar {
    background: var(--asu-yellow) !important;
    color: var(--asu-green-deep) !important;
}

.sidebar-link {
    color: rgba(255, 255, 255, .92) !important;
}

.sidebar-link:hover {
    background: rgba(255, 255, 255, .11) !important;
    color: #FFFFFF !important;
}

.sidebar-link.active {
    background: var(--asu-yellow) !important;
    color: var(--asu-black) !important;
    box-shadow: 0 10px 24px rgba(0, 0, 0, .12) !important;
}

.notification-count,
.sidebar-notification-badge {
    background: var(--asu-orange) !important;
    color: #FFFFFF !important;
    border: 2px solid rgba(255, 255, 255, .35) !important;
    box-shadow: 0 8px 18px rgba(242, 140, 40, .32) !important;
}

.sidebar-link.active .notification-count,
.sidebar-link.active .sidebar-notification-badge {
    background: var(--asu-orange) !important;
    color: #FFFFFF !important;
}

.asu-topbar {
    background: #FFFFFF !important;
    border-bottom: 1px solid rgba(0, 107, 46, .12) !important;
    box-shadow: 0 8px 24px rgba(0, 79, 34, .05) !important;
}

.system-name,
.topbar-user-text strong,
.research-view-heading h1,
.progress-heading h1,
.monitoring-hero h1,
.rps-queue-heading h1,
.processing-hero h1,
.notification-header-row h1,
.card-title,
.research-panel-title,
.workflow-text h4,
.notification-title-line h3 {
    color: var(--asu-black) !important;
}

.topbar-user-text span,
.research-view-heading p,
.progress-heading p,
.monitoring-hero p,
.rps-queue-heading p,
.processing-hero p,
.notification-header-row p,
.info-item label,
.notification-content p,
.notification-meta {
    color: var(--asu-muted) !important;
}

.btn-asu,
.btn.btn-asu {
    background: var(--asu-green) !important;
    border-color: var(--asu-green) !important;
    color: #FFFFFF !important;
    box-shadow: 0 10px 20px rgba(0, 107, 46, .18) !important;
}

.btn-asu:hover,
.btn.btn-asu:hover {
    background: var(--asu-green-dark) !important;
    border-color: var(--asu-green-dark) !important;
    color: #FFFFFF !important;
}

.btn-outline-asu,
.btn.btn-outline-asu {
    background: #FFFFFF !important;
    border-color: rgba(0, 107, 46, .28) !important;
    color: var(--asu-green) !important;
}

.btn-outline-asu:hover,
.btn.btn-outline-asu:hover {
    background: rgba(0, 107, 46, .06) !important;
    border-color: var(--asu-green) !important;
    color: var(--asu-green-deep) !important;
}

.research-panel,
.workflow-card,
.research-document-viewer,
.processing-card,
.processing-queue-card,
.rps-queue-table-wrap,
.notification-summary-card,
.notification-filter-card,
.notification-list-card,
.monitoring-filter-card,
.monitoring-project-card,
.project-info-card,
.progress-form-card,
.progress-history-card,
.progress-update-card,
.card,
.asu-card {
    background: #FFFFFF !important;
    border: 1px solid rgba(0, 107, 46, .14) !important;
    box-shadow: 0 14px 34px rgba(0, 79, 34, .06) !important;
}

.research-panel-icon,
.research-status-overview-icon,
.processing-queue-icon,
.processing-card-icon,
.rps-queue-icon,
.monitoring-icon,
.notification-summary-card .notification-icon,
.notification-icon,
.progress-panel-icon,
.project-info-icon,
.document-icon,
.document-open-icon {
    background: rgba(0, 107, 46, .08) !important;
    color: var(--asu-green) !important;
}

.processing-queue-icon.yellow,
.notification-icon.yellow {
    background: rgba(255, 210, 31, .24) !important;
    color: var(--asu-green-deep) !important;
}

.notification-icon.blue,
.notification-icon.orange,
.notification-summary-card .notification-icon {
    background: rgba(242, 140, 40, .14) !important;
    color: var(--asu-orange-dark) !important;
}

.notification-unread-dot {
    background: var(--asu-orange) !important;
}

.notification-item.unread {
    border-color: rgba(242, 140, 40, .42) !important;
    background: #FFFBF5 !important;
}

.notification-item:hover,
.processing-queue-link:hover,
.rps-queue-table tbody tr:hover td,
.monitoring-project-card:hover {
    border-color: rgba(0, 107, 46, .28) !important;
    box-shadow: 0 18px 40px rgba(0, 79, 34, .10) !important;
}

.notification-tab.active,
.rps-queue-tab.active,
.processing-total-badge,
.rps-queue-badge,
.monitoring-stat-badge {
    background: rgba(255, 210, 31, .22) !important;
    border-color: rgba(0, 107, 46, .20) !important;
    color: var(--asu-green-deep) !important;
}

.processing-count,
.monitoring-count,
.rps-workflow-badge,
.monitoring-status,
.project-status,
.research-status {
    border-color: rgba(0, 107, 46, .18) !important;
    color: var(--asu-green-deep) !important;
}

.status-draft {
    background: #FFFFFF !important;
    color: var(--asu-black) !important;
    border-color: rgba(0, 107, 46, .18) !important;
}

.status-submitted,
.status-review,
.status-under-review,
.status-pending {
    background: rgba(255, 210, 31, .36) !important;
    color: var(--asu-black) !important;
    border-color: rgba(255, 210, 31, .70) !important;
}

.status-revision,
.status-for-revision {
    background: rgba(242, 140, 40, .16) !important;
    color: var(--asu-black) !important;
    border-color: rgba(242, 140, 40, .38) !important;
}

.status-approved,
.status-ongoing,
.status-completed {
    background: var(--asu-green) !important;
    color: #FFFFFF !important;
    border-color: var(--asu-green) !important;
}

.status-rejected,
.status-archived {
    background: var(--asu-black) !important;
    color: #FFFFFF !important;
    border-color: var(--asu-black) !important;
}

/* Professional green status/progress bar */
.research-summary,
.project-summary,
.monitoring-hero {
    background:
        radial-gradient(circle at 95% 0%, rgba(255, 210, 31, .22), transparent 30%),
        linear-gradient(135deg, #007A34 0%, #006B2E 54%, #004F22 100%) !important;
    border: 1px solid rgba(255, 255, 255, .10) !important;
    color: #FFFFFF !important;
    box-shadow: 0 18px 42px rgba(0, 79, 34, .18) !important;
}

.research-summary h2,
.project-summary h2,
.monitoring-hero h1,
.research-summary .research-summary-meta,
.project-summary .project-summary-meta,
.monitoring-hero p {
    color: #FFFFFF !important;
}

.research-summary-meta,
.project-summary-meta {
    color: rgba(255, 255, 255, .84) !important;
}

.research-summary-meta i,
.project-summary-meta i,
.workflow-stage-line i,
.main-progress-head span,
.monitoring-hero i {
    color: var(--asu-yellow) !important;
}

.workflow-status-strip .research-progress-head strong,
.main-progress-head strong,
.monitoring-progress-top strong,
.project-summary .project-status,
.research-summary .research-status {
    background: var(--asu-yellow) !important;
    color: var(--asu-green-deep) !important;
    border-color: rgba(255, 255, 255, .20) !important;
}

.research-summary .research-progress-bar,
.main-progress-track,
.monitoring-progress-track {
    background: rgba(255, 255, 255, .23) !important;
}

.research-summary .research-progress-value,
.main-progress-value,
.monitoring-progress-value {
    background: var(--asu-yellow) !important;
}

.workflow-card {
    border-left: 4px solid var(--asu-green) !important;
}

.workflow-card.is-warning,
.workflow-notice {
    border-left-color: var(--asu-orange) !important;
    background: rgba(242, 140, 40, .08) !important;
    color: var(--asu-black) !important;
}

.form-control:focus,
.form-select:focus {
    border-color: var(--asu-green) !important;
    box-shadow: 0 0 0 .18rem rgba(0, 107, 46, .14) !important;
}


/* Sidebar-specific notification color */
.sidebar-notification-badge,
.notification-count {
    background: #F28C28 !important;
    color: #FFFFFF !important;
}

</style>

<aside class="asu-sidebar">

    <div class="sidebar-brand">
        <div class="brand-logo">
            <i class="bi bi-mortarboard-fill"></i>
        </div>
        <div class="brand-text">
            <h4>ASU-REMS</h4>
            <span>Aklan State University</span>
        </div>
    </div>

    <nav class="sidebar-menu">

        <a
            href="<?= BASE_URL; ?>/dashboard.php"
            class="sidebar-link <?= $isDashboardActive ? 'active' : ''; ?>"
        >
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
        </a>

        <?php if ($currentRole === 'rps'): ?>
            <a
                href="<?= BASE_URL; ?>/research/rps_queue.php?queue=submissions"
                class="sidebar-link <?= $isProcessingActive ? 'active' : ''; ?>"
            >
                <i class="bi bi-clipboard-check"></i>
                <span>Processing Overview</span>
            </a>
        <?php endif; ?>

        <?php if (in_array($currentRole, ['admin', 'faculty'], true)): ?>
            <a
                href="<?= BASE_URL; ?>/research/index.php"
                class="sidebar-link <?= $activePage === 'research' ? 'active' : ''; ?>"
            >
                <i class="bi bi-journal-text"></i>
                <span>Research</span>
            </a>
        <?php endif; ?>

        <?php if (in_array($currentRole, ['faculty', 'rps', 'admin'], true)): ?>
            <a
                href="<?= BASE_URL; ?>/research/monitoring.php"
                class="sidebar-link <?= $activePage === 'project_monitoring' ? 'active' : ''; ?>"
            >
                <i class="bi bi-graph-up-arrow"></i>
                <span>Project Monitoring</span>
            </a>
        <?php endif; ?>

        <?php if (in_array($currentRole, ['admin', 'extension_coordinator'], true)): ?>
            <a
                href="<?= BASE_URL; ?>/extension/index.php"
                class="sidebar-link <?= $activePage === 'extension' ? 'active' : ''; ?>"
            >
                <i class="bi bi-megaphone"></i>
                <span>Extension</span>
            </a>
        <?php endif; ?>

        <?php if ($currentRole === 'admin'): ?>
            <a
                href="<?= BASE_URL; ?>/admin/users/index.php"
                class="sidebar-link <?= $activePage === 'users' ? 'active' : ''; ?>"
            >
                <i class="bi bi-people"></i>
                <span>Users</span>
            </a>
        <?php endif; ?>

        <a
            href="<?= BASE_URL; ?>/reports/index.php"
            class="sidebar-link <?= $activePage === 'reports' ? 'active' : ''; ?>"
        >
            <i class="bi bi-file-earmark-bar-graph"></i>
            <span>Reports</span>
        </a>

        <?php if ($currentRole === 'admin'): ?>
            <a
                href="<?= BASE_URL; ?>/activity_logs/index.php"
                class="sidebar-link <?= $activePage === 'activity' ? 'active' : ''; ?>"
            >
                <i class="bi bi-clock-history"></i>
                <span>Activity Logs</span>
            </a>
        <?php endif; ?>

        <a
            href="<?= BASE_URL; ?>/notifications/index.php"
            class="sidebar-link <?= $activePage === 'notifications' ? 'active' : ''; ?>"
        >
            <i class="bi bi-bell"></i>
            <span>Notifications</span>

            <?php if ($sidebarUnreadNotifications > 0): ?>
                <span class="sidebar-notification-badge">
                    <?= $sidebarUnreadNotifications > 99
                        ? '99+'
                        : number_format($sidebarUnreadNotifications); ?>
                </span>
            <?php endif; ?>
        </a>

        <div class="sidebar-menu-spacer"></div>

        <a
            href="<?= BASE_URL; ?>/logout.php"
            class="sidebar-link sidebar-logout"
        >
            <i class="bi bi-box-arrow-left"></i>
            <span>Logout</span>
        </a>

    </nav>

    <div class="sidebar-footer">
        <small>© <?= date('Y'); ?> ASU Research Office</small>
    </div>

</aside>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
